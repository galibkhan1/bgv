from __future__ import annotations

from enum import StrEnum


class UserRole(StrEnum):
    ADMIN = "admin"
    LEAD = "lead"
    ANALYST = "analyst"
    VIEWER = "viewer"


class RuleSource(StrEnum):
    MANUAL = "manual"
    AI = "ai"
    CONTRACT = "contract"


class RuleEngine(StrEnum):
    SODA = "soda"
    GE = "ge"


class Severity(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class RunStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class IssueStatus(StrEnum):
    OPEN = "open"
    ACKNOWLEDGED = "acknowledged"
    SNOOZED = "snoozed"
    RESOLVED = "resolved"


class AlertChannel(StrEnum):
    SLACK = "slack"
    EMAIL = "email"


class AlertStatus(StrEnum):
    SENT = "sent"
    RESOLVED = "resolved"
    ESCALATED = "escalated"
    EXPIRED = "expired"


class HealingStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXECUTED = "executed"
    FAILED = "failed"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class AuditAction(StrEnum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    EXECUTE = "execute"
    APPROVE = "approve"
    REJECT = "reject"
    LOGIN = "login"


# Trust score weights
TRUST_WEIGHT_COMPLETENESS = 0.40
TRUST_WEIGHT_ACCURACY = 0.40
TRUST_WEIGHT_TIMELINESS = 0.20

# Healing safety
HEALING_MAX_ROWS = 1000
