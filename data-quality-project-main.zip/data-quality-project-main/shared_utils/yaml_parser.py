from __future__ import annotations

import re
import yaml


def strip_yaml_fences(text: str) -> str:
    """Remove markdown code fences from LLM output."""
    text = text.strip()
    text = re.sub(r"^```(?:yaml|yml)?\s*\n?", "", text)
    text = re.sub(r"\n?```\s*$", "", text)
    return text.strip()


def parse_sodacl_yaml(text: str) -> list[dict]:
    """Parse SodaCL YAML from LLM output into a list of check entries.

    Returns a list of dicts with keys: name, definition, dimension.
    Each definition is stored in check-line-only format:
      "- row_count > 0"
      "- invalid_count(age) = 0:\n    valid min: 18\n    valid max: 70"

    This means NO "checks for <table>:" wrapper — just the check lines
    ready to be assembled into SodaCL YAML by the scan engine.
    """
    clean = strip_yaml_fences(text)
    checks = []

    # Try YAML parse first
    try:
        parsed = yaml.safe_load(clean)
        if isinstance(parsed, dict):
            # SodaCL format: {"checks for table": [list of checks]}
            for key, value in parsed.items():
                if not isinstance(value, list):
                    continue
                for item in value:
                    if isinstance(item, str):
                        # Simple check like "row_count > 0"
                        name = _extract_check_name(item)
                        dimension = extract_dimension_comment(item)
                        # Strip any leading "- " the LLM may have included
                        clean_item = item.lstrip("- ").strip()
                        defn = f"- {clean_item}"
                        checks.append({"name": name, "definition": defn, "dimension": dimension})
                    elif isinstance(item, dict):
                        # Complex check like {"invalid_count(age) = 0": {"valid min": 18, "valid max": 70}}
                        for check_key, check_val in item.items():
                            name = _extract_check_name(check_key)
                            if isinstance(check_val, dict):
                                # Multi-line definition with sub-keys
                                lines = [f"- {check_key}:"]
                                for sub_key, sub_val in check_val.items():
                                    lines.append(f"    {sub_key}: {sub_val}")
                                defn = "\n".join(lines)
                            elif check_val is not None:
                                defn = f"- {check_key}: {check_val}"
                            else:
                                defn = f"- {check_key}"
                            checks.append({"name": name, "definition": defn, "dimension": None})
            if checks:
                return checks
    except yaml.YAMLError:
        pass

    # Fallback: line-by-line parsing for malformed YAML
    # Handles multi-line checks by tracking indentation
    lines = clean.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Skip "checks for <table>:" headers
        if stripped.startswith("checks for ") and stripped.endswith(":"):
            i += 1
            continue

        if stripped.startswith("- "):
            check_text = stripped[2:].strip()
            name = _extract_check_name(check_text)
            dimension = extract_dimension_comment(line)

            # Collect sub-lines (indented continuation)
            defn_lines = [stripped]
            base_indent = len(line) - len(line.lstrip())
            j = i + 1
            while j < len(lines):
                next_line = lines[j]
                next_stripped = next_line.strip()
                if not next_stripped:
                    j += 1
                    continue
                next_indent = len(next_line) - len(next_line.lstrip())
                if next_indent > base_indent and not next_stripped.startswith("- "):
                    defn_lines.append(f"    {next_stripped}")
                    j += 1
                else:
                    break

            defn = "\n".join(defn_lines)
            checks.append({"name": name, "definition": defn, "dimension": dimension})
            i = j
        else:
            i += 1

    return checks


def _extract_check_name(text: str) -> str:
    """Extract the check name from a check line.

    Examples:
      "row_count > 0" -> "row_count"
      "missing_count(name) = 0" -> "missing_count(name)"
      "invalid_count(age) = 0:" -> "invalid_count(age)"
    """
    text = text.lstrip("- ").strip()
    # Match function-style: name(arg)
    match = re.match(r'^(\w+\([^)]*\))', text)
    if match:
        return match.group(1)
    # Match simple name before operator
    match = re.match(r'^(\w+)', text)
    if match:
        return match.group(1)
    return text.split(":")[0].strip()


def extract_dimension_comment(yaml_text: str) -> str | None:
    """Extract # dimension: tag from SodaCL YAML lines."""
    for line in yaml_text.splitlines():
        match = re.search(r"#\s*dimension:\s*(\w+)", line)
        if match:
            return match.group(1).lower()
    return None
