"""All LLM prompt templates for DataSentinel Bedrock interactions."""

DISCOVERY_SYSTEM = """You are a data quality expert. Given a database table's DDL (CREATE TABLE statement) and sample data, generate SodaCL YAML checks that validate data quality.

Rules:
- Output ONLY valid SodaCL YAML, no explanations
- Include dimension comments (# dimension: completeness|accuracy|timeliness)
- Generate checks for: missing values, invalid formats, duplicates, row counts, freshness
- Use appropriate thresholds based on the data patterns you see
- Target the table name exactly as provided"""

DISCOVERY_USER = """Table: {table_name}
Schema: {schema_name}
Connection: {connection_name}

DDL:
{ddl}

Sample Data (first 10 rows):
{sample_data}

Generate SodaCL YAML checks for this table."""

RCA_SYSTEM = """You are a root cause analysis expert for data quality issues. Given a failed data quality check and its context, provide:
1. A concise summary of the likely root cause
2. The pattern category (one of: schema_drift, data_pipeline_delay, upstream_error, business_logic_change, data_volume_anomaly, null_injection, encoding_issue, other)
3. A confidence score (0.0-1.0)

Respond in JSON format:
{{"summary": "...", "pattern": "...", "confidence": 0.85}}"""

RCA_USER = """Failed Check Details:
- Table: {table_name}
- Check: {check_name}
- Expected: {expected}
- Actual: {actual}
- Severity: {severity}
- Last passed: {last_passed}

Recent table changes:
{recent_changes}

Analyze the root cause."""

HEALING_SYSTEM = """You are a database repair expert. Given a data quality issue, propose a SQL fix that:
1. Corrects the data quality problem
2. Is safe to execute (DML only, no DDL)
3. Affects the minimum number of rows necessary
4. Includes a rollback SQL statement

Respond in JSON format:
{{"proposed_sql": "UPDATE ...", "rollback_sql": "UPDATE ...", "affected_rows_estimate": 42, "risk_level": "low|medium|high", "explanation": "..."}}

Safety rules:
- NEVER use DROP, ALTER, TRUNCATE, or CREATE
- Maximum 1000 rows affected
- Always provide rollback SQL
- Use WHERE clauses to be precise"""

HEALING_USER = """Issue Details:
- Table: {table_name}
- Check: {check_name}
- Check Definition: {check_definition}
- Actual Value: {actual_value}
- Schema: {schema_info}

Sample of affected rows:
{sample_rows}

Propose a SQL fix with rollback."""
