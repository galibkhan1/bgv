"""Add discovery_runs table for tracking AI discovery history

Revision ID: 002_discovery_runs
Revises: 001_initial
Create Date: 2026-02-21
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = '002_discovery_runs'
down_revision: Union[str, None] = '001_initial'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('discovery_runs',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('connection_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('data_connections.id'), nullable=False),
        sa.Column('triggered_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('status', sa.String(20), nullable=False, server_default='running'),
        sa.Column('tables_processed', sa.Integer(), server_default='0'),
        sa.Column('rules_generated', sa.Integer(), server_default='0'),
        sa.Column('tables_requested', sa.Text(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('errors_json', postgresql.JSONB(), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_index('ix_discovery_runs_connection_id', 'discovery_runs', ['connection_id'])

    op.execute("""
        CREATE TRIGGER update_discovery_runs_updated_at
        BEFORE UPDATE ON discovery_runs
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    """)


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS update_discovery_runs_updated_at ON discovery_runs")
    op.drop_index('ix_discovery_runs_connection_id')
    op.drop_table('discovery_runs')
