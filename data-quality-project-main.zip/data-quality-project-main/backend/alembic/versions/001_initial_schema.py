"""Initial schema - all 10 tables

Revision ID: 001_initial
Revises: None
Create Date: 2026-02-17
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = '001_initial'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # users
    op.create_table('users',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('email', sa.String(320), unique=True, nullable=False, index=True),
        sa.Column('hashed_password', sa.String(128), nullable=False),
        sa.Column('full_name', sa.String(200), nullable=False),
        sa.Column('role', sa.String(20), nullable=False, server_default='viewer'),
        sa.Column('is_active', sa.Boolean(), server_default='true'),
        sa.Column('hr_scope_departments', postgresql.ARRAY(sa.String()), nullable=True),
        sa.Column('hr_scope_teams', postgresql.ARRAY(sa.String()), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # data_connections
    op.create_table('data_connections',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('name', sa.String(200), unique=True, nullable=False),
        sa.Column('db_type', sa.String(50), nullable=False, server_default='postgresql'),
        sa.Column('host', sa.String(500), nullable=False),
        sa.Column('port', sa.Integer(), nullable=False, server_default='5432'),
        sa.Column('database', sa.String(200), nullable=False),
        sa.Column('schema_name', sa.String(200), nullable=False, server_default='public'),
        sa.Column('username', sa.String(200), nullable=True),
        sa.Column('encrypted_password', sa.Text(), nullable=True),
        sa.Column('secret_arn', sa.String(500), nullable=True),
        sa.Column('is_active', sa.Boolean(), server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # dq_rules
    op.create_table('dq_rules',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('connection_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('data_connections.id'), nullable=False),
        sa.Column('table_name', sa.String(500), nullable=False, index=True),
        sa.Column('check_name', sa.String(500), nullable=False),
        sa.Column('check_definition', sa.Text(), nullable=False),
        sa.Column('source', sa.String(20), nullable=False, server_default='manual'),
        sa.Column('engine', sa.String(20), nullable=False, server_default='soda'),
        sa.Column('severity', sa.String(20), nullable=False, server_default='medium'),
        sa.Column('dimension', sa.String(50), nullable=True),
        sa.Column('is_contract', sa.Boolean(), server_default='false'),
        sa.Column('is_active', sa.Boolean(), server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # dq_rule_versions
    op.create_table('dq_rule_versions',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('rule_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('dq_rules.id'), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('check_definition', sa.Text(), nullable=False),
        sa.Column('change_reason', sa.String(500), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # dq_runs
    op.create_table('dq_runs',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('connection_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('data_connections.id'), nullable=False),
        sa.Column('triggered_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('status', sa.String(20), nullable=False, server_default='pending'),
        sa.Column('engine', sa.String(20), nullable=False, server_default='soda'),
        sa.Column('total_checks', sa.Integer(), server_default='0'),
        sa.Column('passed', sa.Integer(), server_default='0'),
        sa.Column('failed', sa.Integer(), server_default='0'),
        sa.Column('warnings', sa.Integer(), server_default='0'),
        sa.Column('health_score', sa.Float(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # dq_issues
    op.create_table('dq_issues',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('run_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('dq_runs.id'), nullable=False),
        sa.Column('rule_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('dq_rules.id'), nullable=True),
        sa.Column('table_name', sa.String(500), nullable=False),
        sa.Column('check_name', sa.String(500), nullable=False),
        sa.Column('severity', sa.String(20), nullable=False, server_default='medium'),
        sa.Column('status', sa.String(20), nullable=False, server_default='open'),
        sa.Column('expected_value', sa.Text(), nullable=True),
        sa.Column('actual_value', sa.Text(), nullable=True),
        sa.Column('rca_summary', sa.Text(), nullable=True),
        sa.Column('rca_pattern', sa.String(100), nullable=True),
        sa.Column('rca_confidence', sa.Float(), nullable=True),
        sa.Column('snoozed_until', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # healing_proposals
    op.create_table('healing_proposals',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('issue_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('dq_issues.id'), nullable=False),
        sa.Column('proposed_sql', sa.Text(), nullable=False),
        sa.Column('rollback_sql', sa.Text(), nullable=False),
        sa.Column('explanation', sa.Text(), nullable=True),
        sa.Column('risk_level', sa.String(20), nullable=False, server_default='medium'),
        sa.Column('confidence', sa.Float(), nullable=False, server_default='0'),
        sa.Column('affected_rows_estimate', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('status', sa.String(20), nullable=False, server_default='pending'),
        sa.Column('approved_by', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('execution_result', sa.Text(), nullable=True),
        sa.Column('actual_rows_affected', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # alerts
    op.create_table('alerts',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('issue_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('dq_issues.id'), nullable=True),
        sa.Column('healing_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('healing_proposals.id'), nullable=True),
        sa.Column('channel', sa.String(20), nullable=False),
        sa.Column('recipient', sa.String(500), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('status', sa.String(20), nullable=False, server_default='sent'),
        sa.Column('resolution_token', postgresql.UUID(as_uuid=True), unique=True),
        sa.Column('resolution_action', sa.String(50), nullable=True),
        sa.Column('escalation_level', sa.Integer(), server_default='0'),
        sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # trust_scores
    op.create_table('trust_scores',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('connection_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('data_connections.id'), nullable=False),
        sa.Column('table_name', sa.String(500), nullable=False, index=True),
        sa.Column('overall', sa.Float(), nullable=False, server_default='100'),
        sa.Column('completeness', sa.Float(), nullable=False, server_default='100'),
        sa.Column('accuracy', sa.Float(), nullable=False, server_default='100'),
        sa.Column('timeliness', sa.Float(), nullable=False, server_default='100'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # audit_trail (immutable)
    op.create_table('audit_trail',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('entity_type', sa.String(100), nullable=False, index=True),
        sa.Column('entity_id', sa.String(100), nullable=False),
        sa.Column('action', sa.String(50), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('old_values', postgresql.JSONB(), nullable=True),
        sa.Column('new_values', postgresql.JSONB(), nullable=True),
        sa.Column('justification', sa.Text(), nullable=True),
        sa.Column('ip_address', sa.String(50), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # --- Performance indexes on high-query columns ---
    op.create_index('ix_dq_rules_connection_id', 'dq_rules', ['connection_id'])
    op.create_index('ix_dq_issues_run_id', 'dq_issues', ['run_id'])
    op.create_index('ix_dq_issues_table_name', 'dq_issues', ['table_name'])
    op.create_index('ix_dq_issues_status', 'dq_issues', ['status'])
    op.create_index('ix_alerts_status', 'alerts', ['status'])
    op.create_index('ix_alerts_resolution_token', 'alerts', ['resolution_token'])
    op.create_index('ix_healing_proposals_status', 'healing_proposals', ['status'])
    op.create_index('ix_trust_scores_connection_id', 'trust_scores', ['connection_id'])

    # --- updated_at trigger for automatic timestamp updates ---
    op.execute("""
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    """)

    for table in ['users', 'data_connections', 'dq_rules', 'dq_rule_versions',
                   'dq_runs', 'dq_issues', 'healing_proposals', 'alerts', 'trust_scores']:
        op.execute(f"""
            CREATE TRIGGER update_{table}_updated_at
            BEFORE UPDATE ON {table}
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
        """)

    # Immutable audit trail trigger
    op.execute("""
        CREATE OR REPLACE FUNCTION prevent_audit_modification()
        RETURNS TRIGGER AS $$
        BEGIN
            RAISE EXCEPTION 'audit_trail is immutable: UPDATE and DELETE are not allowed';
        END;
        $$ LANGUAGE plpgsql;

        CREATE TRIGGER audit_trail_immutable
        BEFORE UPDATE OR DELETE ON audit_trail
        FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();
    """)


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS audit_trail_immutable ON audit_trail")
    op.execute("DROP FUNCTION IF EXISTS prevent_audit_modification()")

    for table in ['users', 'data_connections', 'dq_rules', 'dq_rule_versions',
                   'dq_runs', 'dq_issues', 'healing_proposals', 'alerts', 'trust_scores']:
        op.execute(f"DROP TRIGGER IF EXISTS update_{table}_updated_at ON {table}")
    op.execute("DROP FUNCTION IF EXISTS update_updated_at_column()")

    op.drop_index('ix_trust_scores_connection_id')
    op.drop_index('ix_healing_proposals_status')
    op.drop_index('ix_alerts_resolution_token')
    op.drop_index('ix_alerts_status')
    op.drop_index('ix_dq_issues_status')
    op.drop_index('ix_dq_issues_table_name')
    op.drop_index('ix_dq_issues_run_id')
    op.drop_index('ix_dq_rules_connection_id')
    op.drop_table('audit_trail')
    op.drop_table('trust_scores')
    op.drop_table('alerts')
    op.drop_table('healing_proposals')
    op.drop_table('dq_issues')
    op.drop_table('dq_runs')
    op.drop_table('dq_rule_versions')
    op.drop_table('dq_rules')
    op.drop_table('data_connections')
    op.drop_table('users')
