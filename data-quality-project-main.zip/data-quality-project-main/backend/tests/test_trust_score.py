"""Tests for trust score dimension classification."""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from data_sentinel.services.trust_score_engine import classify_dimension


def test_classify_completeness():
    assert classify_dimension("missing_count(email) = 0", None) == "completeness"
    assert classify_dimension("row_count > 0", None) == "completeness"


def test_classify_accuracy():
    assert classify_dimension("invalid_count(age) = 0", None) == "accuracy"
    assert classify_dimension("duplicate_count(id) = 0", None) == "accuracy"


def test_classify_timeliness():
    assert classify_dimension("freshness(updated_at) < 24h", None) == "timeliness"


def test_classify_with_hint():
    assert classify_dimension("some_check > 0", "completeness") == "completeness"


def test_classify_default():
    assert classify_dimension("some_unknown_check > 5", None) == "accuracy"
