"""Tests for shared_utils yaml_parser."""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from shared_utils.yaml_parser import strip_yaml_fences, extract_dimension_comment


def test_strip_yaml_fences():
    text = "```yaml\nchecks:\n  - row_count > 0\n```"
    result = strip_yaml_fences(text)
    assert result == "checks:\n  - row_count > 0"


def test_strip_no_fences():
    text = "checks:\n  - row_count > 0"
    result = strip_yaml_fences(text)
    assert result == text


def test_extract_dimension():
    yaml = "  - missing_count(email) = 0  # dimension: completeness"
    assert extract_dimension_comment(yaml) == "completeness"


def test_extract_dimension_none():
    yaml = "  - row_count > 0"
    assert extract_dimension_comment(yaml) is None
