"""Basic smoke tests for DataSentinel API."""
import pytest
from httpx import ASGITransport, AsyncClient


@pytest.fixture
def app():
    from data_sentinel.main import app
    return app


@pytest.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.mark.asyncio
async def test_healthz(client):
    resp = await client.get("/healthz")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


@pytest.mark.asyncio
async def test_login_invalid(client):
    resp = await client.post("/api/auth/login", json={"email": "x@x.com", "password": "wrong"})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_protected_route_no_token(client):
    resp = await client.get("/api/connections")
    # HTTPBearer returns 403 when no Authorization header is present (FastAPI default)
    assert resp.status_code == 403
