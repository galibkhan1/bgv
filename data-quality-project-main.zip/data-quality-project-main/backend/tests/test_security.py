"""Tests for security utilities."""
from data_sentinel.core.security import hash_password, verify_password, create_access_token, decode_access_token


def test_password_hash_verify():
    password = "test-password-123"
    hashed = hash_password(password)
    assert hashed != password
    assert verify_password(password, hashed)
    assert not verify_password("wrong", hashed)


def test_jwt_roundtrip():
    data = {"sub": "test-user-id", "role": "admin"}
    token = create_access_token(data)
    decoded = decode_access_token(token)
    assert decoded is not None
    assert decoded["sub"] == "test-user-id"
    assert decoded["role"] == "admin"


def test_jwt_invalid():
    result = decode_access_token("invalid.token.here")
    assert result is None
