#!/usr/bin/env python3
"""Create an admin user for DataSentinel."""
from __future__ import annotations

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sqlalchemy import select
from data_sentinel.core.database import async_session_factory
from data_sentinel.core.security import hash_password
from data_sentinel.models.user import User


async def main():
    import getpass
    email = input("Admin email: ").strip()
    password = getpass.getpass("Admin password: ")
    full_name = input("Full name: ").strip()

    async with async_session_factory() as session:
        existing = await session.execute(select(User).where(User.email == email))
        if existing.scalar_one_or_none():
            print(f"User {email} already exists")
            return

        user = User(
            email=email,
            hashed_password=hash_password(password),
            full_name=full_name,
            role="admin",
            is_active=True,
        )
        session.add(user)
        await session.commit()
        print(f"Admin user '{full_name}' ({email}) created successfully")


if __name__ == "__main__":
    asyncio.run(main())
