#!/usr/bin/env python3
"""Seed development data for DataSentinel."""
from __future__ import annotations

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from data_sentinel.core.database import async_session_factory
from data_sentinel.core.encryption import encrypt_password
from data_sentinel.core.security import hash_password
from data_sentinel.models.user import User
from data_sentinel.models.connection import DataConnection


async def main():
    async with async_session_factory() as session:
        # Create dev users
        users = [
            User(email="admin@datasentinel.dev", hashed_password=hash_password("admin123"),
                 full_name="Dev Admin", role="admin"),
            User(email="lead@datasentinel.dev", hashed_password=hash_password("lead123"),
                 full_name="Dev Lead", role="lead"),
            User(email="analyst@datasentinel.dev", hashed_password=hash_password("analyst123"),
                 full_name="Dev Analyst", role="analyst"),
        ]
        for u in users:
            session.add(u)

        # Create sample connection (Postgres.app trust auth)
        conn = DataConnection(
            name="dev-postgres",
            db_type="postgresql",
            host="localhost",
            port=5432,
            database="datasentinel",
            schema_name="public",
            username="dakshsahni",
            encrypted_password=encrypt_password("trust"),
        )
        session.add(conn)

        await session.commit()
        print("Dev data seeded: 3 users + 1 connection")


if __name__ == "__main__":
    asyncio.run(main())
