#!/usr/bin/env python3
"""Seed HR-specific demo data for client presentation to HR team."""
from __future__ import annotations

import asyncio
import os
import sys
import uuid
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sqlalchemy import select, delete

from data_sentinel.core.database import async_session_factory
from data_sentinel.models.connection import DataConnection
from data_sentinel.models.rule import DQRule
from data_sentinel.models.run import DQRun
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.trust_score import TrustScore
from data_sentinel.models.alert import Alert
from data_sentinel.models.audit_trail import AuditTrail

NOW = datetime.now(timezone.utc)

HR_TABLES = ["employees", "employee_attrition", "performance_ratings", "pulse_surveys", "employee_learning", "employee_promotions"]


async def main():
    async with async_session_factory() as session:
        # Get the dev-postgres connection
        result = await session.execute(
            select(DataConnection).where(DataConnection.name == "dev-postgres")
        )
        conn = result.scalar_one_or_none()
        if not conn:
            print("ERROR: Run seed_dev_data.py first")
            return
        conn_id = conn.id

        # Clean old rules/issues/scores for HR tables (idempotent re-run)
        for model in [DQIssue, DQRule, TrustScore]:
            await session.execute(
                delete(model).where(model.table_name.in_(HR_TABLES))
            )
        await session.commit()

        # ── DQ Rules (18 rules across 6 HR tables) ──────────────────
        rules_data = [
            # employees
            ("employees", "row_count", "- row_count > 0", "completeness", "high"),
            ("employees", "missing_count(name)", "- missing_count(name) = 0", "completeness", "critical"),
            ("employees", "missing_count(department)", "- missing_count(department) = 0", "completeness", "high"),
            ("employees", "missing_count(hire_date)", "- missing_count(hire_date) = 0", "completeness", "high"),
            ("employees", "invalid_count(age)", "- invalid_count(age) = 0:\n      valid min: 18\n      valid max: 70", "accuracy", "medium"),
            ("employees", "min(salary)", "- min(salary) >= 0", "accuracy", "high"),
            # employee_attrition
            ("employee_attrition", "row_count", "- row_count > 0", "completeness", "medium"),
            ("employee_attrition", "missing_count(reason)", "- missing_count(reason) = 0", "completeness", "high"),
            ("employee_attrition", "missing_count(exit_date)", "- missing_count(exit_date) = 0", "completeness", "critical"),
            # performance_ratings
            ("performance_ratings", "row_count", "- row_count > 0", "completeness", "medium"),
            ("performance_ratings", "missing_count(rating)", "- missing_count(rating) = 0", "completeness", "critical"),
            ("performance_ratings", "missing_count(review_date)", "- missing_count(review_date) = 0", "completeness", "high"),
            # pulse_surveys
            ("pulse_surveys", "row_count", "- row_count > 0", "completeness", "medium"),
            ("pulse_surveys", "missing_count(score)", "- missing_count(score) = 0", "completeness", "high"),
            ("pulse_surveys", "freshness(survey_date)", "- freshness(survey_date) < 30d", "timeliness", "high"),
            # employee_learning
            ("employee_learning", "row_count", "- row_count > 0", "completeness", "medium"),
            ("employee_learning", "missing_count(course_name)", "- missing_count(course_name) = 0", "completeness", "high"),
            # employee_promotions
            ("employee_promotions", "row_count", "- row_count > 0", "completeness", "medium"),
        ]

        rule_ids = {}
        for table, check_name, check_def, dimension, severity in rules_data:
            rule = DQRule(
                connection_id=conn_id,
                table_name=table,
                check_name=check_name,
                check_definition=check_def,
                source="ai",
                engine="soda",
                severity=severity,
                dimension=dimension,
                is_active=True,
            )
            session.add(rule)
            await session.flush()
            rule_ids[(table, check_name)] = rule.id

        # ── DQ Runs (6 scan runs over last 5 days) ──────────────────
        runs_data = [
            (NOW - timedelta(days=5, hours=2), "completed", 18, 16, 2, 0, 88.9),
            (NOW - timedelta(days=4, hours=6), "completed", 18, 15, 2, 1, 83.3),
            (NOW - timedelta(days=3, hours=2), "completed", 18, 16, 1, 1, 88.9),
            (NOW - timedelta(days=2, hours=6), "completed", 18, 17, 1, 0, 94.4),
            (NOW - timedelta(days=1, hours=2), "completed", 18, 17, 1, 0, 94.4),
            (NOW - timedelta(hours=4), "completed", 18, 18, 0, 0, 100.0),
        ]

        run_ids = []
        for started, status, total, p, f, w, score in runs_data:
            run = DQRun(
                connection_id=conn_id,
                status=status,
                engine="soda",
                total_checks=total,
                passed=p,
                failed=f,
                warnings=w,
                health_score=score,
                started_at=started,
                completed_at=started + timedelta(minutes=3),
            )
            session.add(run)
            await session.flush()
            run_ids.append(run.id)

        # ── DQ Issues (HR-specific failures) ────────────────────────
        issues_data = [
            (run_ids[0], "employees", "missing_count(department)", "0", "3", "high",
             "3 employee records missing department — likely from recent bulk import of contractor data", "data_pipeline_delay", 0.88),
            (run_ids[0], "employee_attrition", "missing_count(reason)", "0", "5", "high",
             "5 exit records missing reason field — HR team may not have completed exit interviews", "business_logic_change", 0.82),
            (run_ids[1], "performance_ratings", "missing_count(rating)", "0", "12", "critical",
             "12 performance reviews missing ratings — Q4 review cycle incomplete", "upstream_error", 0.91),
            (run_ids[1], "pulse_surveys", "freshness(survey_date)", "< 30d", "45d", "high",
             "Latest pulse survey data is 45 days old — survey pipeline may be stalled", "data_pipeline_delay", 0.95),
            (run_ids[2], "employees", "invalid_count(age)", "0", "2", "medium",
             None, None, None),
            (run_ids[3], "pulse_surveys", "freshness(survey_date)", "< 30d", "35d", "high",
             "Survey freshness improving but still exceeds 30-day threshold", "data_pipeline_delay", 0.89),
        ]

        for run_id, table, check, expected, actual, severity, rca_sum, rca_pat, rca_conf in issues_data:
            rule_id = rule_ids.get((table, check))
            issue = DQIssue(
                run_id=run_id,
                rule_id=rule_id,
                table_name=table,
                check_name=check,
                expected_value=expected,
                actual_value=actual,
                severity=severity,
                status="open",
                rca_summary=rca_sum,
                rca_pattern=rca_pat,
                rca_confidence=rca_conf,
            )
            session.add(issue)

        # ── Trust Scores (daily scores for 6 HR tables) ─────────────
        trust_data = {
            "employees":           [(92, 94, 90, 91), (90, 92, 88, 89), (93, 95, 91, 92), (95, 97, 93, 94), (96, 98, 95, 95)],
            "employee_attrition":  [(85, 82, 88, 86), (83, 80, 86, 84), (86, 84, 89, 87), (88, 86, 90, 88), (90, 88, 92, 90)],
            "performance_ratings": [(78, 85, 70, 80), (75, 82, 67, 78), (80, 87, 72, 82), (85, 90, 78, 86), (88, 92, 83, 88)],
            "pulse_surveys":       [(70, 80, 75, 50), (68, 78, 73, 48), (72, 82, 77, 52), (76, 85, 80, 58), (80, 88, 84, 65)],
            "employee_learning":   [(94, 96, 92, 94), (93, 95, 91, 93), (95, 97, 93, 95), (96, 98, 94, 96), (97, 99, 96, 97)],
            "employee_promotions": [(96, 98, 95, 96), (95, 97, 94, 95), (97, 99, 96, 97), (97, 99, 96, 97), (98, 100, 97, 98)],
        }

        for table, daily_scores in trust_data.items():
            for day_offset, (ov, co, ac, ti) in enumerate(daily_scores):
                ts = TrustScore(
                    connection_id=conn_id,
                    table_name=table,
                    overall=ov,
                    completeness=co,
                    accuracy=ac,
                    timeliness=ti,
                )
                session.add(ts)

        # ── Alerts (HR-relevant) ─────────────────────────────────────
        alerts_data = [
            ("slack", "#hr-data-quality", "Performance ratings table has 12 missing ratings — Q4 review cycle incomplete", "sent"),
            ("email", "hr-lead@company.com", "Pulse survey data is 45 days stale — engagement tracking impacted", "sent"),
            ("slack", "#hr-data-quality", "Employee attrition records missing exit reasons — compliance risk", "resolved"),
        ]
        for channel, recipient, message, status in alerts_data:
            alert = Alert(channel=channel, recipient=recipient, message=message, status=status)
            session.add(alert)

        # ── Audit Trail ──────────────────────────────────────────────
        audit_entries = [
            ("scan", "trigger", "Admin triggered HR data quality scan"),
            ("rule", "create", "AI discovery generated 18 HR-specific quality rules"),
            ("alert", "resolve", "Resolved attrition exit-reason alert after HR completed interviews"),
            ("connection", "create", "Created dev-postgres connection for HR analytics DB"),
            ("scan", "trigger", "Scheduled daily HR scan executed"),
        ]
        for entity_type, action, justification in audit_entries:
            entry = AuditTrail(
                entity_type=entity_type,
                entity_id=str(uuid.uuid4()),
                action=action,
                justification=justification,
            )
            session.add(entry)

        await session.commit()
        print("HR demo data seeded:")
        print("  - 18 DQ rules (6 HR tables)")
        print("  -  6 scan runs (5 days, improving trend)")
        print("  -  6 issues (4 with RCA analysis)")
        print("  - 30 trust scores (6 tables x 5 days)")
        print("  -  3 HR-relevant alerts")
        print("  -  5 audit trail entries")


if __name__ == "__main__":
    asyncio.run(main())
