#!/usr/bin/env python3
"""Seed realistic demo data for client presentation."""
from __future__ import annotations

import asyncio
import os
import sys
import uuid
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sqlalchemy import select

from data_sentinel.core.database import async_session_factory
from data_sentinel.models.connection import DataConnection
from data_sentinel.models.rule import DQRule
from data_sentinel.models.run import DQRun
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.trust_score import TrustScore
from data_sentinel.models.alert import Alert
from data_sentinel.models.audit_trail import AuditTrail

NOW = datetime.now(timezone.utc)


async def main():
    async with async_session_factory() as session:
        # Get the dev-postgres connection
        result = await session.execute(
            select(DataConnection).where(DataConnection.name == "dev-postgres")
        )
        conn = result.scalar_one_or_none()
        if not conn:
            print("ERROR: Run seed_dev_data.py first to create the dev-postgres connection")
            return

        conn_id = conn.id

        # ── DQ Rules (12 rules across 4 tables) ──────────────────────
        rules_data = [
            ("orders", "row_count", "checks for orders:\n  - row_count > 0", "soda", "completeness", "high"),
            ("orders", "missing_count(order_date)", "checks for orders:\n  - missing_count(order_date) = 0", "soda", "completeness", "critical"),
            ("orders", "freshness(order_date)", "checks for orders:\n  - freshness(order_date) < 2d", "soda", "timeliness", "high"),
            ("customers", "duplicate_count(email)", "checks for customers:\n  - duplicate_count(email) = 0", "soda", "accuracy", "critical"),
            ("customers", "missing_count(email)", "checks for customers:\n  - missing_count(email) = 0", "soda", "completeness", "high"),
            ("customers", "invalid_count(phone)", "checks for customers:\n  - invalid_count(phone) = 0:\n      valid regex: '^\\+?[0-9]{10,15}$'", "soda", "accuracy", "medium"),
            ("payments", "missing_count(amount)", "checks for payments:\n  - missing_count(amount) = 0", "soda", "completeness", "critical"),
            ("payments", "min(amount)", "checks for payments:\n  - min(amount) >= 0", "soda", "accuracy", "high"),
            ("payments", "row_count", "checks for payments:\n  - row_count > 0", "soda", "completeness", "medium"),
            ("products", "missing_count(name)", "checks for products:\n  - missing_count(name) = 0", "soda", "completeness", "high"),
            ("products", "missing_count(price)", "checks for products:\n  - missing_count(price) = 0", "soda", "completeness", "high"),
            ("products", "min(price)", "checks for products:\n  - min(price) >= 0", "soda", "accuracy", "medium"),
        ]

        rule_ids = {}
        for table, check_name, check_def, engine, dimension, severity in rules_data:
            rule = DQRule(
                connection_id=conn_id,
                table_name=table,
                check_name=check_name,
                check_definition=check_def,
                source="ai",
                engine=engine,
                severity=severity,
                dimension=dimension,
                is_active=True,
            )
            session.add(rule)
            await session.flush()
            rule_ids[(table, check_name)] = rule.id

        # ── DQ Runs (6 scan runs over last 3 days) ──────────────────
        runs_data = [
            (NOW - timedelta(days=3, hours=2), "completed", "soda", 12, 11, 1, 0, 91.7),
            (NOW - timedelta(days=2, hours=14), "completed", "soda", 12, 10, 2, 0, 83.3),
            (NOW - timedelta(days=2, hours=2), "completed", "soda", 12, 11, 1, 0, 91.7),
            (NOW - timedelta(days=1, hours=14), "completed", "soda", 12, 9, 2, 1, 75.0),
            (NOW - timedelta(days=1, hours=2), "completed", "soda", 12, 11, 1, 0, 91.7),
            (NOW - timedelta(hours=6), "completed", "soda", 12, 12, 0, 0, 100.0),
        ]

        run_ids = []
        for started, status, engine, total, p, f, w, score in runs_data:
            run = DQRun(
                connection_id=conn_id,
                status=status,
                engine=engine,
                total_checks=total,
                passed=p,
                failed=f,
                warnings=w,
                health_score=score,
                started_at=started,
                completed_at=started + timedelta(minutes=2),
            )
            session.add(run)
            await session.flush()
            run_ids.append(run.id)

        # ── DQ Issues (5 issues from failed checks) ─────────────────
        issues_data = [
            (run_ids[0], "customers", "duplicate_count(email)", "0", "3", "critical",
             "3 duplicate emails found in customers table", "data_pipeline_delay", 0.87),
            (run_ids[1], "orders", "freshness(order_date)", "< 2d", "3.5d", "high",
             "Order data is 3.5 days stale — ETL pipeline may be delayed", "data_pipeline_delay", 0.92),
            (run_ids[1], "payments", "min(amount)", ">= 0", "-15.50", "high",
             "Negative payment amount detected — possible refund processing error", "business_logic_change", 0.78),
            (run_ids[3], "orders", "freshness(order_date)", "< 2d", "2.8d", "high",
             None, None, None),
            (run_ids[3], "customers", "duplicate_count(email)", "0", "5", "critical",
             "Duplicate email count increased from 3 to 5", "upstream_error", 0.85),
        ]

        for run_id, table, check, expected, actual, severity, rca_sum, rca_pat, rca_conf in issues_data:
            rule_id = rule_ids.get((table, check))
            issue = DQIssue(
                run_id=run_id,
                rule_id=rule_id,
                table_name=table,
                check_name=check,
                expected_value=expected,
                actual_value=actual,
                severity=severity,
                status="open",
                rca_summary=rca_sum,
                rca_pattern=rca_pat,
                rca_confidence=rca_conf,
            )
            session.add(issue)

        # ── Trust Scores (daily scores for 4 tables over 5 days) ─────
        trust_data = {
            "orders":    [(92, 95, 90, 88), (90, 93, 89, 85), (88, 91, 87, 82), (91, 94, 90, 86), (95, 97, 94, 92)],
            "customers": [(85, 88, 80, 90), (82, 85, 76, 88), (80, 83, 74, 86), (84, 87, 79, 89), (88, 91, 84, 91)],
            "payments":  [(94, 96, 93, 92), (92, 94, 91, 90), (90, 92, 88, 88), (93, 95, 92, 91), (96, 98, 95, 94)],
            "products":  [(98, 99, 97, 98), (97, 98, 96, 97), (97, 98, 96, 97), (98, 99, 97, 98), (99, 100, 98, 99)],
        }

        for table, daily_scores in trust_data.items():
            for day_offset, (ov, co, ac, ti) in enumerate(daily_scores):
                ts = TrustScore(
                    connection_id=conn_id,
                    table_name=table,
                    overall=ov,
                    completeness=co,
                    accuracy=ac,
                    timeliness=ti,
                )
                session.add(ts)

        # ── Alerts (3 alerts) ─────────────────────────────────────────
        alerts_data = [
            ("slack", "#data-quality-alerts", "Duplicate emails in customers table increased to 5", "sent"),
            ("email", "lead@datasentinel.dev", "Order data freshness exceeded 2-day threshold", "resolved"),
            ("slack", "#data-quality-alerts", "Negative payment amount detected in payments table", "sent"),
        ]

        for channel, recipient, message, status in alerts_data:
            alert = Alert(
                channel=channel,
                recipient=recipient,
                message=message,
                status=status,
            )
            session.add(alert)

        # ── Audit Trail (5 entries) ───────────────────────────────────
        audit_entries = [
            ("scan", "trigger", "Admin triggered full scan"),
            ("rule", "create", "AI discovery generated 12 rules"),
            ("alert", "resolve", "Resolved freshness alert for orders"),
            ("connection", "create", "Created dev-postgres connection"),
            ("scan", "trigger", "Scheduled scan executed"),
        ]

        for entity_type, action, justification in audit_entries:
            entry = AuditTrail(
                entity_type=entity_type,
                entity_id=str(uuid.uuid4()),
                action=action,
                justification=justification,
            )
            session.add(entry)

        await session.commit()
        print("Demo data seeded:")
        print("  - 12 DQ rules (4 tables)")
        print("  -  6 scan runs (3 days)")
        print("  -  5 issues (2 with RCA)")
        print("  - 20 trust scores (4 tables x 5 days)")
        print("  -  3 alerts")
        print("  -  5 audit trail entries")


if __name__ == "__main__":
    asyncio.run(main())
