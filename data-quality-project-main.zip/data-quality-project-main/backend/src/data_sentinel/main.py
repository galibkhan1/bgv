from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from data_sentinel.config import settings
from data_sentinel.core.exceptions import (
    AIServiceError,
    AuthenticationError,
    AuthorizationError,
    BedrockError,
    ConnectionTestError,
    DataSentinelError,
    HealingError,
    NotFoundError,
    ScanExecutionError,
)

logger = logging.getLogger("data_sentinel")


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        if settings.environment != "development":
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; font-src 'self';"
        )
        return response


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(level=getattr(logging, settings.log_level))
    logger.info("DataSentinel starting up")
    yield
    logger.info("DataSentinel shutting down")
    # Dispose async engine on shutdown
    from data_sentinel.core.database import engine
    await engine.dispose()


def create_app() -> FastAPI:
    app = FastAPI(
        title="DataSentinel",
        description="Data Quality & Observability Platform",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Security headers middleware
    app.add_middleware(SecurityHeadersMiddleware)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    # --- Rate limiting ---
    try:
        from slowapi import _rate_limit_exceeded_handler
        from slowapi.errors import RateLimitExceeded
        from data_sentinel.core.rate_limit import limiter

        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    except ImportError:
        logger.warning("slowapi not installed; rate limiting disabled. Install with: pip install slowapi")

    # --- Exception handlers ---
    @app.exception_handler(NotFoundError)
    async def not_found_handler(request: Request, exc: NotFoundError):
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    @app.exception_handler(AuthenticationError)
    async def auth_error_handler(request: Request, exc: AuthenticationError):
        return JSONResponse(status_code=401, content={"detail": str(exc)})

    @app.exception_handler(AuthorizationError)
    async def authz_error_handler(request: Request, exc: AuthorizationError):
        return JSONResponse(status_code=403, content={"detail": str(exc)})

    @app.exception_handler(ConnectionTestError)
    async def conn_test_handler(request: Request, exc: ConnectionTestError):
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.exception_handler(ScanExecutionError)
    async def scan_error_handler(request: Request, exc: ScanExecutionError):
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    @app.exception_handler(HealingError)
    async def healing_error_handler(request: Request, exc: HealingError):
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.exception_handler(BedrockError)
    async def bedrock_error_handler(request: Request, exc: BedrockError):
        return JSONResponse(status_code=502, content={"detail": str(exc)})

    @app.exception_handler(AIServiceError)
    async def ai_service_error_handler(request: Request, exc: AIServiceError):
        return JSONResponse(status_code=502, content={"detail": str(exc)})

    @app.exception_handler(DataSentinelError)
    async def base_error_handler(request: Request, exc: DataSentinelError):
        return JSONResponse(status_code=500, content={"detail": str(exc)})

    # Import and register routers
    from data_sentinel.api.routers import (
        auth, connections, rules, scans, discovery, rca,
        health_score, audit, healing, alerts,
    )
    app.include_router(auth.router, prefix="/api")
    app.include_router(connections.router, prefix="/api")
    app.include_router(rules.router, prefix="/api")
    app.include_router(scans.router, prefix="/api")
    app.include_router(discovery.router, prefix="/api")
    app.include_router(rca.router, prefix="/api")
    app.include_router(health_score.router, prefix="/api")
    app.include_router(audit.router, prefix="/api")
    app.include_router(healing.router, prefix="/api")
    app.include_router(alerts.router, prefix="/api")

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    return app


app = create_app()
