from __future__ import annotations

import uuid
from sqlalchemy import String, Text, Float, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from data_sentinel.models.base import Base, UUIDPKMixin


class HealingProposal(UUIDPKMixin, Base):
    __tablename__ = "healing_proposals"

    issue_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dq_issues.id"), nullable=False
    )
    proposed_sql: Mapped[str] = mapped_column(Text, nullable=False)
    rollback_sql: Mapped[str] = mapped_column(Text, nullable=False)
    explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
    risk_level: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    affected_rows_estimate: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    approved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    execution_result: Mapped[str | None] = mapped_column(Text, nullable=True)
    actual_rows_affected: Mapped[int | None] = mapped_column(Integer, nullable=True)
