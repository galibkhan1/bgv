from __future__ import annotations

import uuid
from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from data_sentinel.models.base import Base, UUIDPKMixin


class TrustScore(UUIDPKMixin, Base):
    __tablename__ = "trust_scores"

    connection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("data_connections.id"), nullable=False
    )
    table_name: Mapped[str] = mapped_column(String(500), nullable=False, index=True)
    overall: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
    completeness: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
    accuracy: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
    timeliness: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
