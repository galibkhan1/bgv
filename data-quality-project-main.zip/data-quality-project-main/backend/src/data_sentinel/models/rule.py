from __future__ import annotations

import uuid
from sqlalchemy import String, Text, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from data_sentinel.models.base import Base, UUIDPKMixin


class DQRule(UUIDPKMixin, Base):
    __tablename__ = "dq_rules"

    connection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("data_connections.id"), nullable=False
    )
    table_name: Mapped[str] = mapped_column(String(500), nullable=False, index=True)
    check_name: Mapped[str] = mapped_column(String(500), nullable=False)
    check_definition: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(20), nullable=False, default="manual")
    engine: Mapped[str] = mapped_column(String(20), nullable=False, default="soda")
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    dimension: Mapped[str | None] = mapped_column(String(50), nullable=True)
    is_contract: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    versions: Mapped[list[DQRuleVersion]] = relationship(back_populates="rule", lazy="noload")
