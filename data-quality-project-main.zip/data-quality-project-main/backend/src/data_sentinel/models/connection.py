from __future__ import annotations

from sqlalchemy import String, Integer, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column

from data_sentinel.models.base import Base, UUIDPKMixin


class DataConnection(UUIDPKMixin, Base):
    __tablename__ = "data_connections"

    name: Mapped[str] = mapped_column(String(200), unique=True, nullable=False)
    db_type: Mapped[str] = mapped_column(String(50), nullable=False, default="postgresql")
    host: Mapped[str] = mapped_column(String(500), nullable=False)
    port: Mapped[int] = mapped_column(Integer, nullable=False, default=5432)
    database: Mapped[str] = mapped_column(String(200), nullable=False)
    schema_name: Mapped[str] = mapped_column(String(200), nullable=False, default="public")
    username: Mapped[str | None] = mapped_column(String(200), nullable=True)
    encrypted_password: Mapped[str | None] = mapped_column(Text, nullable=True)
    secret_arn: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
