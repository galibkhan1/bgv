from __future__ import annotations

import uuid
from sqlalchemy import String, Text, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from data_sentinel.models.base import Base, UUIDPKMixin


class DQRuleVersion(UUIDPKMixin, Base):
    __tablename__ = "dq_rule_versions"

    rule_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dq_rules.id"), nullable=False
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    check_definition: Mapped[str] = mapped_column(Text, nullable=False)
    change_reason: Mapped[str | None] = mapped_column(String(500), nullable=True)

    rule: Mapped["DQRule"] = relationship(back_populates="versions")
