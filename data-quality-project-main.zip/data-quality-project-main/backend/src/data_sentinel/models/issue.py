from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import String, Text, Float, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from data_sentinel.models.base import Base, UUIDPKMixin


class DQIssue(UUIDPKMixin, Base):
    __tablename__ = "dq_issues"

    run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dq_runs.id"), nullable=False
    )
    rule_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dq_rules.id"), nullable=True
    )
    table_name: Mapped[str] = mapped_column(String(500), nullable=False)
    check_name: Mapped[str] = mapped_column(String(500), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")
    expected_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    actual_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    rca_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    rca_pattern: Mapped[str | None] = mapped_column(String(100), nullable=True)
    rca_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    snoozed_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
