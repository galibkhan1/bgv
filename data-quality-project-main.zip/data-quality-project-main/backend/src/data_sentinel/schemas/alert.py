from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class AlertOut(BaseModel):
    id: uuid.UUID
    issue_id: uuid.UUID | None
    healing_id: uuid.UUID | None
    channel: str
    recipient: str
    message: str
    status: str
    resolution_action: str | None
    escalation_level: int
    resolved_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class AlertResolveRequest(BaseModel):
    action: Literal["approve", "reject", "snooze"]
    justification: str | None = None


class AlertCreateRequest(BaseModel):
    issue_id: uuid.UUID | None = None
    channel: Literal["slack", "email"] = "slack"
    recipient: str
    message: str
