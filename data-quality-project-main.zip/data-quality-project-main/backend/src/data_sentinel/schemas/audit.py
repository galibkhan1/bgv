from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel


class AuditTrailOut(BaseModel):
    id: uuid.UUID
    entity_type: str
    entity_id: str
    action: str
    user_id: uuid.UUID | None
    old_values: dict | None
    new_values: dict | None
    justification: str | None
    ip_address: str | None
    created_at: datetime

    model_config = {"from_attributes": True}
