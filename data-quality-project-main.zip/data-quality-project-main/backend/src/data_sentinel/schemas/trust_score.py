from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel


class TrustScoreOut(BaseModel):
    id: uuid.UUID
    connection_id: uuid.UUID
    table_name: str
    overall: float
    completeness: float
    accuracy: float
    timeliness: float
    created_at: datetime

    model_config = {"from_attributes": True}
