from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class ConnectionCreate(BaseModel):
    name: str
    db_type: Literal["postgresql", "mysql", "snowflake", "bigquery", "redshift"] = "postgresql"
    host: str
    port: int = 5432
    database: str
    schema_name: str = "public"
    username: str | None = None
    password: str | None = None
    secret_arn: str | None = None


class ConnectionUpdate(BaseModel):
    name: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    schema_name: str | None = None
    username: str | None = None
    password: str | None = None
    secret_arn: str | None = None
    is_active: bool | None = None


class ConnectionOut(BaseModel):
    id: uuid.UUID
    name: str
    db_type: str
    host: str
    port: int
    database: str
    schema_name: str
    username: str | None
    secret_arn: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
