from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class ScanTriggerRequest(BaseModel):
    connection_id: uuid.UUID
    table_names: list[str] | None = None
    engine: Literal["soda", "ge"] = "soda"


class RunOut(BaseModel):
    id: uuid.UUID
    connection_id: uuid.UUID
    triggered_by: uuid.UUID | None
    status: str
    engine: str
    total_checks: int
    passed: int
    failed: int
    warnings: int
    health_score: float | None
    error_message: str | None
    started_at: datetime | None
    completed_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class IssueOut(BaseModel):
    id: uuid.UUID
    run_id: uuid.UUID
    rule_id: uuid.UUID | None
    table_name: str
    check_name: str
    severity: str
    status: str
    expected_value: str | None
    actual_value: str | None
    rca_summary: str | None
    rca_pattern: str | None
    rca_confidence: float | None
    snoozed_until: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}
