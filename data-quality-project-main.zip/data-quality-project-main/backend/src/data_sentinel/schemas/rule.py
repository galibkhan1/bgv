from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class RuleCreate(BaseModel):
    connection_id: uuid.UUID
    table_name: str
    check_name: str
    check_definition: str
    source: Literal["manual", "ai", "contract"] = "manual"
    engine: Literal["soda", "ge"] = "soda"
    severity: Literal["critical", "high", "medium", "low", "info"] = "medium"
    dimension: str | None = None
    is_contract: bool = False


class RuleUpdate(BaseModel):
    check_name: str | None = None
    check_definition: str | None = None
    severity: Literal["critical", "high", "medium", "low", "info"] | None = None
    dimension: str | None = None
    is_contract: bool | None = None
    is_active: bool | None = None
    change_reason: str | None = None


class RuleOut(BaseModel):
    id: uuid.UUID
    connection_id: uuid.UUID
    table_name: str
    check_name: str
    check_definition: str
    source: str
    engine: str
    severity: str
    dimension: str | None
    is_contract: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class RuleVersionOut(BaseModel):
    id: uuid.UUID
    rule_id: uuid.UUID
    version: int
    check_definition: str
    change_reason: str | None
    created_at: datetime

    model_config = {"from_attributes": True}
