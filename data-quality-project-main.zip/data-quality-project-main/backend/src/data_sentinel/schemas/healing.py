from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel


class HealingProposalOut(BaseModel):
    id: uuid.UUID
    issue_id: uuid.UUID
    proposed_sql: str
    rollback_sql: str
    explanation: str | None
    risk_level: str
    confidence: float
    affected_rows_estimate: int
    status: str
    approved_by: uuid.UUID | None
    execution_result: str | None
    actual_rows_affected: int | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class HealingProposeRequest(BaseModel):
    issue_id: uuid.UUID


class HealingExecuteRequest(BaseModel):
    connection_id: uuid.UUID
