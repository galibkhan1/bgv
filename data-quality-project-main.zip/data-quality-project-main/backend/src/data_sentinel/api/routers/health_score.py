from __future__ import annotations

import re
import uuid

from fastapi import APIRouter, HTTPException, Path, Query
from sqlalchemy import select

from data_sentinel.api.deps import CurrentUser, DbSession
from data_sentinel.models.trust_score import TrustScore
from data_sentinel.schemas.trust_score import TrustScoreOut
from data_sentinel.services.trust_score_engine import compute_trust_score

router = APIRouter(prefix="/health-score", tags=["health-score"])

_VALID_TABLE_NAME = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_.]*$')


@router.get("", response_model=list[TrustScoreOut])
async def list_trust_scores(
    session: DbSession,
    user: CurrentUser,
    connection_id: uuid.UUID | None = None,
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
):
    query = select(TrustScore).order_by(TrustScore.created_at.desc())
    if connection_id:
        query = query.where(TrustScore.connection_id == connection_id)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()


@router.get("/{table_name}", response_model=list[TrustScoreOut])
async def get_table_trust_history(
    session: DbSession,
    user: CurrentUser,
    table_name: str = Path(..., pattern=r'^[a-zA-Z_][a-zA-Z0-9_.]*$'),
    limit: int = Query(default=30, le=100),
):
    result = await session.execute(
        select(TrustScore)
        .where(TrustScore.table_name == table_name)
        .order_by(TrustScore.created_at.desc())
        .limit(limit)
    )
    return result.scalars().all()


@router.post("/compute/{connection_id}/{table_name}", response_model=TrustScoreOut)
async def compute_score(
    connection_id: uuid.UUID,
    session: DbSession,
    user: CurrentUser,
    table_name: str = Path(..., pattern=r'^[a-zA-Z_][a-zA-Z0-9_.]*$'),
):
    score = await compute_trust_score(session, connection_id, table_name)
    return score
