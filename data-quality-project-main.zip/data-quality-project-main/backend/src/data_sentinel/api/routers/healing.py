from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import select

from data_sentinel.api.deps import AdminUser, CurrentUser, DbSession
from data_sentinel.models.connection import DataConnection
from data_sentinel.models.healing_proposal import HealingProposal
from data_sentinel.schemas.healing import HealingExecuteRequest, HealingProposalOut, HealingProposeRequest
from data_sentinel.services.audit_service import log_audit
from data_sentinel.services.healing_engine import execute_healing, propose_healing

router = APIRouter(prefix="/healing", tags=["healing"])


@router.get("", response_model=list[HealingProposalOut])
async def list_proposals(
    session: DbSession,
    user: CurrentUser,
    status: str | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    query = select(HealingProposal).order_by(HealingProposal.created_at.desc())
    if status:
        query = query.where(HealingProposal.status == status)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()


@router.post("/propose", response_model=HealingProposalOut)
async def propose(body: HealingProposeRequest, session: DbSession, user: CurrentUser):
    proposal = await propose_healing(session, body.issue_id)
    return proposal


@router.post("/{proposal_id}/approve", response_model=HealingProposalOut)
async def approve(proposal_id: uuid.UUID, session: DbSession, user: AdminUser):
    result = await session.execute(
        select(HealingProposal).where(HealingProposal.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    if proposal.status != "pending":
        raise HTTPException(status_code=400, detail=f"Cannot approve proposal with status: {proposal.status}")

    proposal.status = "approved"
    proposal.approved_by = user.id
    await session.commit()
    await session.refresh(proposal)

    await log_audit(
        session, "healing_proposal", str(proposal.id), "approve", user_id=user.id,
    )
    return proposal


@router.post("/{proposal_id}/reject", response_model=HealingProposalOut)
async def reject(proposal_id: uuid.UUID, session: DbSession, user: AdminUser):
    result = await session.execute(
        select(HealingProposal).where(HealingProposal.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")

    proposal.status = "rejected"
    await session.commit()
    await session.refresh(proposal)

    await log_audit(
        session, "healing_proposal", str(proposal.id), "reject", user_id=user.id,
    )
    return proposal


@router.post("/{proposal_id}/execute", response_model=HealingProposalOut)
async def execute(
    proposal_id: uuid.UUID,
    body: HealingExecuteRequest,
    session: DbSession,
    user: AdminUser,
):
    conn_result = await session.execute(
        select(DataConnection).where(DataConnection.id == body.connection_id)
    )
    connection = conn_result.scalar_one_or_none()
    if not connection:
        raise HTTPException(status_code=404, detail="Connection not found")

    proposal = await execute_healing(session, proposal_id, user.id, connection)
    return proposal
