from __future__ import annotations

import uuid

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from sqlalchemy import select

from data_sentinel.api.deps import CurrentUser, DbSession
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.run import DQRun
from data_sentinel.schemas.scan import IssueOut, RunOut, ScanTriggerRequest
from data_sentinel.services.scan_engine import trigger_scan

router = APIRouter(prefix="/scans", tags=["scans"])


@router.post("/trigger", response_model=RunOut, status_code=202)
async def trigger(
    body: ScanTriggerRequest,
    session: DbSession,
    user: CurrentUser,
    background_tasks: BackgroundTasks,
):
    """Trigger a scan. Returns immediately with run record; scan executes in background."""
    run = await trigger_scan(
        session=session,
        connection_id=body.connection_id,
        triggered_by=user.id,
        table_names=body.table_names,
        engine=body.engine,
        background_tasks=background_tasks,
    )
    return run


@router.get("/history", response_model=list[RunOut])
async def scan_history(
    session: DbSession,
    user: CurrentUser,
    connection_id: uuid.UUID | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    query = select(DQRun).order_by(DQRun.created_at.desc())
    if connection_id:
        query = query.where(DQRun.connection_id == connection_id)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()


# Static path /issues/all MUST come before /{run_id} to avoid route conflicts
@router.get("/issues/all", response_model=list[IssueOut])
async def list_all_issues(
    session: DbSession,
    user: CurrentUser,
    status: str | None = None,
    severity: str | None = None,
    table_name: str | None = None,
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
):
    query = select(DQIssue).order_by(DQIssue.created_at.desc())
    if status:
        query = query.where(DQIssue.status == status)
    if severity:
        query = query.where(DQIssue.severity == severity)
    if table_name:
        query = query.where(DQIssue.table_name == table_name)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()


@router.get("/{run_id}", response_model=RunOut)
async def get_run(run_id: uuid.UUID, session: DbSession, user: CurrentUser):
    result = await session.execute(select(DQRun).where(DQRun.id == run_id))
    run = result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run


@router.get("/{run_id}/issues", response_model=list[IssueOut])
async def get_run_issues(run_id: uuid.UUID, session: DbSession, user: CurrentUser):
    result = await session.execute(
        select(DQIssue).where(DQIssue.run_id == run_id).order_by(DQIssue.created_at.desc())
    )
    return result.scalars().all()
