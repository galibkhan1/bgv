from __future__ import annotations

from fastapi import APIRouter, Query
from sqlalchemy import select

from data_sentinel.api.deps import AdminUser, DbSession
from data_sentinel.models.audit_trail import AuditTrail
from data_sentinel.schemas.audit import AuditTrailOut

router = APIRouter(prefix="/audit-trail", tags=["audit"])


@router.get("", response_model=list[AuditTrailOut])
async def list_audit_entries(
    session: DbSession,
    user: AdminUser,
    entity_type: str | None = None,
    action: str | None = None,
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
):
    query = select(AuditTrail).order_by(AuditTrail.created_at.desc())
    if entity_type:
        query = query.where(AuditTrail.entity_type == entity_type)
    if action:
        query = query.where(AuditTrail.action == action)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()
