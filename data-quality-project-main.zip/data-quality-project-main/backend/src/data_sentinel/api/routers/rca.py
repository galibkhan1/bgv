from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from data_sentinel.api.deps import CurrentUser, DbSession
from data_sentinel.services.rca_engine import analyze_issue

router = APIRouter(prefix="/rca", tags=["rca"])


class RCAResponse(BaseModel):
    issue_id: str
    summary: str
    pattern: str
    confidence: float


@router.post("/analyze/{issue_id}", response_model=RCAResponse)
async def run_rca(issue_id: uuid.UUID, session: DbSession, user: CurrentUser):
    try:
        result = await analyze_issue(session, issue_id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
