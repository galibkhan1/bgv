from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select, update

from data_sentinel.api.deps import CurrentUser, DbSession
from data_sentinel.models.alert import Alert
from data_sentinel.models.issue import DQIssue
from data_sentinel.schemas.alert import AlertCreateRequest, AlertOut, AlertResolveRequest
from data_sentinel.services.audit_service import log_audit

router = APIRouter(prefix="/alerts", tags=["alerts"])

# Valid resolution actions
VALID_ACTIONS = {"approve", "reject", "snooze"}


@router.get("", response_model=list[AlertOut])
async def list_alerts(
    session: DbSession,
    user: CurrentUser,
    status: str | None = None,
    channel: str | None = None,
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
):
    query = select(Alert).order_by(Alert.created_at.desc())
    if status:
        query = query.where(Alert.status == status)
    if channel:
        query = query.where(Alert.channel == channel)
    query = query.offset(offset).limit(limit)
    result = await session.execute(query)
    return result.scalars().all()


@router.post("", response_model=AlertOut, status_code=201)
async def create_alert(body: AlertCreateRequest, session: DbSession, user: CurrentUser):
    alert = Alert(
        issue_id=body.issue_id,
        channel=body.channel,
        recipient=body.recipient,
        message=body.message,
        status="sent",
        escalation_level=0,
    )
    session.add(alert)
    await session.commit()
    await session.refresh(alert)

    await log_audit(
        session, "alert", str(alert.id), "create", user_id=user.id,
    )
    return alert


@router.post("/{alert_id}/resolve", response_model=AlertOut)
async def resolve_alert(
    alert_id: uuid.UUID,
    body: AlertResolveRequest,
    session: DbSession,
    user: CurrentUser,
):
    result = await session.execute(select(Alert).where(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    alert.status = "resolved"
    alert.resolution_action = body.action
    alert.resolved_at = datetime.now(timezone.utc)

    # If action is snooze and there's an associated issue, snooze it
    if body.action == "snooze" and alert.issue_id:
        issue_result = await session.execute(select(DQIssue).where(DQIssue.id == alert.issue_id))
        issue = issue_result.scalar_one_or_none()
        if issue:
            issue.status = "snoozed"
            issue.snoozed_until = datetime.now(timezone.utc) + timedelta(hours=24)

    await session.commit()
    await session.refresh(alert)

    await log_audit(
        session, "alert", str(alert.id), body.action,
        user_id=user.id, justification=body.justification,
    )
    return alert


@router.get("/resolve/{token}")
async def resolve_by_token(
    token: uuid.UUID,
    session: DbSession,
    action: str = Query(...),
):
    """Resolve an alert via resolution token (from Slack/Email links).

    Note: This endpoint is intentionally unauthenticated -- tokens are
    single-use secrets shared via Slack/Email.
    """
    if action not in VALID_ACTIONS:
        raise HTTPException(status_code=400, detail=f"Invalid action. Must be one of: {', '.join(VALID_ACTIONS)}")

    # Atomic resolution: UPDATE only if not already resolved AND not expired (48h)
    expiry_cutoff = datetime.now(timezone.utc) - timedelta(hours=48)
    stmt = (
        update(Alert)
        .where(
            Alert.resolution_token == token,
            Alert.status != "resolved",
            Alert.created_at > expiry_cutoff,
        )
        .values(
            status="resolved",
            resolution_action=action,
            resolved_at=datetime.now(timezone.utc),
        )
        .returning(Alert.id, Alert.issue_id)
    )
    result = await session.execute(stmt)
    row = result.first()

    if not row:
        # Determine why: invalid token, already resolved, or expired
        check = await session.execute(select(Alert).where(Alert.resolution_token == token))
        existing = check.scalar_one_or_none()
        if not existing:
            raise HTTPException(status_code=404, detail="Invalid resolution token")
        if existing.status == "resolved":
            return {"message": "Alert already resolved", "action": existing.resolution_action}
        if (datetime.now(timezone.utc) - existing.created_at).total_seconds() > 48 * 3600:
            raise HTTPException(status_code=410, detail="Resolution token has expired")
        raise HTTPException(status_code=404, detail="Invalid resolution token")

    alert_id, issue_id = row

    # Handle snooze on associated issue
    if action == "snooze" and issue_id:
        issue_result = await session.execute(select(DQIssue).where(DQIssue.id == issue_id))
        issue = issue_result.scalar_one_or_none()
        if issue:
            issue.status = "snoozed"
            issue.snoozed_until = datetime.now(timezone.utc) + timedelta(hours=24)

    await session.commit()

    return {"message": f"Alert resolved with action: {action}", "alert_id": str(alert_id)}
