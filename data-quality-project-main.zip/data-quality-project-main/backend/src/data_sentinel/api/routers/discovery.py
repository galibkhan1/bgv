from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from data_sentinel.api.deps import CurrentUser, DbSession
from data_sentinel.models.connection import DataConnection
from data_sentinel.models.discovery_run import DiscoveryRun
from data_sentinel.schemas.rule import RuleOut
from data_sentinel.services.connection_service import get_connection_password
from data_sentinel.services.discovery_engine import discover_rules_for_table, list_tables_for_connection

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/discovery", tags=["discovery"])


class DiscoveryRequest(BaseModel):
    connection_id: uuid.UUID
    table_names: list[str] | None = None


class DiscoveryResponse(BaseModel):
    id: uuid.UUID
    connection_id: uuid.UUID
    tables_processed: int
    rules_generated: int
    rules: list[RuleOut]
    errors: list[dict] | None = None
    status: str


class DiscoveryRunOut(BaseModel):
    id: uuid.UUID
    connection_id: uuid.UUID
    status: str
    tables_processed: int
    rules_generated: int
    tables_requested: str | None
    error_message: str | None
    errors_json: list[dict] | None
    started_at: datetime | None
    completed_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


@router.post("/run", response_model=DiscoveryResponse)
async def run_discovery(body: DiscoveryRequest, session: DbSession, user: CurrentUser):
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == body.connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")

    password = await get_connection_password(conn)

    if body.table_names:
        tables = body.table_names
    else:
        tables = await list_tables_for_connection(conn, password)

    # Create discovery run record
    run = DiscoveryRun(
        connection_id=conn.id,
        triggered_by=user.id,
        status="running",
        tables_requested=", ".join(tables) if body.table_names else None,
        started_at=datetime.now(timezone.utc),
    )
    session.add(run)
    await session.commit()
    await session.refresh(run)

    all_rules = []
    errors = []
    for table in tables:
        try:
            rules = await discover_rules_for_table(session, conn, table)
            all_rules.extend(rules)
        except Exception as e:
            logger.error(f"Discovery failed for table {table}: {e}")
            errors.append({"table": table, "error": str(e)})

    # Update discovery run with results
    run.status = "completed" if not errors else ("partial" if all_rules else "failed")
    run.tables_processed = len(tables)
    run.rules_generated = len(all_rules)
    run.errors_json = errors if errors else None
    run.error_message = "; ".join(e["error"] for e in errors) if errors else None
    run.completed_at = datetime.now(timezone.utc)
    await session.commit()

    return DiscoveryResponse(
        id=run.id,
        connection_id=conn.id,
        tables_processed=len(tables),
        rules_generated=len(all_rules),
        rules=[RuleOut.model_validate(r) for r in all_rules],
        errors=errors if errors else None,
        status=run.status,
    )


@router.get("/history", response_model=list[DiscoveryRunOut])
async def list_discovery_runs(
    session: DbSession,
    user: CurrentUser,
    connection_id: uuid.UUID | None = None,
    limit: int = 20,
):
    query = select(DiscoveryRun).order_by(DiscoveryRun.created_at.desc()).limit(limit)
    if connection_id:
        query = query.where(DiscoveryRun.connection_id == connection_id)
    result = await session.execute(query)
    return result.scalars().all()
