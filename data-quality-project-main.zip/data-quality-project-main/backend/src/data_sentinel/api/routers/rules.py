from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from data_sentinel.api.deps import CurrentUser, DbSession, LeadOrAdminUser
from data_sentinel.models.rule import DQRule
from data_sentinel.models.rule_version import DQRuleVersion
from data_sentinel.schemas.rule import RuleCreate, RuleOut, RuleUpdate, RuleVersionOut
from data_sentinel.services.audit_service import log_audit

router = APIRouter(prefix="/rules", tags=["rules"])


@router.get("", response_model=list[RuleOut])
async def list_rules(
    session: DbSession,
    user: CurrentUser,
    connection_id: uuid.UUID | None = None,
    table_name: str | None = None,
    is_contract: bool | None = None,
    active_only: bool = True,
):
    query = select(DQRule)
    if active_only:
        query = query.where(DQRule.is_active.is_(True))
    if connection_id:
        query = query.where(DQRule.connection_id == connection_id)
    if table_name:
        query = query.where(DQRule.table_name == table_name)
    if is_contract is not None:
        query = query.where(DQRule.is_contract == is_contract)
    query = query.order_by(DQRule.table_name, DQRule.check_name)
    result = await session.execute(query)
    return result.scalars().all()


@router.post("", response_model=RuleOut, status_code=status.HTTP_201_CREATED)
async def create_rule(body: RuleCreate, session: DbSession, user: LeadOrAdminUser):
    rule = DQRule(**body.model_dump())
    session.add(rule)
    await session.commit()
    await session.refresh(rule)

    # Create initial version
    version = DQRuleVersion(
        rule_id=rule.id,
        version=1,
        check_definition=rule.check_definition,
        change_reason="Initial creation",
    )
    session.add(version)
    await session.commit()

    await log_audit(
        session, "rule", str(rule.id), "create",
        user_id=user.id, new_values={"check_name": rule.check_name, "table": rule.table_name},
    )
    await session.commit()
    return rule


@router.get("/contracts", response_model=list[RuleOut])
async def list_contracts(session: DbSession, user: CurrentUser):
    result = await session.execute(
        select(DQRule).where(DQRule.is_contract.is_(True), DQRule.is_active.is_(True))
    )
    return result.scalars().all()


@router.get("/{rule_id}", response_model=RuleOut)
async def get_rule(rule_id: uuid.UUID, session: DbSession, user: CurrentUser):
    result = await session.execute(select(DQRule).where(DQRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    return rule


@router.patch("/{rule_id}", response_model=RuleOut)
async def update_rule(rule_id: uuid.UUID, body: RuleUpdate, session: DbSession, user: LeadOrAdminUser):
    result = await session.execute(select(DQRule).where(DQRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")

    old_values = {"check_name": rule.check_name, "check_definition": rule.check_definition}
    update_data = body.model_dump(exclude_unset=True)
    change_reason = update_data.pop("change_reason", None)

    # If check_definition changed, create a new version
    if "check_definition" in update_data and update_data["check_definition"] != rule.check_definition:
        ver_result = await session.execute(
            select(DQRuleVersion)
            .where(DQRuleVersion.rule_id == rule_id)
            .order_by(DQRuleVersion.version.desc())
            .limit(1)
        )
        latest = ver_result.scalar_one_or_none()
        next_version = (latest.version + 1) if latest else 1

        version = DQRuleVersion(
            rule_id=rule_id,
            version=next_version,
            check_definition=update_data["check_definition"],
            change_reason=change_reason,
        )
        session.add(version)

    for key, value in update_data.items():
        setattr(rule, key, value)

    await session.commit()
    await session.refresh(rule)

    await log_audit(
        session, "rule", str(rule.id), "update",
        user_id=user.id, old_values=old_values,
        new_values={"check_name": rule.check_name, "check_definition": rule.check_definition},
    )
    await session.commit()
    return rule


@router.delete("/{rule_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_rule(rule_id: uuid.UUID, session: DbSession, user: LeadOrAdminUser):
    result = await session.execute(select(DQRule).where(DQRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    rule.is_active = False
    await session.commit()

    await log_audit(
        session, "rule", str(rule.id), "delete", user_id=user.id,
    )
    await session.commit()


@router.get("/{rule_id}/versions", response_model=list[RuleVersionOut])
async def list_rule_versions(rule_id: uuid.UUID, session: DbSession, user: CurrentUser):
    result = await session.execute(
        select(DQRuleVersion)
        .where(DQRuleVersion.rule_id == rule_id)
        .order_by(DQRuleVersion.version.desc())
    )
    return result.scalars().all()
