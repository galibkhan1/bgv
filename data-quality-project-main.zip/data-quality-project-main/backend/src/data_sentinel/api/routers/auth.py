from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Query, Request, status
from sqlalchemy import select

from data_sentinel.api.deps import AdminUser, CurrentUser, DbSession
from data_sentinel.core.security import create_access_token, hash_password, verify_password
from data_sentinel.models.user import User
from data_sentinel.schemas.auth import LoginRequest, TokenResponse, UserCreate, UserOut
from data_sentinel.core.rate_limit import limiter
from data_sentinel.services.audit_service import log_audit

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])


def _get_client_ip(request: Request) -> str:
    """Extract client IP. Uses request.client.host (direct connection) for safety.

    X-Forwarded-For is not trusted here because there is no reverse proxy
    trust list configured. If deployed behind a trusted proxy, configure
    Starlette's ProxyHeadersMiddleware instead.
    """
    return request.client.host if request.client else "unknown"


@router.post("/login", response_model=TokenResponse)
@limiter.limit("30/minute")
async def login(body: LoginRequest, session: DbSession, request: Request):
    ip = _get_client_ip(request)
    result = await session.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()
    if not user or not verify_password(body.password, user.hashed_password):
        # Log failed login attempt
        await log_audit(
            session, "auth", body.email, "login_failed",
            ip_address=ip,
        )
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account disabled")
    token = create_access_token({"sub": str(user.id), "role": user.role})

    # Log successful login
    await log_audit(
        session, "auth", str(user.id), "login",
        user_id=user.id, ip_address=ip,
    )
    await session.commit()

    return TokenResponse(access_token=token)


@router.get("/me", response_model=UserOut)
async def me(user: CurrentUser):
    return user


@router.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(body: UserCreate, session: DbSession, user: AdminUser, request: Request):
    """Admin-only user creation."""
    existing = await session.execute(select(User).where(User.email == body.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="User with this email already exists")

    new_user = User(
        email=body.email,
        full_name=body.full_name,
        hashed_password=hash_password(body.password),
        role=body.role,
    )
    session.add(new_user)
    await session.commit()
    await session.refresh(new_user)

    await log_audit(
        session, "user", str(new_user.id), "create",
        user_id=user.id, new_values={"email": new_user.email, "role": new_user.role},
        ip_address=_get_client_ip(request),
    )
    await session.commit()
    return new_user


@router.get("/users", response_model=list[UserOut])
async def list_users(
    session: DbSession,
    user: AdminUser,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    """Admin-only user listing."""
    result = await session.execute(
        select(User).order_by(User.created_at.desc()).offset(offset).limit(limit)
    )
    return result.scalars().all()
