from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select

from data_sentinel.api.deps import AdminUser, CurrentUser, DbSession
from data_sentinel.core.encryption import encrypt_password
from data_sentinel.models.connection import DataConnection
from data_sentinel.schemas.connection import ConnectionCreate, ConnectionOut, ConnectionUpdate
from data_sentinel.services.audit_service import log_audit
from data_sentinel.services.connection_service import test_connection

router = APIRouter(prefix="/connections", tags=["connections"])


@router.get("", response_model=list[ConnectionOut])
async def list_connections(user: CurrentUser, session: DbSession):
    result = await session.execute(
        select(DataConnection).where(DataConnection.is_active.is_(True)).order_by(DataConnection.name)
    )
    return result.scalars().all()


@router.post("", response_model=ConnectionOut, status_code=status.HTTP_201_CREATED)
async def create_connection(body: ConnectionCreate, user: AdminUser, session: DbSession):
    encrypted_pw = encrypt_password(body.password) if body.password else None
    conn = DataConnection(
        name=body.name,
        db_type=body.db_type,
        host=body.host,
        port=body.port,
        database=body.database,
        schema_name=body.schema_name,
        username=body.username,
        encrypted_password=encrypted_pw,
        secret_arn=body.secret_arn,
    )
    session.add(conn)
    await session.commit()
    await session.refresh(conn)

    await log_audit(
        session, "connection", str(conn.id), "create",
        user_id=user.id, new_values={"name": conn.name, "host": conn.host},
    )
    return conn


@router.get("/{connection_id}", response_model=ConnectionOut)
async def get_connection(connection_id: uuid.UUID, user: CurrentUser, session: DbSession):
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


@router.patch("/{connection_id}", response_model=ConnectionOut)
async def update_connection(
    connection_id: uuid.UUID, body: ConnectionUpdate, user: AdminUser, session: DbSession
):
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")

    old_values = {"name": conn.name, "host": conn.host}
    update_data = body.model_dump(exclude_unset=True)
    if "password" in update_data:
        pw = update_data.pop("password")
        update_data["encrypted_password"] = encrypt_password(pw) if pw else None
    for key, value in update_data.items():
        setattr(conn, key, value)
    await session.commit()
    await session.refresh(conn)

    await log_audit(
        session, "connection", str(conn.id), "update",
        user_id=user.id, old_values=old_values, new_values={"name": conn.name, "host": conn.host},
    )
    return conn


@router.delete("/{connection_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_connection(connection_id: uuid.UUID, user: AdminUser, session: DbSession):
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn.is_active = False
    await session.commit()

    await log_audit(
        session, "connection", str(conn.id), "delete", user_id=user.id,
    )


@router.post("/{connection_id}/test")
async def test_conn(connection_id: uuid.UUID, user: CurrentUser, session: DbSession):
    """Test database connectivity (#14)."""
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    try:
        success = await test_connection(conn)
        return {"success": success, "message": "Connection successful"}
    except Exception as e:
        return {"success": False, "message": str(e)}
