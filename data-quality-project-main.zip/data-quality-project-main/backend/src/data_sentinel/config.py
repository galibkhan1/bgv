from __future__ import annotations

import json
import logging
import warnings

from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Database
    database_url: str = "postgresql+asyncpg://datasentinel:changeme@localhost:5432/datasentinel"

    # JWT
    jwt_secret_key: str = "change-this-to-a-random-secret"
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 60

    # Encryption (Fernet key — generate via: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
    encryption_key: str = ""

    # Environment
    environment: str = "development"

    # AWS (legacy — kept for reference, not used when Ollama Cloud is configured)
    aws_region: str = "us-east-1"
    aws_bedrock_model_id: str = "us.anthropic.claude-sonnet-4-20250514"
    aws_access_key_id: str | None = None
    aws_secret_access_key: str | None = None

    # Ollama Cloud (primary AI provider)
    ollama_cloud_base_url: str = "https://ollama.com"
    ollama_cloud_api_key: str = ""
    ollama_cloud_model: str = "gpt-oss:120b-cloud"

    # Slack
    slack_bot_token: str | None = None
    slack_default_channel: str = "#data-quality-alerts"

    # AWS SES
    ses_sender_email: str | None = None
    ses_region: str = "us-east-1"

    # App
    app_base_url: str = "http://localhost:8000"
    cors_origins: str = '["http://localhost:5173"]'
    log_level: str = "INFO"

    def model_post_init(self, __context):
        # Fail in production if default JWT secret is used
        if self.jwt_secret_key == "change-this-to-a-random-secret":
            if self.environment != "development":
                raise RuntimeError(
                    "SECURITY: JWT_SECRET_KEY must be set to a secure value in production. "
                    "Set JWT_SECRET_KEY in .env"
                )
            warnings.warn(
                "SECURITY WARNING: Using default JWT secret. Set JWT_SECRET_KEY in .env",
                stacklevel=2,
            )
        # Fail in production if default DB password is used
        if "changeme" in self.database_url and self.environment != "development":
            raise RuntimeError(
                "SECURITY: DATABASE_URL contains default password 'changeme'. "
                "Change it in .env for production."
            )
        _KNOWN_DEV_KEY = "RxvZJAUJRo0OysRix-5bx_Jfh13BX6l5X_Ab7CPDSQk="
        # Require ENCRYPTION_KEY in all environments
        if not self.encryption_key or self.encryption_key == _KNOWN_DEV_KEY:
            if self.environment != "development":
                raise RuntimeError(
                    "SECURITY: ENCRYPTION_KEY must be set to a unique random value in production. "
                    "Generate via: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
                )
            # Stable dev-only key (NOT for production). Deterministic so saved
            # connection passwords survive restarts during local development.
            self.encryption_key = "RxvZJAUJRo0OysRix-5bx_Jfh13BX6l5X_Ab7CPDSQk="
            warnings.warn(
                "SECURITY WARNING: Using default dev ENCRYPTION_KEY. Set ENCRYPTION_KEY in .env for production.",
                stacklevel=2,
            )

    @property
    def cors_origins_list(self) -> list[str]:
        try:
            return json.loads(self.cors_origins)
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"Invalid CORS_ORIGINS JSON, falling back to single origin")
            return [self.cors_origins.strip()] if self.cors_origins else []

    @property
    def sync_database_url(self) -> str:
        return self.database_url.replace("+asyncpg", "")


settings = Settings()
