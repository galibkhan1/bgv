"""Trust score computation: 0-100 per-table scoring.

overall = 0.40 * completeness + 0.40 * accuracy + 0.20 * timeliness
"""
from __future__ import annotations

import logging
import uuid
from datetime import date

from sqlalchemy import select, and_
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.models.rule import DQRule
from data_sentinel.models.run import DQRun
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.trust_score import TrustScore
from shared_utils.constants import TRUST_WEIGHT_COMPLETENESS, TRUST_WEIGHT_ACCURACY, TRUST_WEIGHT_TIMELINESS

logger = logging.getLogger(__name__)

# Keywords for dimension classification
COMPLETENESS_KEYWORDS = {"missing_count", "missing_percent", "row_count", "missing"}
ACCURACY_KEYWORDS = {"invalid_count", "duplicate_count", "failed_rows", "invalid", "duplicate", "valid"}
TIMELINESS_KEYWORDS = {"freshness", "stale", "max_age"}


def classify_dimension(check_definition: str, dimension_hint: str | None) -> str:
    if dimension_hint:
        return dimension_hint
    lower = check_definition.lower()
    for kw in TIMELINESS_KEYWORDS:
        if kw in lower:
            return "timeliness"
    for kw in COMPLETENESS_KEYWORDS:
        if kw in lower:
            return "completeness"
    for kw in ACCURACY_KEYWORDS:
        if kw in lower:
            return "accuracy"
    return "accuracy"


async def compute_trust_score(
    session: AsyncSession,
    connection_id: uuid.UUID,
    table_name: str,
) -> TrustScore:
    """Compute and store/upsert trust score for a specific table."""
    # Get latest run for this connection
    run_result = await session.execute(
        select(DQRun)
        .where(DQRun.connection_id == connection_id, DQRun.status == "completed")
        .order_by(DQRun.completed_at.desc())
        .limit(1)
    )
    latest_run = run_result.scalar_one_or_none()

    if not latest_run:
        # No runs yet -- default to 100
        return await _upsert_score(session, connection_id, table_name, 100.0, 100.0, 100.0, 100.0)

    # Get rules for this table
    rules_result = await session.execute(
        select(DQRule).where(
            DQRule.connection_id == connection_id,
            DQRule.table_name == table_name,
            DQRule.is_active.is_(True),
        )
    )
    rules = list(rules_result.scalars().all())

    # Get issues from latest run for this table
    issues_result = await session.execute(
        select(DQIssue).where(
            DQIssue.run_id == latest_run.id,
            DQIssue.table_name == table_name,
        )
    )
    failed_rule_ids = {i.rule_id for i in issues_result.scalars().all() if i.rule_id}

    # Group rules by dimension and compute pass rates
    dimension_counts = {"completeness": [0, 0], "accuracy": [0, 0], "timeliness": [0, 0]}

    for rule in rules:
        dim = classify_dimension(rule.check_definition, rule.dimension)
        if dim not in dimension_counts:
            dim = "accuracy"
        dimension_counts[dim][1] += 1  # total
        if rule.id not in failed_rule_ids:
            dimension_counts[dim][0] += 1  # passed

    def _pct(passed: int, total: int) -> float:
        return (passed / total * 100.0) if total > 0 else 100.0

    completeness = _pct(*dimension_counts["completeness"])
    accuracy = _pct(*dimension_counts["accuracy"])
    timeliness = _pct(*dimension_counts["timeliness"])
    overall = round(
        TRUST_WEIGHT_COMPLETENESS * completeness
        + TRUST_WEIGHT_ACCURACY * accuracy
        + TRUST_WEIGHT_TIMELINESS * timeliness,
        2,
    )

    return await _upsert_score(
        session, connection_id, table_name,
        overall, round(completeness, 2), round(accuracy, 2), round(timeliness, 2),
    )


async def _upsert_score(
    session: AsyncSession,
    connection_id: uuid.UUID,
    table_name: str,
    overall: float,
    completeness: float,
    accuracy: float,
    timeliness: float,
) -> TrustScore:
    """Upsert trust score -- one row per table per day. Uses SELECT FOR UPDATE to prevent races."""
    today = date.today()

    from sqlalchemy import func, cast, Date

    # Use FOR UPDATE to prevent race conditions with concurrent computes
    existing_result = await session.execute(
        select(TrustScore).where(
            TrustScore.connection_id == connection_id,
            TrustScore.table_name == table_name,
            cast(TrustScore.created_at, Date) == today,
        ).with_for_update().limit(1)
    )
    existing = existing_result.scalar_one_or_none()

    if existing:
        existing.overall = overall
        existing.completeness = completeness
        existing.accuracy = accuracy
        existing.timeliness = timeliness
        await session.commit()
        await session.refresh(existing)
        return existing

    score = TrustScore(
        connection_id=connection_id,
        table_name=table_name,
        overall=overall,
        completeness=completeness,
        accuracy=accuracy,
        timeliness=timeliness,
    )
    session.add(score)
    await session.commit()
    await session.refresh(score)
    return score
