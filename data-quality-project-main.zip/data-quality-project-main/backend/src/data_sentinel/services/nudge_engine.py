"""Nudge engine: Slack Block Kit + AWS SES alerts with resolution tokens."""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from html import escape

import boto3
import httpx

from data_sentinel.config import settings
from data_sentinel.models.alert import Alert

logger = logging.getLogger(__name__)


def _build_slack_blocks(message: str, resolve_url: str) -> list[dict]:
    return [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": message},
        },
        {
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Approve"},
                    "style": "primary",
                    "url": f"{resolve_url}?action=approve",
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Reject"},
                    "style": "danger",
                    "url": f"{resolve_url}?action=reject",
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Snooze 24h"},
                    "url": f"{resolve_url}?action=snooze",
                },
            ],
        },
    ]


async def send_slack_alert(channel: str, message: str, resolution_token: uuid.UUID) -> bool:
    if not settings.slack_bot_token:
        logger.warning("Slack bot token not configured, skipping alert")
        return False

    resolve_url = f"{settings.app_base_url}/api/alerts/resolve/{resolution_token}"
    blocks = _build_slack_blocks(message, resolve_url)

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://slack.com/api/chat.postMessage",
            headers={"Authorization": f"Bearer {settings.slack_bot_token}"},
            json={
                "channel": channel,
                "text": message,
                "blocks": blocks,
            },
        )
        data = resp.json()
        if not data.get("ok"):
            logger.error(f"Slack API error: {data.get('error')}")
            return False
    return True


def _send_ses_email_sync(recipient: str, subject: str, html_body: str) -> bool:
    if not settings.ses_sender_email:
        logger.warning("SES sender not configured, skipping email")
        return False

    client = boto3.client("ses", region_name=settings.ses_region)
    try:
        client.send_email(
            Source=settings.ses_sender_email,
            Destination={"ToAddresses": [recipient]},
            Message={
                "Subject": {"Data": subject},
                "Body": {
                    "Html": {"Data": html_body},
                },
            },
        )
        return True
    except Exception as e:
        logger.error(f"SES send error: {e}")
        return False


async def send_email_alert(
    recipient: str, subject: str, message: str, resolution_token: uuid.UUID
) -> bool:
    resolve_url = f"{settings.app_base_url}/api/alerts/resolve/{resolution_token}"
    # Escape user-controlled content to prevent HTML injection
    safe_message = escape(message)
    html = f"""
    <div style="font-family: sans-serif; max-width: 600px;">
        <h2 style="color: #d32f2f;">DataSentinel Alert</h2>
        <p>{safe_message}</p>
        <div style="margin-top: 20px;">
            <a href="{escape(resolve_url)}?action=approve"
               style="background: #4caf50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin-right: 10px;">
                Approve
            </a>
            <a href="{escape(resolve_url)}?action=reject"
               style="background: #d32f2f; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin-right: 10px;">
                Reject
            </a>
            <a href="{escape(resolve_url)}?action=snooze"
               style="background: #ff9800; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
                Snooze 24h
            </a>
        </div>
    </div>
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _send_ses_email_sync, recipient, subject, html)
