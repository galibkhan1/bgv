"""AI-powered rule discovery: DDL + sample data -> Bedrock -> SodaCL rules."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re

from sqlalchemy import select, text
from sqlalchemy.engine import URL, create_engine
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.models.connection import DataConnection
from data_sentinel.models.rule import DQRule
from data_sentinel.models.rule_version import DQRuleVersion
from data_sentinel.services.ollama_client import converse
from data_sentinel.services.connection_service import get_connection_password

from shared_utils.prompt_templates import DISCOVERY_SYSTEM, DISCOVERY_USER
from shared_utils.yaml_parser import extract_dimension_comment, parse_sodacl_yaml, strip_yaml_fences

logger = logging.getLogger(__name__)

# Valid identifier pattern to prevent SQL injection
_VALID_IDENTIFIER = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

# Column names that likely contain PII and should be masked in sample data
_PII_COLUMN_PATTERNS = re.compile(
    r'(email|phone|ssn|social_security|address|birth|dob|salary|password|secret|token|credit_card|card_number)',
    re.IGNORECASE,
)


def _validate_identifier(name: str) -> str:
    """Validate SQL identifiers to prevent injection."""
    if not _VALID_IDENTIFIER.match(name):
        raise ValueError(f"Invalid SQL identifier: {name}")
    return name


def _mask_value(value) -> str:
    """Mask a PII value for safe transmission to external AI services."""
    if value is None:
        return "NULL"
    s = str(value)
    if len(s) <= 2:
        return "***"
    return s[0] + "*" * (len(s) - 2) + s[-1]


def _build_sync_url(conn: DataConnection, password: str) -> URL:
    return URL.create(
        "postgresql",
        username=conn.username,
        password=password,
        host=conn.host,
        port=conn.port,
        database=conn.database,
    )


async def _get_table_ddl(conn: DataConnection, password: str, table_name: str) -> str:
    """Fetch DDL for a table via information_schema."""
    _validate_identifier(table_name)
    schema = _validate_identifier(conn.schema_name)

    url = _build_sync_url(conn, password)

    def _fetch():
        engine = create_engine(url)
        with engine.connect() as c:
            result = c.execute(text("""
                SELECT column_name, data_type, is_nullable, column_default
                FROM information_schema.columns
                WHERE table_schema = :schema AND table_name = :table
                ORDER BY ordinal_position
            """), {"schema": schema, "table": table_name})
            columns = result.fetchall()

            ddl_lines = [f"CREATE TABLE {schema}.{table_name} ("]
            for col in columns:
                nullable = "" if col[2] == "YES" else " NOT NULL"
                default = f" DEFAULT {col[3]}" if col[3] else ""
                ddl_lines.append(f"  {col[0]} {col[1]}{nullable}{default},")
            ddl_lines.append(");")
        engine.dispose()
        return "\n".join(ddl_lines)

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _fetch)


async def _get_sample_data(conn: DataConnection, password: str, table_name: str) -> str:
    """Fetch first 10 rows with PII columns masked for safe AI transmission."""
    _validate_identifier(table_name)
    schema = _validate_identifier(conn.schema_name)

    url = _build_sync_url(conn, password)

    def _fetch():
        engine = create_engine(url)
        with engine.connect() as c:
            result = c.execute(
                text(f'SELECT * FROM "{schema}"."{table_name}" LIMIT 10')
            )
            rows = result.fetchall()
            cols = list(result.keys())
        engine.dispose()

        if not rows:
            return "No data"

        # Identify PII columns to mask
        pii_cols = {i for i, col in enumerate(cols) if _PII_COLUMN_PATTERNS.search(col)}

        lines = [" | ".join(cols)]
        lines.append("-" * len(lines[0]))
        for row in rows:
            values = []
            for i, v in enumerate(row):
                if i in pii_cols:
                    values.append(_mask_value(v))
                else:
                    values.append(str(v))
            lines.append(" | ".join(values))
        return "\n".join(lines)

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _fetch)


async def discover_rules_for_table(
    session: AsyncSession,
    connection: DataConnection,
    table_name: str,
    skip_existing: bool = True,
) -> list[DQRule]:
    """Run AI discovery for a single table, returning generated rules."""
    password = await get_connection_password(connection)

    ddl = await _get_table_ddl(connection, password, table_name)
    sample = await _get_sample_data(connection, password, table_name)

    user_msg = DISCOVERY_USER.format(
        table_name=table_name,
        schema_name=connection.schema_name,
        connection_name=connection.name,
        ddl=ddl,
        sample_data=sample,
    )

    response = await converse(DISCOVERY_SYSTEM, user_msg)
    yaml_text = strip_yaml_fences(response)

    parsed = parse_sodacl_yaml(yaml_text)

    # Get existing check names for dedup
    existing_checks: set[str] = set()
    if skip_existing:
        existing_result = await session.execute(
            select(DQRule.check_name).where(
                DQRule.connection_id == connection.id,
                DQRule.table_name == table_name,
                DQRule.is_active.is_(True),
            )
        )
        existing_checks = {row[0] for row in existing_result.all()}

    rules = []
    for check_entry in parsed:
        check_name = check_entry.get("name", "")
        check_definition = check_entry.get("definition", "")
        dimension = check_entry.get("dimension")

        if not check_name or not check_definition:
            continue

        if check_name in existing_checks:
            logger.info(f"Skipping duplicate check: {check_name} for {table_name}")
            continue

        rule = DQRule(
            connection_id=connection.id,
            table_name=table_name,
            check_name=check_name,
            check_definition=check_definition,
            source="ai",
            engine="soda",
            severity="medium",
            dimension=dimension,
            is_active=True,
        )
        session.add(rule)
        await session.flush()

        version = DQRuleVersion(
            rule_id=rule.id,
            version=1,
            check_definition=rule.check_definition,
            change_reason="AI discovery",
        )
        session.add(version)
        rules.append(rule)
        existing_checks.add(check_name)

    await session.commit()
    return rules


async def list_tables_for_connection(conn: DataConnection, password: str) -> list[str]:
    """List all user tables in the connection's schema."""
    url = _build_sync_url(conn, password)

    def _fetch():
        engine = create_engine(url)
        with engine.connect() as c:
            result = c.execute(text("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = :schema AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """), {"schema": conn.schema_name})
            tables = [row[0] for row in result.fetchall()]
        engine.dispose()
        return tables

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _fetch)
