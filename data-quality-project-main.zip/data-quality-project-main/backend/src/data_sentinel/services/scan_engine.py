"""Orchestrates DQ scans: gathers rules, executes via Soda, records results."""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from fastapi import BackgroundTasks
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.models.connection import DataConnection
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.rule import DQRule
from data_sentinel.models.run import DQRun
from data_sentinel.services.connection_service import build_soda_datasource_yaml, get_connection_password
from data_sentinel.services.soda_executor import execute_soda_scan

logger = logging.getLogger(__name__)


async def _send_failure_alerts(session: AsyncSession, run: DQRun, failed_issues: list[DQIssue]):
    """Create alerts for scan failures and send via nudge engine."""
    from data_sentinel.models.alert import Alert
    from data_sentinel.services.nudge_engine import send_slack_alert, send_email_alert
    from data_sentinel.config import settings

    for issue in failed_issues:
        message = (
            f"*DQ Check Failed*: `{issue.check_name}` on table `{issue.table_name}`\n"
            f"Severity: {issue.severity} | Value: {issue.actual_value or 'N/A'}"
        )
        alert = Alert(
            issue_id=issue.id,
            channel="slack",
            recipient=settings.slack_default_channel,
            message=message,
            status="sent",
            escalation_level=0,
        )
        session.add(alert)
        await session.flush()

        try:
            await send_slack_alert(settings.slack_default_channel, message, alert.resolution_token)
        except Exception as e:
            logger.warning(f"Slack alert failed for issue {issue.id}: {e}")

    await session.commit()


async def _execute_scan_work(
    run_id: uuid.UUID,
    connection_id: uuid.UUID,
    table_names: list[str] | None,
    engine: str,
):
    """Execute the actual scan work in a background task with its own session.

    Uses independent session from async_session_factory (not the request-scoped session)
    because FastAPI closes the request session after the HTTP response returns.
    """
    from data_sentinel.core.database import async_session_factory

    async with async_session_factory() as session:
        try:
            # Re-fetch run and connection inside this independent session
            run_result = await session.execute(select(DQRun).where(DQRun.id == run_id))
            run = run_result.scalar_one()
            conn_result = await session.execute(select(DataConnection).where(DataConnection.id == connection_id))
            conn = conn_result.scalar_one()

            # Gather active rules for this connection
            query = select(DQRule).where(
                DQRule.connection_id == conn.id,
                DQRule.is_active.is_(True),
                DQRule.engine == engine,
            )
            if table_names:
                query = query.where(DQRule.table_name.in_(table_names))
            rules_result = await session.execute(query)
            rules = list(rules_result.scalars().all())

            if not rules:
                run.status = "completed"
                run.total_checks = 0
                run.completed_at = datetime.now(timezone.utc)
                await session.commit()
                return

            # Build SodaCL YAML from rules
            checks_by_table: dict[str, list[str]] = {}
            rule_map: dict[tuple[str, str], DQRule] = {}
            for rule in rules:
                checks_by_table.setdefault(rule.table_name, []).append(rule.check_definition)
                rule_map[(rule.table_name, rule.check_definition)] = rule

            checks_yaml_parts = []
            for table, definitions in checks_by_table.items():
                checks_yaml_parts.append(f"checks for {table}:")
                for defn in definitions:
                    lines = defn.strip().splitlines()
                    # Find the check line(s) — skip any "checks for X:" header
                    in_check = False
                    base_indent = 0
                    for line in lines:
                        stripped = line.strip()
                        if not stripped:
                            continue
                        if stripped.startswith("checks for ") and stripped.endswith(":"):
                            continue
                        # Detect indentation of original line
                        orig_indent = len(line) - len(line.lstrip())
                        if stripped.startswith("- "):
                            # Top-level check item
                            checks_yaml_parts.append(f"  {stripped}")
                            base_indent = orig_indent
                            in_check = True
                        elif in_check and orig_indent > base_indent:
                            # Sub-key of the check (e.g., "valid regex: ...")
                            checks_yaml_parts.append(f"    {stripped}")
                        elif stripped:
                            checks_yaml_parts.append(f"  {stripped}")
            checks_yaml = "\n".join(checks_yaml_parts)
            logger.info(f"Assembled SodaCL checks YAML:\n{checks_yaml}")

            # Build datasource config
            password = await get_connection_password(conn)
            ds_yaml = build_soda_datasource_yaml(conn, password)
            safe_name = conn.name.replace("-", "_").replace(" ", "_").lower()
            ds_name = f"ds_{safe_name}"

            # Execute
            scan_result = await execute_soda_scan(ds_yaml, checks_yaml, ds_name)

            if scan_result.error:
                run.status = "failed"
                run.error_message = scan_result.error
            else:
                run.status = "completed"

            run.total_checks = len(scan_result.passed) + len(scan_result.failed) + len(scan_result.warnings)
            run.passed = len(scan_result.passed)
            run.failed = len(scan_result.failed)
            run.warnings = len(scan_result.warnings)
            run.completed_at = datetime.now(timezone.utc)

            if run.total_checks > 0:
                run.health_score = round((run.passed / run.total_checks) * 100, 2)

            # Create issues for failures
            failed_issues = []
            for check in scan_result.failed:
                matched_rule = None
                for (tbl, defn), rule in rule_map.items():
                    if tbl == check.table and check.check_name in defn:
                        matched_rule = rule
                        break

                issue = DQIssue(
                    run_id=run.id,
                    rule_id=matched_rule.id if matched_rule else None,
                    table_name=check.table,
                    check_name=check.check_name,
                    severity=matched_rule.severity if matched_rule else "medium",
                    status="open",
                    actual_value=str(check.value) if check.value is not None else None,
                )
                session.add(issue)
                await session.flush()
                failed_issues.append(issue)

            await session.commit()
            await session.refresh(run)

            # Send alerts for failures
            if failed_issues:
                try:
                    await _send_failure_alerts(session, run, failed_issues)
                except Exception as e:
                    logger.warning(f"Failed to send alerts: {e}")

        except Exception as e:
            logger.error(f"Scan execution error: {e}")
            try:
                run_result = await session.execute(select(DQRun).where(DQRun.id == run_id))
                run = run_result.scalar_one_or_none()
                if run:
                    run.status = "failed"
                    run.error_message = str(e)
                    run.completed_at = datetime.now(timezone.utc)
                    await session.commit()
            except Exception as inner_e:
                logger.error(f"Failed to update run status: {inner_e}")


async def trigger_scan(
    session: AsyncSession,
    connection_id: uuid.UUID,
    triggered_by: uuid.UUID | None = None,
    table_names: list[str] | None = None,
    engine: str = "soda",
    background_tasks: BackgroundTasks | None = None,
) -> DQRun:
    """Create a run record and execute scan (in background if BackgroundTasks provided)."""
    # Get connection
    result = await session.execute(
        select(DataConnection).where(DataConnection.id == connection_id)
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise ValueError(f"Connection {connection_id} not found")

    # Create run record
    run = DQRun(
        connection_id=connection_id,
        triggered_by=triggered_by,
        status="running",
        engine=engine,
        started_at=datetime.now(timezone.utc),
    )
    session.add(run)
    await session.commit()
    await session.refresh(run)

    if background_tasks is not None:
        # Pass IDs (not ORM objects) so background task can use its own session
        background_tasks.add_task(_execute_scan_work, run.id, connection_id, table_names, engine)
    else:
        # Direct execution (used by Airflow DAGs) — uses caller's session
        await _execute_scan_work(run.id, connection_id, table_names, engine)
        await session.refresh(run)

    return run
