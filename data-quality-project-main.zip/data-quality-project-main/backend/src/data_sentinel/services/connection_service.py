from __future__ import annotations

import asyncio
from sqlalchemy import text
from sqlalchemy.engine import URL, create_engine

from data_sentinel.core.aws_secrets import fetch_secret
from data_sentinel.core.encryption import decrypt_password
from data_sentinel.models.connection import DataConnection


def _build_sync_url(conn: DataConnection, password: str) -> URL:
    """Build a SQLAlchemy URL object (keeps credentials out of string repr)."""
    return URL.create(
        "postgresql",
        username=conn.username,
        password=password,
        host=conn.host,
        port=conn.port,
        database=conn.database,
    )


async def get_connection_password(conn: DataConnection) -> str:
    if conn.secret_arn:
        secret = await fetch_secret(conn.secret_arn)
        return secret.get("password", "")
    if conn.encrypted_password:
        return decrypt_password(conn.encrypted_password)
    return ""


async def test_connection(conn: DataConnection) -> bool:
    password = await get_connection_password(conn)
    url = _build_sync_url(conn, password)

    def _test():
        engine = create_engine(url, pool_pre_ping=True)
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
        engine.dispose()
        return True

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _test)


def build_soda_datasource_yaml(conn: DataConnection, password: str) -> dict:
    # Soda expects "postgres" not "postgresql"
    soda_type = "postgres" if conn.db_type == "postgresql" else conn.db_type
    # Soda requires [a-z0-9_] names — sanitize
    safe_name = conn.name.replace("-", "_").replace(" ", "_").lower()
    ds_name = f"ds_{safe_name}"
    return {
        f"data_source {ds_name}": {
            "type": soda_type,
            "host": conn.host,
            "port": str(conn.port),
            "username": conn.username or "",
            "password": password,
            "database": conn.database,
            "schema": conn.schema_name,
        }
    }
