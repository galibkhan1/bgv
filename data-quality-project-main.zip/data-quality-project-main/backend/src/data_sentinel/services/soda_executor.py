"""Soda Core 3.5.x wrapper with all known quirks.

Quirks preserved from pulse-dq:
- No get_checks_pass() method; use _checks + get_checks_fail() set comparison
- check.check_value is int/float, not dict
- check.dict["table"] for table name
- Dynamic datasource YAML from data_connections table
"""
from __future__ import annotations

import asyncio
import logging
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


@dataclass
class CheckResult:
    table: str
    check_name: str
    passed: bool
    value: float | int | None = None
    has_warning: bool = False


@dataclass
class ScanResult:
    passed: list[CheckResult] = field(default_factory=list)
    failed: list[CheckResult] = field(default_factory=list)
    warnings: list[CheckResult] = field(default_factory=list)
    error: str | None = None


def _run_soda_scan(datasource_yaml: dict, checks_yaml: str, datasource_name: str) -> ScanResult:
    """Run soda scan synchronously (called in executor)."""
    from soda.scan import Scan

    result = ScanResult()
    ds_path = None

    try:
        scan = Scan()
        scan.set_data_source_name(datasource_name)

        # Write datasource config to temp file (key is "data_source <name>")
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            yaml.dump(datasource_yaml, f)
            ds_path = f.name
        scan.add_configuration_yaml_file(ds_path)

        # Add checks — split by table to isolate parse errors
        # Each "checks for <table>:" block is added separately
        current_block = []
        for line in checks_yaml.splitlines():
            if line.startswith("checks for ") and current_block:
                block_str = "\n".join(current_block)
                try:
                    scan.add_sodacl_yaml_str(block_str)
                except Exception as e:
                    logger.warning(f"Skipping invalid SodaCL block: {e}\n{block_str[:200]}")
                current_block = [line]
            else:
                current_block.append(line)
        if current_block:
            block_str = "\n".join(current_block)
            try:
                scan.add_sodacl_yaml_str(block_str)
            except Exception as e:
                logger.warning(f"Skipping invalid SodaCL block: {e}\n{block_str[:200]}")

        scan.execute()

        # Extract results using 3.5.x compatible API
        all_checks = set(scan._checks)
        failed_checks = set(scan.get_checks_fail())
        warn_or_fail = set(scan.get_checks_warn_or_fail())
        warning_checks = warn_or_fail - failed_checks
        passed_checks = all_checks - warn_or_fail

        for check in passed_checks:
            val = getattr(check, "check_value", None)
            result.passed.append(CheckResult(
                table=check.dict.get("table", "unknown"),
                check_name=str(check),
                passed=True,
                value=val if isinstance(val, (int, float)) else None,
            ))

        for check in failed_checks:
            val = getattr(check, "check_value", None)
            result.failed.append(CheckResult(
                table=check.dict.get("table", "unknown"),
                check_name=str(check),
                passed=False,
                value=val if isinstance(val, (int, float)) else None,
            ))

        for check in warning_checks:
            val = getattr(check, "check_value", None)
            result.warnings.append(CheckResult(
                table=check.dict.get("table", "unknown"),
                check_name=str(check),
                passed=False,
                has_warning=True,
                value=val if isinstance(val, (int, float)) else None,
            ))

    except Exception as e:
        logger.error(f"Soda scan error: {e}")
        result.error = str(e)
    finally:
        # Cleanup temp file in finally block (#24)
        if ds_path:
            Path(ds_path).unlink(missing_ok=True)

    return result


async def execute_soda_scan(
    datasource_yaml: dict, checks_yaml: str, datasource_name: str
) -> ScanResult:
    """Async wrapper for soda scan execution."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, _run_soda_scan, datasource_yaml, checks_yaml, datasource_name
    )
