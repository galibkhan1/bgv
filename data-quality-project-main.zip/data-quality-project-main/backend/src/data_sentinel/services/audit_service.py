"""Immutable audit trail service -- append-only writes."""
from __future__ import annotations

import uuid
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.models.audit_trail import AuditTrail


async def log_audit(
    session: AsyncSession,
    entity_type: str,
    entity_id: str,
    action: str,
    user_id: uuid.UUID | None = None,
    old_values: dict | None = None,
    new_values: dict | None = None,
    justification: str | None = None,
    ip_address: str | None = None,
) -> AuditTrail:
    entry = AuditTrail(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        user_id=user_id,
        old_values=old_values,
        new_values=new_values,
        justification=justification,
        ip_address=ip_address,
    )
    session.add(entry)
    await session.flush()
    return entry
