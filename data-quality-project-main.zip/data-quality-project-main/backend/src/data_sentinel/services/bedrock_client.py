"""AWS Bedrock Claude client using Converse API.

boto3 is sync, so all calls are wrapped in asyncio.run_in_executor.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import threading

import boto3
from botocore.exceptions import ClientError

from data_sentinel.config import settings
from data_sentinel.core.exceptions import BedrockError

logger = logging.getLogger(__name__)

_client = None
_client_created_at = 0.0
_client_lock = threading.Lock()
_CLIENT_TTL_SECONDS = 3600  # Refresh client every hour for credential rotation


def _get_bedrock_client():
    global _client, _client_created_at
    now = time.monotonic()
    with _client_lock:
        if _client is None or (now - _client_created_at) > _CLIENT_TTL_SECONDS:
            kwargs = {"region_name": settings.aws_region}
            if settings.aws_access_key_id:
                kwargs["aws_access_key_id"] = settings.aws_access_key_id
                kwargs["aws_secret_access_key"] = settings.aws_secret_access_key
            _client = boto3.client("bedrock-runtime", **kwargs)
            _client_created_at = now
        return _client


def _converse_sync(system_prompt: str, user_message: str, max_tokens: int = 4096) -> str:
    """Call Bedrock Converse API synchronously."""
    client = _get_bedrock_client()
    try:
        response = client.converse(
            modelId=settings.aws_bedrock_model_id,
            system=[{"text": system_prompt}],
            messages=[
                {
                    "role": "user",
                    "content": [{"text": user_message}],
                }
            ],
            inferenceConfig={
                "maxTokens": max_tokens,
                "temperature": 0.3,
            },
        )
        output = response["output"]["message"]["content"]
        return output[0]["text"] if output else ""
    except ClientError as e:
        logger.error(f"Bedrock API error: {e}")
        raise BedrockError(f"Bedrock API call failed: {e}") from e


async def converse(system_prompt: str, user_message: str, max_tokens: int = 4096) -> str:
    """Async wrapper for Bedrock Converse API."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _converse_sync, system_prompt, user_message, max_tokens)


async def converse_json(system_prompt: str, user_message: str, max_tokens: int = 4096) -> dict:
    """Call Bedrock and parse response as JSON."""
    text = await converse(system_prompt, user_message, max_tokens)
    # Strip markdown fences if present
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Bedrock JSON response: {text[:200]}")
        raise BedrockError(f"Invalid JSON from Bedrock: {e}") from e
