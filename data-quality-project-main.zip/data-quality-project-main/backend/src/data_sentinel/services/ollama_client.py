"""Ollama Cloud client for LLM inference.

Drop-in replacement for bedrock_client.py — same converse() / converse_json() interface.
Uses the native Ollama Python client with async wrapper.
"""
from __future__ import annotations

import asyncio
import json
import logging
from functools import partial

from ollama import Client

from data_sentinel.config import settings
from data_sentinel.core.exceptions import AIServiceError

logger = logging.getLogger(__name__)

_client: Client | None = None


def _get_client() -> Client:
    global _client
    if _client is None:
        _client = Client(
            host=settings.ollama_cloud_base_url,
            headers={"Authorization": f"Bearer {settings.ollama_cloud_api_key}"},
            timeout=120,
        )
    return _client


def _chat_sync(system_prompt: str, user_message: str, max_tokens: int = 4096) -> str:
    """Call Ollama Cloud chat API synchronously."""
    client = _get_client()
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ]
    try:
        response = client.chat(
            model=settings.ollama_cloud_model,
            messages=messages,
            options={"temperature": 0.3, "num_predict": max_tokens},
        )
        return response.get("message", {}).get("content", "")
    except Exception as e:
        logger.error(f"Ollama Cloud API error: {e}")
        raise AIServiceError(f"Ollama Cloud API call failed: {e}") from e


async def converse(system_prompt: str, user_message: str, max_tokens: int = 4096) -> str:
    """Async wrapper — same signature as bedrock_client.converse()."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, partial(_chat_sync, system_prompt, user_message, max_tokens)
    )


async def converse_json(system_prompt: str, user_message: str, max_tokens: int = 4096) -> dict:
    """Call Ollama Cloud and parse response as JSON."""
    text = await converse(system_prompt, user_message, max_tokens)
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Ollama JSON response: {text[:200]}")
        raise AIServiceError(f"Invalid JSON from Ollama Cloud: {e}") from e
