"""AI-powered Root Cause Analysis for data quality issues."""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.models.issue import DQIssue
from data_sentinel.models.rule import DQRule
from data_sentinel.services.ollama_client import converse_json

from shared_utils.prompt_templates import RCA_SYSTEM, RCA_USER

logger = logging.getLogger(__name__)


async def analyze_issue(session: AsyncSession, issue_id: uuid.UUID) -> dict:
    """Run RCA analysis on a specific issue, updating it with results."""
    result = await session.execute(select(DQIssue).where(DQIssue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise ValueError(f"Issue {issue_id} not found")

    # Get associated rule for context
    rule = None
    if issue.rule_id:
        rule_result = await session.execute(select(DQRule).where(DQRule.id == issue.rule_id))
        rule = rule_result.scalar_one_or_none()

    user_msg = RCA_USER.format(
        table_name=issue.table_name,
        check_name=issue.check_name,
        expected=issue.expected_value or "N/A",
        actual=issue.actual_value or "N/A",
        severity=issue.severity,
        last_passed="Unknown",
        recent_changes="No recent changes data available",
    )

    rca_result = await converse_json(RCA_SYSTEM, user_msg)

    issue.rca_summary = rca_result.get("summary", "")
    issue.rca_pattern = rca_result.get("pattern", "other")
    issue.rca_confidence = rca_result.get("confidence", 0.0)

    await session.commit()
    await session.refresh(issue)

    return {
        "issue_id": str(issue.id),
        "summary": issue.rca_summary,
        "pattern": issue.rca_pattern,
        "confidence": issue.rca_confidence,
    }
