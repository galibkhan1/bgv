"""Self-healing pipeline: AI proposes SQL fix -> admin approves -> safe execution."""
from __future__ import annotations

import asyncio
import logging
import re
import uuid

from sqlalchemy import select, text
from sqlalchemy.engine import URL, create_engine
from sqlalchemy.ext.asyncio import AsyncSession

from data_sentinel.core.exceptions import HealingError
from data_sentinel.models.connection import DataConnection
from data_sentinel.models.healing_proposal import HealingProposal
from data_sentinel.models.issue import DQIssue
from data_sentinel.models.rule import DQRule
from data_sentinel.services.ollama_client import converse_json
from data_sentinel.services.connection_service import get_connection_password
from data_sentinel.services.audit_service import log_audit

from shared_utils.constants import HEALING_MAX_ROWS
from shared_utils.prompt_templates import HEALING_SYSTEM, HEALING_USER

logger = logging.getLogger(__name__)

# SQL safety: only UPDATE and INSERT are allowed. Block everything else structurally.
_ALLOWED_STATEMENT_PATTERN = re.compile(
    r'^\s*(UPDATE|INSERT)\s', re.IGNORECASE | re.DOTALL
)
# Broad forbidden patterns (case-insensitive, multi-whitespace tolerant)
_FORBIDDEN_PATTERNS = [
    re.compile(r'\b(DROP|ALTER|TRUNCATE|CREATE|GRANT|REVOKE|DELETE)\b', re.IGNORECASE),
    re.compile(r';', re.IGNORECASE),  # Block semicolons (statement batching)
]


def _validate_proposed_sql(proposed_sql: str) -> None:
    """Validate that proposed SQL is safe to execute. Raises HealingError on violation."""
    stripped = proposed_sql.strip()
    if not stripped:
        raise HealingError("Proposed SQL is empty")

    # Must start with UPDATE or INSERT
    if not _ALLOWED_STATEMENT_PATTERN.match(stripped):
        raise HealingError("Proposed SQL must be an UPDATE or INSERT statement")

    # Check for forbidden patterns
    for pattern in _FORBIDDEN_PATTERNS:
        match = pattern.search(stripped)
        if match:
            raise HealingError(f"Proposed SQL contains forbidden pattern: {match.group()}")


async def propose_healing(session: AsyncSession, issue_id: uuid.UUID) -> HealingProposal:
    """Use AI to propose a SQL fix for a data quality issue."""
    result = await session.execute(select(DQIssue).where(DQIssue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HealingError(f"Issue {issue_id} not found")

    rule = None
    if issue.rule_id:
        rule_result = await session.execute(select(DQRule).where(DQRule.id == issue.rule_id))
        rule = rule_result.scalar_one_or_none()

    user_msg = HEALING_USER.format(
        table_name=issue.table_name,
        check_name=issue.check_name,
        check_definition=rule.check_definition if rule else "N/A",
        actual_value=issue.actual_value or "N/A",
        schema_info="See table DDL",
        sample_rows="Not available",
    )

    ai_response = await converse_json(HEALING_SYSTEM, user_msg)

    proposed_sql = ai_response.get("proposed_sql", "")
    rollback_sql = ai_response.get("rollback_sql", "")

    # Safety check using parser-based validation
    _validate_proposed_sql(proposed_sql)

    proposal = HealingProposal(
        issue_id=issue_id,
        proposed_sql=proposed_sql,
        rollback_sql=rollback_sql,
        explanation=ai_response.get("explanation", ""),
        risk_level=ai_response.get("risk_level", "medium"),
        confidence=ai_response.get("confidence", 0.5),
        affected_rows_estimate=ai_response.get("affected_rows_estimate", 0),
        status="pending",
    )
    session.add(proposal)
    await session.commit()
    await session.refresh(proposal)
    return proposal


async def execute_healing(
    session: AsyncSession,
    proposal_id: uuid.UUID,
    approver_id: uuid.UUID,
    connection: DataConnection,
) -> HealingProposal:
    """Execute an approved healing proposal with dry-run safety."""
    result = await session.execute(
        select(HealingProposal).where(HealingProposal.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        raise HealingError(f"Proposal {proposal_id} not found")

    if proposal.status != "approved":
        raise HealingError(f"Proposal must be approved before execution (current: {proposal.status})")

    # Re-validate SQL at execution time as a defense-in-depth measure
    _validate_proposed_sql(proposal.proposed_sql)

    password = await get_connection_password(connection)
    url = URL.create(
        "postgresql",
        username=connection.username,
        password=password,
        host=connection.host,
        port=connection.port,
        database=connection.database,
    )

    def _execute():
        engine = create_engine(url)
        try:
            # Dry run first
            with engine.connect() as conn:
                trans = conn.begin()
                try:
                    result = conn.execute(text(proposal.proposed_sql))
                    dry_run_count = result.rowcount
                    trans.rollback()
                except Exception as e:
                    trans.rollback()
                    raise HealingError(f"Dry run failed: {e}") from e

            if dry_run_count < 0:
                raise HealingError(
                    "Dry run returned unknown rowcount; execution blocked for safety"
                )
            if dry_run_count > HEALING_MAX_ROWS:
                raise HealingError(
                    f"Dry run affected {dry_run_count} rows (max {HEALING_MAX_ROWS})"
                )

            # Actual execution
            with engine.connect() as conn:
                trans = conn.begin()
                try:
                    result = conn.execute(text(proposal.proposed_sql))
                    actual_count = result.rowcount
                    trans.commit()
                except Exception as e:
                    trans.rollback()
                    raise HealingError(f"Execution failed: {e}") from e

            return actual_count
        finally:
            engine.dispose()

    try:
        loop = asyncio.get_running_loop()
        actual_rows = await loop.run_in_executor(None, _execute)
        proposal.status = "executed"
        proposal.actual_rows_affected = actual_rows
        proposal.execution_result = f"Success: {actual_rows} rows affected"
    except HealingError as e:
        proposal.status = "failed"
        proposal.execution_result = str(e)
        await session.commit()
        raise

    await session.commit()
    await session.refresh(proposal)

    await log_audit(
        session,
        entity_type="healing_proposal",
        entity_id=str(proposal.id),
        action="execute",
        user_id=approver_id,
        new_values={"rows_affected": proposal.actual_rows_affected, "status": proposal.status},
    )

    return proposal
