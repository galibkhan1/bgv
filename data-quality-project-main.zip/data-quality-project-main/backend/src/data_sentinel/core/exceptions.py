from __future__ import annotations


class DataSentinelError(Exception):
    """Base exception for DataSentinel."""


class NotFoundError(DataSentinelError):
    def __init__(self, entity: str, id: str):
        super().__init__(f"{entity} with id '{id}' not found")
        self.entity = entity
        self.id = id


class AuthenticationError(DataSentinelError):
    pass


class AuthorizationError(DataSentinelError):
    pass


class ConnectionTestError(DataSentinelError):
    pass


class ScanExecutionError(DataSentinelError):
    pass


class HealingError(DataSentinelError):
    pass


class BedrockError(DataSentinelError):
    """Kept for backwards compatibility."""
    pass


class AIServiceError(DataSentinelError):
    """Error from the AI service (Ollama Cloud / Bedrock)."""
    pass
