"""Shared rate limiter instance for slowapi.

This module provides a single Limiter instance that is:
1. Stored on app.state.limiter in main.py
2. Referenced by route decorators (e.g., @limiter.limit("5/minute"))

Both must use the SAME instance for rate counting to work.
"""
from __future__ import annotations

from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
