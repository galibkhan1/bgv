"""Fernet symmetric encryption for database connection passwords.

Uses a dedicated ENCRYPTION_KEY (not the JWT secret) for proper key separation.
"""
from __future__ import annotations

from cryptography.fernet import Fernet

from data_sentinel.config import settings


def get_fernet() -> Fernet:
    return Fernet(settings.encryption_key.encode())


def encrypt_password(plain: str) -> str:
    return get_fernet().encrypt(plain.encode()).decode()


def decrypt_password(ciphertext: str) -> str:
    return get_fernet().decrypt(ciphertext.encode()).decode()
