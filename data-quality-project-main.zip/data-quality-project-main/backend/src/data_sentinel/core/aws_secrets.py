from __future__ import annotations

import json
import asyncio
import time
import threading

import boto3
from botocore.exceptions import ClientError

from data_sentinel.config import settings

_client = None
_client_created_at = 0.0
_client_lock = threading.Lock()
_CLIENT_TTL_SECONDS = 3600  # Refresh client every hour to handle credential rotation


def _get_client():
    global _client, _client_created_at
    now = time.monotonic()
    with _client_lock:
        if _client is None or (now - _client_created_at) > _CLIENT_TTL_SECONDS:
            kwargs = {"region_name": settings.aws_region}
            if settings.aws_access_key_id:
                kwargs["aws_access_key_id"] = settings.aws_access_key_id
                kwargs["aws_secret_access_key"] = settings.aws_secret_access_key
            _client = boto3.client("secretsmanager", **kwargs)
            _client_created_at = now
        return _client


def _fetch_secret_sync(secret_arn: str) -> dict:
    client = _get_client()
    try:
        resp = client.get_secret_value(SecretId=secret_arn)
        return json.loads(resp["SecretString"])
    except ClientError as e:
        raise RuntimeError(f"Failed to fetch secret {secret_arn}: {e}") from e


async def fetch_secret(secret_arn: str) -> dict:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _fetch_secret_sync, secret_arn)
