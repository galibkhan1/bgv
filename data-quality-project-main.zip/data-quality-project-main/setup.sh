#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"

echo "=== DataSentinel Setup ==="

# 1. Create venv
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

# 2. Install dependencies
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r "$PROJECT_DIR/requirements.txt"
pip install -e "$PROJECT_DIR"

# 3. Copy env if needed
if [ ! -f "$PROJECT_DIR/.env" ]; then
    cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
    echo "Created .env from .env.example -- edit it with your settings"
fi

# 4. Generate a random database password
DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=' | head -c 24)

# 5. Create database (assumes PostgreSQL running)
echo "Creating database (if not exists)..."
psql -U postgres -tc "SELECT 1 FROM pg_database WHERE datname = 'datasentinel'" | grep -q 1 || \
    psql -U postgres -c "CREATE DATABASE datasentinel"
psql -U postgres -tc "SELECT 1 FROM pg_roles WHERE rolname = 'datasentinel'" | grep -q 1 || \
    psql -U postgres -c "CREATE USER datasentinel WITH PASSWORD '${DB_PASSWORD}'"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE datasentinel TO datasentinel"

# 6. Update .env with the generated password if it still has the default
if grep -q "changeme" "$PROJECT_DIR/.env" 2>/dev/null; then
    sed -i.bak "s/changeme/${DB_PASSWORD}/g" "$PROJECT_DIR/.env"
    rm -f "$PROJECT_DIR/.env.bak"
    echo "Updated .env with generated database password"
fi

# 7. Generate encryption key if not set
if ! grep -q "ENCRYPTION_KEY" "$PROJECT_DIR/.env" 2>/dev/null; then
    ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
    echo "ENCRYPTION_KEY=${ENCRYPTION_KEY}" >> "$PROJECT_DIR/.env"
    echo "Generated and saved ENCRYPTION_KEY to .env"
fi

# 8. Run migrations
echo "Running database migrations..."
cd "$PROJECT_DIR"
alembic upgrade head

echo ""
echo "=== Setup Complete ==="
echo "Next steps:"
echo "  1. Edit .env with your AWS/Slack credentials"
echo "  2. Run: python backend/scripts/create_admin.py"
echo "  3. Run: ./start.sh start"
