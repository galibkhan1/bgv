/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        pine: {
          50:  '#F5FDF8',
          100: '#EAFAF1',
          200: '#D4F5E3',
          300: '#A8EBC7',
          400: '#7DDFAA',
          500: '#50D387',
          600: '#008059',
          700: '#006647',
          800: '#004D35',
          900: '#003323',
          950: '#001A12',
        },
      },
      fontFamily: {
        sans: ['Roboto', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
