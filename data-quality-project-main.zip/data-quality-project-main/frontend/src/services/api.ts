const BASE = '/api';

let redirecting = false;

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('ds_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE}${path}`, { ...options, headers });
  if (res.status === 401) {
    localStorage.removeItem('ds_token');
    // Prevent multiple concurrent 401 redirects
    if (!redirecting) {
      redirecting = true;
      const returnUrl = window.location.pathname;
      window.location.href = returnUrl !== '/login' ? `/login?return=${encodeURIComponent(returnUrl)}` : '/login';
    }
    throw new Error('Unauthorized');
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || res.statusText);
  }
  if (res.status === 204) return {} as T;
  return res.json();
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'PATCH', body: JSON.stringify(body) }),
  del: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
};

// Auth
export const login = (email: string, password: string) =>
  api.post<{ access_token: string }>('/auth/login', { email, password });
export const getMe = () => api.get<User>('/auth/me');

// Connections
export const listConnections = () => api.get<Connection[]>('/connections');
export const createConnection = (data: ConnectionCreate) =>
  api.post<Connection>('/connections', data);
export const deleteConnection = (id: string) => api.del(`/connections/${id}`);

// Rules
export const listRules = (params?: string) =>
  api.get<Rule[]>(`/rules${params ? `?${params}` : ''}`);
export const createRule = (data: RuleCreate) => api.post<Rule>('/rules', data);
export const updateRule = (id: string, data: Partial<Rule>) =>
  api.patch<Rule>(`/rules/${id}`, data);
export const deleteRule = (id: string) => api.del(`/rules/${id}`);

// Scans
export const triggerScan = (data: ScanTrigger) => api.post<Run>('/scans/trigger', data);
export const listScanHistory = (params?: string) =>
  api.get<Run[]>(`/scans/history${params ? `?${params}` : ''}`);
export const getRunIssues = (runId: string) => api.get<Issue[]>(`/scans/${runId}/issues`);
export const listAllIssues = (params?: string) =>
  api.get<Issue[]>(`/scans/issues/all${params ? `?${params}` : ''}`);

// Discovery
export const runDiscovery = (data: { connection_id: string; table_names?: string[] }) =>
  api.post<DiscoveryResult>('/discovery/run', data);
export const listDiscoveryHistory = (connectionId?: string) =>
  api.get<DiscoveryRunEntry[]>(`/discovery/history${connectionId ? `?connection_id=${connectionId}` : ''}`);

// RCA
export const analyzeRCA = (issueId: string) => api.post<RCAResult>(`/rca/analyze/${issueId}`);

// Trust Scores
export const listTrustScores = (params?: string) =>
  api.get<TrustScore[]>(`/health-score${params ? `?${params}` : ''}`);
export const getTableTrustHistory = (table: string) =>
  api.get<TrustScore[]>(`/health-score/${table}`);

// Audit
export const listAuditEntries = (params?: string) =>
  api.get<AuditEntry[]>(`/audit-trail${params ? `?${params}` : ''}`);

// Healing
export const listHealingProposals = (params?: string) =>
  api.get<HealingProposal[]>(`/healing${params ? `?${params}` : ''}`);
export const proposeHealing = (issueId: string) =>
  api.post<HealingProposal>('/healing/propose', { issue_id: issueId });
export const approveHealing = (id: string) => api.post<HealingProposal>(`/healing/${id}/approve`);
export const rejectHealing = (id: string) => api.post<HealingProposal>(`/healing/${id}/reject`);
export const executeHealing = (id: string, connectionId: string) =>
  api.post<HealingProposal>(`/healing/${id}/execute`, { connection_id: connectionId });

// Alerts
export const listAlerts = (params?: string) =>
  api.get<Alert[]>(`/alerts${params ? `?${params}` : ''}`);
export const resolveAlert = (id: string, data: { action: string; justification?: string }) =>
  api.post<Alert>(`/alerts/${id}/resolve`, data);

// Types
export interface User {
  id: string; email: string; full_name: string; role: string; is_active: boolean;
}
export interface Connection {
  id: string; name: string; db_type: string; host: string; port: number;
  database: string; schema_name: string; username: string | null;
  is_active: boolean; created_at: string; updated_at: string;
}
export interface ConnectionCreate {
  name: string; db_type?: string; host: string; port?: number;
  database: string; schema_name?: string; username?: string;
  password?: string; secret_arn?: string;
}
export interface Rule {
  id: string; connection_id: string; table_name: string; check_name: string;
  check_definition: string; source: string; engine: string; severity: string;
  dimension: string | null; is_contract: boolean; is_active: boolean;
  created_at: string; updated_at: string;
}
export interface RuleCreate {
  connection_id: string; table_name: string; check_name: string;
  check_definition: string; source?: string; engine?: string; severity?: string;
  dimension?: string; is_contract?: boolean;
}
export interface Run {
  id: string; connection_id: string; status: string; engine: string;
  total_checks: number; passed: number; failed: number; warnings: number;
  health_score: number | null; error_message: string | null;
  started_at: string | null; completed_at: string | null; created_at: string;
}
export interface Issue {
  id: string; run_id: string; rule_id: string | null; table_name: string;
  check_name: string; severity: string; status: string;
  expected_value: string | null; actual_value: string | null;
  rca_summary: string | null; rca_pattern: string | null;
  rca_confidence: number | null; snoozed_until: string | null; created_at: string;
}
export interface ScanTrigger {
  connection_id: string; table_names?: string[]; engine?: string;
}
export interface DiscoveryResult {
  id: string; connection_id: string; tables_processed: number; rules_generated: number;
  rules: Rule[]; errors: { table: string; error: string }[] | null; status: string;
}
export interface DiscoveryRunEntry {
  id: string; connection_id: string; status: string; tables_processed: number;
  rules_generated: number; tables_requested: string | null; error_message: string | null;
  errors_json: { table: string; error: string }[] | null;
  started_at: string | null; completed_at: string | null; created_at: string;
}
export interface RCAResult {
  issue_id: string; summary: string; pattern: string; confidence: number;
}
export interface TrustScore {
  id: string; connection_id: string; table_name: string;
  overall: number; completeness: number; accuracy: number; timeliness: number;
  created_at: string;
}
export interface AuditEntry {
  id: string; entity_type: string; entity_id: string; action: string;
  user_id: string | null; old_values: Record<string, unknown> | null;
  new_values: Record<string, unknown> | null; justification: string | null;
  ip_address: string | null; created_at: string;
}
export interface HealingProposal {
  id: string; issue_id: string; proposed_sql: string; rollback_sql: string;
  explanation: string | null; risk_level: string; confidence: number;
  affected_rows_estimate: number; status: string; approved_by: string | null;
  execution_result: string | null; actual_rows_affected: number | null;
  created_at: string; updated_at: string;
}
export interface Alert {
  id: string; issue_id: string | null; healing_id: string | null;
  channel: string; recipient: string; message: string; status: string;
  resolution_action: string | null;
  escalation_level: number; resolved_at: string | null; created_at: string;
}
