const statusConfig: Record<string, { bg: string; text: string; dot: string }> = {
  completed:  { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  passed:     { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  running:    { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500' },
  pending:    { bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-400' },
  failed:     { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  open:       { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  critical:   { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  high:       { bg: 'bg-orange-50',  text: 'text-orange-700',  dot: 'bg-orange-500' },
  medium:     { bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-400' },
  low:        { bg: 'bg-sky-50',     text: 'text-sky-700',     dot: 'bg-sky-500' },
  info:       { bg: 'bg-gray-50',    text: 'text-gray-600',    dot: 'bg-gray-400' },
  resolved:   { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  snoozed:    { bg: 'bg-purple-50',  text: 'text-purple-700',  dot: 'bg-purple-400' },
  approved:   { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  rejected:   { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  executed:   { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  sent:       { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500' },
  escalated:  { bg: 'bg-orange-50',  text: 'text-orange-700',  dot: 'bg-orange-500' },
  partial:    { bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-400' },
  error:      { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  // Discovery / rule sources
  ai:         { bg: 'bg-violet-50',  text: 'text-violet-700',  dot: 'bg-violet-500' },
  manual:     { bg: 'bg-gray-50',    text: 'text-gray-600',    dot: 'bg-gray-400' },
  create:     { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  update:     { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500' },
  delete:     { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  execute:    { bg: 'bg-pine-50',    text: 'text-pine-700',    dot: 'bg-pine-500' },
  approve:    { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  reject:     { bg: 'bg-red-50',     text: 'text-red-700',     dot: 'bg-red-500' },
  login:      { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500' },
};

const defaultConfig = { bg: 'bg-gray-50', text: 'text-gray-600', dot: 'bg-gray-400' };

export default function StatusBadge({ status }: { status: string }) {
  const cfg = statusConfig[status] || defaultConfig;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${cfg.bg} ${cfg.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {status}
    </span>
  );
}
