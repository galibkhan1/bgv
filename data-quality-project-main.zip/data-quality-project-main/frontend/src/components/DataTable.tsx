type Column<T = any> = {
  key: string;
  label: string;
  render?: (row: T) => React.ReactNode;
};

interface Props<T = any> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
}

export default function DataTable<T = any>({ columns, data, onRowClick }: Props<T>) {
  return (
    <div className="overflow-x-auto rounded-xl border border-pine-200 bg-white">
      <table className="min-w-full divide-y divide-pine-100">
        <thead>
          <tr className="bg-pine-100/60">
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider"
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-pine-100/60">
          {data.map((row) => (
            <tr
              key={(row as any).id ?? JSON.stringify(row)}
              className={`transition-colors duration-100 ${
                onRowClick ? 'cursor-pointer hover:bg-pine-50' : ''
              }`}
              onClick={() => onRowClick?.(row)}
            >
              {columns.map((col) => (
                <td key={col.key} className="px-4 py-3 text-sm text-gray-700 whitespace-nowrap">
                  {col.render ? col.render(row) : String((row as any)[col.key] ?? '')}
                </td>
              ))}
            </tr>
          ))}
          {data.length === 0 && (
            <tr>
              <td colSpan={columns.length} className="px-4 py-10 text-center text-gray-400 text-sm">
                No data
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
