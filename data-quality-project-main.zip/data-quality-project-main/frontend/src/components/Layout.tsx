import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Sparkles,
  ShieldCheck,
  ScanLine,
  AlertTriangle,
  Bell,
  Wrench,
  TrendingUp,
  ScrollText,
  Database,
  LogOut,
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/discovery', label: 'Discovery', icon: Sparkles },
  { path: '/rules', label: 'Rules', icon: ShieldCheck },
  { path: '/scans', label: 'Scans', icon: ScanLine },
  { path: '/issues', label: 'Issues', icon: AlertTriangle },
  { path: '/alerts', label: 'Alerts', icon: Bell },
  { path: '/healing', label: 'Healing', icon: Wrench },
  { path: '/trust-scores', label: 'Trust Scores', icon: TrendingUp },
  { path: '/audit-trail', label: 'Audit Trail', icon: ScrollText },
  { path: '/connections', label: 'Connections', icon: Database },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();

  const initials = user?.full_name
    ? user.full_name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : '?';

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-pine-950 text-white flex flex-col shrink-0">
        {/* Brand */}
        <div className="px-5 py-5 flex items-center gap-2.5">
          <div className="w-8 h-8 bg-pine-500 rounded-md flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 1L14 5V11L8 15L2 11V5L8 1Z" fill="white" />
            </svg>
          </div>
          <span className="text-lg font-bold tracking-tight">DataSentinel</span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-2 space-y-0.5">
          {navItems.map((item) => {
            const active = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150 ${
                  active
                    ? 'bg-pine-900 text-white border-l-2 border-pine-500 -ml-px'
                    : 'text-gray-400 hover:bg-pine-900 hover:text-white'
                }`}
              >
                <Icon size={18} strokeWidth={active ? 2 : 1.5} />
                <span className={active ? 'font-medium' : ''}>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        {user && (
          <div className="px-4 py-4 border-t border-pine-900">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-pine-700 rounded-full flex items-center justify-center text-sm font-medium text-white shrink-0">
                {initials}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{user.full_name}</div>
                <div className="text-xs text-gray-500">{user.role}</div>
              </div>
            </div>
            <button
              onClick={logout}
              className="mt-3 flex items-center gap-2 text-xs text-gray-500 hover:text-gray-300 transition-colors"
            >
              <LogOut size={14} />
              Sign out
            </button>
          </div>
        )}
      </aside>

      {/* Main content */}
      <main className="flex-1 p-8 overflow-auto">{children}</main>
    </div>
  );
}
