interface Props {
  score: number;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}

const config = {
  sm: { svgSize: 80, radius: 30, stroke: 6, textSize: 'text-base', labelSize: 'text-[10px]' },
  md: { svgSize: 112, radius: 44, stroke: 7, textSize: 'text-xl', labelSize: 'text-xs' },
  lg: { svgSize: 144, radius: 56, stroke: 8, textSize: 'text-2xl', labelSize: 'text-xs' },
};

function getStrokeColor(score: number): string {
  if (score >= 80) return '#50D387'; // pine-500
  if (score >= 60) return '#EAB308'; // yellow-500
  if (score >= 40) return '#F97316'; // orange-500
  return '#EF4444'; // red-500
}

export default function TrustGauge({ score, label, size = 'md' }: Props) {
  const { svgSize, radius, stroke, textSize, labelSize } = config[size];
  const center = svgSize / 2;
  const circumference = 2 * Math.PI * radius;
  const filled = Math.max(0, Math.min(100, score));
  const offset = circumference - (filled / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={svgSize} height={svgSize} className="transform -rotate-90">
        {/* Background ring */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="#E5E7EB"
          strokeWidth={stroke}
        />
        {/* Score ring */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={getStrokeColor(score)}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.8s ease-out, stroke 0.3s' }}
        />
      </svg>
      {/* Centered score */}
      <div
        className="absolute flex flex-col items-center justify-center"
        style={{ width: svgSize, height: svgSize, marginTop: 0 }}
      >
        <span className={`${textSize} font-bold text-gray-800`}>
          {Math.round(score)}
        </span>
      </div>
      {label && <span className={`${labelSize} text-gray-500 mt-0.5 text-center leading-tight`}>{label}</span>}
    </div>
  );
}
