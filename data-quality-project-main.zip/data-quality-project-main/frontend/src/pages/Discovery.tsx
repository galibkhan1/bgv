import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import { listConnections, runDiscovery, listDiscoveryHistory, type Connection, type Rule, type DiscoveryRunEntry } from '../services/api';
import { Sparkles } from 'lucide-react';

export default function Discovery() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedConn, setSelectedConn] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Rule[]>([]);
  const [status, setStatus] = useState('');
  const [history, setHistory] = useState<DiscoveryRunEntry[]>([]);

  useEffect(() => {
    listConnections().then(setConnections).catch(console.error);
    listDiscoveryHistory().then(setHistory).catch(console.error);
  }, []);

  const handleDiscover = async () => {
    if (!selectedConn) return;
    setLoading(true);
    setStatus('Running AI discovery...');
    try {
      const res = await runDiscovery({ connection_id: selectedConn });
      setResults(res.rules);
      const statusMsg = res.status === 'completed'
        ? `Done: ${res.rules_generated} rules generated across ${res.tables_processed} tables`
        : `Partial: ${res.rules_generated} rules generated, ${res.errors?.length || 0} table(s) had errors`;
      setStatus(statusMsg);
      listDiscoveryHistory().then(setHistory).catch(console.error);
    } catch (err: any) {
      setStatus(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const connName = (id: string) => connections.find(c => c.id === id)?.name || id.slice(0, 8);

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">AI Rule Discovery</h1>

      <div className="bg-white rounded-xl border border-pine-200 p-6 mb-6">
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Connection</label>
            <select
              value={selectedConn}
              onChange={(e) => setSelectedConn(e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none"
            >
              <option value="">Select connection...</option>
              {connections.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <button
            onClick={handleDiscover}
            disabled={!selectedConn || loading}
            className="inline-flex items-center gap-2 bg-pine-600 text-white px-5 py-2.5 rounded-lg hover:bg-pine-700 disabled:opacity-50 transition-colors text-sm font-medium"
          >
            <Sparkles size={16} />
            {loading ? 'Discovering...' : 'Run Discovery'}
          </button>
        </div>
        {status && <div className="mt-3 text-sm text-gray-600">{status}</div>}
      </div>

      {results.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-3">Generated Rules</h2>
          <DataTable
            columns={[
              { key: 'table_name', label: 'Table' },
              { key: 'check_name', label: 'Check' },
              { key: 'check_definition', label: 'Definition' },
              { key: 'severity', label: 'Severity', render: (r: Rule) => <StatusBadge status={r.severity} /> },
              { key: 'dimension', label: 'Dimension' },
            ]}
            data={results}
          />
        </div>
      )}

      {history.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-gray-800 mb-3">Discovery History</h2>
          <div className="bg-white rounded-xl border border-pine-200 overflow-hidden">
            <table className="min-w-full divide-y divide-pine-100">
              <thead>
                <tr className="bg-pine-100/60">
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Connection</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Tables</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Rules</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pine-800 uppercase tracking-wider">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pine-100/60">
                {history.map((run) => {
                  const started = run.started_at ? new Date(run.started_at) : null;
                  const completed = run.completed_at ? new Date(run.completed_at) : null;
                  const durationSec = started && completed
                    ? Math.round((completed.getTime() - started.getTime()) / 1000)
                    : null;
                  return (
                    <tr key={run.id} className="hover:bg-pine-50 transition-colors">
                      <td className="px-4 py-3 text-sm text-gray-700">
                        {started ? started.toLocaleString() : '-'}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-700">{connName(run.connection_id)}</td>
                      <td className="px-4 py-3 text-sm">
                        <StatusBadge status={run.status} />
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-700">{run.tables_processed}</td>
                      <td className="px-4 py-3 text-sm font-medium text-gray-800">{run.rules_generated}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {durationSec !== null ? `${durationSec}s` : '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
