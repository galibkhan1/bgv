import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import { listConnections, listScanHistory, triggerScan, type Connection, type Run } from '../services/api';
import { usePolling } from '../hooks/usePolling';
import { ScanLine } from 'lucide-react';

export default function Scans() {
  const [runs, setRuns] = useState<Run[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedConn, setSelectedConn] = useState('');
  const [loading, setLoading] = useState(false);

  const load = () => listScanHistory().then(setRuns).catch(console.error);

  useEffect(() => {
    load();
    listConnections().then(setConnections).catch(console.error);
  }, []);

  usePolling(load, 10000, runs.some((r) => r.status === 'running'));

  const handleTrigger = async () => {
    if (!selectedConn) return;
    setLoading(true);
    try {
      await triggerScan({ connection_id: selectedConn });
      load();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Scans</h1>

      <div className="bg-white rounded-xl border border-pine-200 p-6 mb-6">
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Connection</label>
            <select
              value={selectedConn}
              onChange={(e) => setSelectedConn(e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none"
            >
              <option value="">Select connection...</option>
              {connections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <button
            onClick={handleTrigger}
            disabled={!selectedConn || loading}
            className="inline-flex items-center gap-2 bg-pine-600 text-white px-5 py-2.5 rounded-lg hover:bg-pine-700 disabled:opacity-50 transition-colors text-sm font-medium"
          >
            <ScanLine size={16} />
            {loading ? 'Running...' : 'Trigger Scan'}
          </button>
        </div>
      </div>

      <DataTable
        columns={[
          { key: 'status', label: 'Status', render: (r: Run) => <StatusBadge status={r.status} /> },
          { key: 'engine', label: 'Engine' },
          { key: 'total_checks', label: 'Total' },
          { key: 'passed', label: 'Passed' },
          { key: 'failed', label: 'Failed' },
          { key: 'warnings', label: 'Warnings' },
          { key: 'health_score', label: 'Score', render: (r: Run) => r.health_score != null ? (
            <div className="flex items-center gap-2">
              <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${r.health_score}%`,
                    backgroundColor: r.health_score >= 80 ? '#50D387' : r.health_score >= 60 ? '#EAB308' : '#EF4444',
                  }}
                />
              </div>
              <span className="text-xs text-gray-600">{r.health_score}%</span>
            </div>
          ) : '-' },
          { key: 'created_at', label: 'Date', render: (r: Run) => new Date(r.created_at).toLocaleString() },
        ]}
        data={runs}
      />
    </div>
  );
}
