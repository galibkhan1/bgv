import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import { listAlerts, resolveAlert, type Alert } from '../services/api';
import { Mail, MessageSquare, Check, X, Clock } from 'lucide-react';

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = () => listAlerts().then(setAlerts).catch(console.error);
  useEffect(() => { load(); }, []);

  const handleResolve = async (id: string, action: string) => {
    try {
      setError(null);
      await resolveAlert(id, { action });
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resolve alert');
    }
  };

  const channelIcon = (channel: string) => {
    if (channel === 'slack') return <MessageSquare size={14} className="text-purple-500" />;
    if (channel === 'email') return <Mail size={14} className="text-blue-500" />;
    return null;
  };

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Alerts</h1>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 text-xs font-medium">dismiss</button>
        </div>
      )}

      <DataTable
        columns={[
          { key: 'status', label: 'Status', render: (a: Alert) => <StatusBadge status={a.status} /> },
          { key: 'channel', label: 'Channel', render: (a: Alert) => (
            <div className="flex items-center gap-1.5">
              {channelIcon(a.channel)}
              <span>{a.channel}</span>
            </div>
          )},
          { key: 'recipient', label: 'Recipient' },
          { key: 'message', label: 'Message', render: (a: Alert) => (
            <span className="truncate max-w-xs block text-gray-600">{a.message}</span>
          )},
          { key: 'escalation_level', label: 'Escalation' },
          { key: 'created_at', label: 'Date', render: (a: Alert) => new Date(a.created_at).toLocaleString() },
          { key: 'actions', label: 'Actions', render: (a: Alert) => a.status !== 'resolved' ? (
            <div className="flex gap-1">
              <button
                onClick={() => handleResolve(a.id, 'approve')}
                className="p-1.5 rounded-md hover:bg-emerald-50 text-emerald-600 transition-colors"
                title="Approve"
              >
                <Check size={14} />
              </button>
              <button
                onClick={() => handleResolve(a.id, 'reject')}
                className="p-1.5 rounded-md hover:bg-red-50 text-red-500 transition-colors"
                title="Reject"
              >
                <X size={14} />
              </button>
              <button
                onClick={() => handleResolve(a.id, 'snooze')}
                className="p-1.5 rounded-md hover:bg-purple-50 text-purple-500 transition-colors"
                title="Snooze"
              >
                <Clock size={14} />
              </button>
            </div>
          ) : <span className="text-gray-400 text-xs">{a.resolution_action}</span> },
        ]}
        data={alerts}
      />
    </div>
  );
}
