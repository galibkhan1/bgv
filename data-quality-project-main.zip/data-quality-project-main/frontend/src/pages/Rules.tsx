import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import StatusBadge from '../components/StatusBadge';
import { listRules, createRule, deleteRule, type Rule, type RuleCreate, listConnections, type Connection } from '../services/api';
import { Plus, Trash2 } from 'lucide-react';

export default function Rules() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [tab, setTab] = useState<'all' | 'contracts'>('all');
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<RuleCreate>({
    connection_id: '', table_name: '', check_name: '', check_definition: '',
  });

  const load = () => {
    const params = tab === 'contracts' ? 'is_contract=true' : '';
    listRules(params).then(setRules).catch(console.error);
  };

  useEffect(() => { load(); }, [tab]);
  useEffect(() => { listConnections().then(setConnections).catch(console.error); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await createRule(form);
      setShowModal(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create rule');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Deactivate this rule?')) {
      try {
        await deleteRule(id);
        load();
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to delete rule');
      }
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-gray-800">Rules</h1>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 bg-pine-600 text-white px-4 py-2 rounded-lg hover:bg-pine-700 transition-colors text-sm font-medium"
        >
          <Plus size={16} />
          New Rule
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 text-xs font-medium">dismiss</button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b border-pine-200">
        {(['all', 'contracts'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium transition-colors relative ${
              tab === t
                ? 'text-pine-700'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {t === 'all' ? 'All Rules' : 'Data Contracts'}
            {tab === t && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-pine-500 rounded-full" />
            )}
          </button>
        ))}
      </div>

      <DataTable
        columns={[
          { key: 'table_name', label: 'Table' },
          { key: 'check_name', label: 'Check' },
          { key: 'source', label: 'Source', render: (r: Rule) => <StatusBadge status={r.source} /> },
          { key: 'engine', label: 'Engine' },
          { key: 'severity', label: 'Severity', render: (r: Rule) => <StatusBadge status={r.severity} /> },
          { key: 'actions', label: '', render: (r: Rule) => (
            <button onClick={() => handleDelete(r.id)} className="text-gray-400 hover:text-red-500 transition-colors">
              <Trash2 size={15} />
            </button>
          )},
        ]}
        data={rules}
      />

      <Modal open={showModal} onClose={() => setShowModal(false)} title="New Rule">
        <form onSubmit={handleCreate} className="space-y-4">
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Connection</label>
            <select value={form.connection_id} onChange={(e) => setForm({ ...form, connection_id: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none" required>
              <option value="">Select connection</option>
              {connections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Table name</label>
            <input value={form.table_name} onChange={(e) => setForm({ ...form, table_name: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Check name</label>
            <input value={form.check_name} onChange={(e) => setForm({ ...form, check_name: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">SodaCL definition</label>
            <textarea value={form.check_definition} onChange={(e) => setForm({ ...form, check_definition: e.target.value })} className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm h-24 font-mono focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none" required />
          </div>
          <button type="submit" className="w-full bg-pine-600 text-white px-4 py-2.5 rounded-lg hover:bg-pine-700 transition-colors text-sm font-medium">
            Create Rule
          </button>
        </form>
      </Modal>
    </div>
  );
}
