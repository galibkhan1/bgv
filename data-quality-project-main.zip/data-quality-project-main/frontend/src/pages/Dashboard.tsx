import { useEffect, useState } from 'react';
import TrustGauge from '../components/TrustGauge';
import StatusBadge from '../components/StatusBadge';
import { listTrustScores, listAlerts, listScanHistory, type TrustScore, type Alert, type Run } from '../services/api';
import { Activity, AlertTriangle, ScanLine, Database } from 'lucide-react';

export default function Dashboard() {
  const [scores, setScores] = useState<TrustScore[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [runs, setRuns] = useState<Run[]>([]);

  useEffect(() => {
    listTrustScores('limit=10').then(setScores).catch(console.error);
    listAlerts('limit=5').then(setAlerts).catch(console.error);
    listScanHistory('limit=5').then(setRuns).catch(console.error);
  }, []);

  const avgScore = scores.length > 0
    ? Math.round(scores.reduce((s, t) => s + t.overall, 0) / scores.length)
    : 100;

  const openAlerts = alerts.filter(a => a.status !== 'resolved').length;
  const tablesMonitored = new Set(scores.map(s => s.table_name)).size;

  const kpis = [
    { label: 'Avg Trust Score', value: `${avgScore}%`, icon: Activity, accent: avgScore >= 80 },
    { label: 'Open Alerts', value: openAlerts, icon: AlertTriangle, accent: openAlerts === 0 },
    { label: 'Recent Scans', value: runs.length, icon: ScanLine, accent: true },
    { label: 'Tables Monitored', value: tablesMonitored, icon: Database, accent: true },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Dashboard</h1>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-8">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-white rounded-xl border border-pine-200 p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-lg bg-pine-100 flex items-center justify-center">
                  <Icon size={18} className="text-pine-500" />
                </div>
                <span className="text-sm text-gray-500">{kpi.label}</span>
              </div>
              <div className="text-3xl font-bold text-gray-800">{kpi.value}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Trust Scores */}
        <div className="bg-white rounded-xl border border-pine-200 p-6">
          <h2 className="font-semibold text-gray-800 mb-4">Trust Scores</h2>
          <div className="flex flex-wrap gap-5">
            {scores.map((s) => (
              <div key={s.id} className="relative">
                <TrustGauge score={s.overall} label={s.table_name} size="sm" />
              </div>
            ))}
            {scores.length === 0 && (
              <p className="text-sm text-gray-400">No scores yet. Run a scan to get started.</p>
            )}
          </div>
        </div>

        {/* Recent Scans */}
        <div className="bg-white rounded-xl border border-pine-200 p-6">
          <h2 className="font-semibold text-gray-800 mb-4">Recent Scans</h2>
          <div className="space-y-3">
            {runs.map((r) => (
              <div key={r.id} className="flex items-center justify-between text-sm border-b border-pine-100/60 pb-2 last:border-0 last:pb-0">
                <StatusBadge status={r.status} />
                <div className="flex items-center gap-3 text-gray-500">
                  <span className="text-xs">
                    <span className="text-emerald-600 font-medium">{r.passed}</span>
                    {' / '}
                    <span className="text-red-500 font-medium">{r.failed}</span>
                    {' / '}
                    <span className="text-amber-500 font-medium">{r.warnings}</span>
                  </span>
                  {r.health_score != null && (
                    <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${r.health_score}%`,
                          backgroundColor: r.health_score >= 80 ? '#50D387' : r.health_score >= 60 ? '#EAB308' : '#EF4444',
                        }}
                      />
                    </div>
                  )}
                  <span className="text-xs text-gray-400">{new Date(r.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
            {runs.length === 0 && (
              <p className="text-sm text-gray-400">No scans yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
