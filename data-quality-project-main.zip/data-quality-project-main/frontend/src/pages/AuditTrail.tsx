import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import { listAuditEntries, type AuditEntry } from '../services/api';
import { Filter } from 'lucide-react';

export default function AuditTrail() {
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [entityFilter, setEntityFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('');

  const load = () => {
    const params = new URLSearchParams();
    if (entityFilter) params.set('entity_type', entityFilter);
    if (actionFilter) params.set('action', actionFilter);
    listAuditEntries(params.toString()).then(setEntries).catch(console.error);
  };

  useEffect(() => { load(); }, [entityFilter, actionFilter]);

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Audit Trail</h1>

      {/* Filter bar */}
      <div className="bg-white rounded-xl border border-pine-200 p-4 mb-6 flex items-center gap-4">
        <Filter size={16} className="text-gray-400" />
        <div>
          <label className="block text-[10px] font-medium text-gray-500 uppercase tracking-wider mb-1">Entity Type</label>
          <select
            value={entityFilter}
            onChange={(e) => setEntityFilter(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none"
          >
            <option value="">All</option>
            <option value="healing_proposal">Healing</option>
            <option value="alert">Alert</option>
            <option value="rule">Rule</option>
            <option value="connection">Connection</option>
            <option value="scan">Scan</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-medium text-gray-500 uppercase tracking-wider mb-1">Action</label>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none"
          >
            <option value="">All</option>
            <option value="create">Create</option>
            <option value="update">Update</option>
            <option value="delete">Delete</option>
            <option value="execute">Execute</option>
            <option value="approve">Approve</option>
            <option value="reject">Reject</option>
            <option value="login">Login</option>
          </select>
        </div>
        {(entityFilter || actionFilter) && (
          <button
            onClick={() => { setEntityFilter(''); setActionFilter(''); }}
            className="text-xs text-pine-600 hover:text-pine-700 font-medium ml-auto"
          >
            Clear filters
          </button>
        )}
      </div>

      <DataTable
        columns={[
          { key: 'action', label: 'Action', render: (e: AuditEntry) => <StatusBadge status={e.action} /> },
          { key: 'entity_type', label: 'Entity' },
          { key: 'entity_id', label: 'Entity ID', render: (e: AuditEntry) => (
            <span className="font-mono text-xs text-gray-500">{e.entity_id.substring(0, 8)}...</span>
          )},
          { key: 'justification', label: 'Justification', render: (e: AuditEntry) => (
            <span className="text-gray-600">{e.justification || '-'}</span>
          )},
          { key: 'ip_address', label: 'IP' },
          { key: 'created_at', label: 'Date', render: (e: AuditEntry) => new Date(e.created_at).toLocaleString() },
        ]}
        data={entries}
      />
    </div>
  );
}
