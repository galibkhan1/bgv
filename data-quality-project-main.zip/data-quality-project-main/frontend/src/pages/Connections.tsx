import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import { listConnections, createConnection, deleteConnection, type Connection, type ConnectionCreate } from '../services/api';
import { Plus, Trash2, Database, CircleDot } from 'lucide-react';

const dbIcons: Record<string, string> = {
  postgresql: 'PG',
  mysql: 'MY',
  snowflake: 'SF',
  redshift: 'RS',
};

export default function Connections() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<ConnectionCreate>({
    name: '', host: '', database: '', port: 5432, schema_name: 'public', db_type: 'postgresql',
  });

  const load = () => listConnections().then(setConnections).catch(console.error);
  useEffect(() => { load(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await createConnection(form);
      setShowModal(false);
      setForm({ name: '', host: '', database: '', port: 5432, schema_name: 'public', db_type: 'postgresql' });
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create connection');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Deactivate this connection?')) {
      try {
        await deleteConnection(id);
        load();
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to delete connection');
      }
    }
  };

  const inputClass = "w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none";

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-gray-800">Connections</h1>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 bg-pine-600 text-white px-4 py-2 rounded-lg hover:bg-pine-700 transition-colors text-sm font-medium"
        >
          <Plus size={16} />
          New Connection
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 text-xs font-medium">dismiss</button>
        </div>
      )}

      <DataTable
        columns={[
          { key: 'name', label: 'Name', render: (c: Connection) => (
            <div className="flex items-center gap-2">
              <Database size={14} className="text-pine-500" />
              <span className="font-medium text-gray-800">{c.name}</span>
            </div>
          )},
          { key: 'db_type', label: 'Type', render: (c: Connection) => (
            <span className="inline-flex items-center px-2 py-0.5 rounded bg-pine-100 text-pine-800 text-xs font-mono font-medium">
              {dbIcons[c.db_type] || c.db_type}
            </span>
          )},
          { key: 'host', label: 'Host' },
          { key: 'port', label: 'Port' },
          { key: 'database', label: 'Database' },
          { key: 'schema_name', label: 'Schema' },
          { key: 'is_active', label: 'Status', render: (c: Connection) => (
            <div className="flex items-center gap-1.5">
              <CircleDot size={12} className={c.is_active ? 'text-emerald-500' : 'text-gray-400'} />
              <span className={`text-xs ${c.is_active ? 'text-emerald-600' : 'text-gray-400'}`}>
                {c.is_active ? 'Active' : 'Inactive'}
              </span>
            </div>
          )},
          { key: 'created_at', label: 'Created', render: (c: Connection) => new Date(c.created_at).toLocaleString() },
          { key: 'actions', label: '', render: (c: Connection) => (
            <button onClick={() => handleDelete(c.id)} className="text-gray-400 hover:text-red-500 transition-colors">
              <Trash2 size={15} />
            </button>
          )},
        ]}
        data={connections}
      />

      <Modal open={showModal} onClose={() => setShowModal(false)} title="New Connection">
        <form onSubmit={handleCreate} className="space-y-3">
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Name</label>
            <input placeholder="Connection name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Database type</label>
            <select value={form.db_type} onChange={(e) => setForm({ ...form, db_type: e.target.value })} className={inputClass}>
              <option value="postgresql">PostgreSQL</option>
              <option value="mysql">MySQL</option>
              <option value="snowflake">Snowflake</option>
              <option value="redshift">Redshift</option>
            </select>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Host</label>
              <input placeholder="localhost" value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} className={inputClass} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Port</label>
              <input type="number" value={form.port} onChange={(e) => setForm({ ...form, port: parseInt(e.target.value) })} className={inputClass} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Database</label>
              <input placeholder="mydb" value={form.database} onChange={(e) => setForm({ ...form, database: e.target.value })} className={inputClass} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Schema</label>
              <input placeholder="public" value={form.schema_name} onChange={(e) => setForm({ ...form, schema_name: e.target.value })} className={inputClass} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Username</label>
              <input value={form.username || ''} onChange={(e) => setForm({ ...form, username: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
              <input type="password" value={form.password || ''} onChange={(e) => setForm({ ...form, password: e.target.value })} className={inputClass} />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Secret ARN (optional)</label>
            <input value={form.secret_arn || ''} onChange={(e) => setForm({ ...form, secret_arn: e.target.value })} className={inputClass} />
          </div>
          <button type="submit" className="w-full bg-pine-600 text-white px-4 py-2.5 rounded-lg hover:bg-pine-700 transition-colors text-sm font-medium mt-2">
            Create Connection
          </button>
        </form>
      </Modal>
    </div>
  );
}
