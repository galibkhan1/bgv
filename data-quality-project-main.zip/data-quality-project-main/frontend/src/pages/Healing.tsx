import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { listHealingProposals, approveHealing, rejectHealing, executeHealing, type HealingProposal } from '../services/api';
import { Eye, Check, X, Play, AlertTriangle } from 'lucide-react';

export default function Healing() {
  const [proposals, setProposals] = useState<HealingProposal[]>([]);
  const [selected, setSelected] = useState<HealingProposal | null>(null);
  const [execConnId, setExecConnId] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = () => listHealingProposals().then(setProposals).catch(console.error);
  useEffect(() => { load(); }, []);

  const handleApprove = async (id: string) => {
    try {
      setError(null);
      await approveHealing(id);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to approve');
    }
  };

  const handleReject = async (id: string) => {
    try {
      setError(null);
      await rejectHealing(id);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reject');
    }
  };

  const handleExecute = async (id: string) => {
    if (!execConnId) return alert('Enter connection ID');
    try {
      setError(null);
      await executeHealing(id, execConnId);
      setSelected(null);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Execution failed');
    }
  };

  const riskColor = (level: string) => {
    if (level === 'critical' || level === 'high') return 'text-red-500';
    if (level === 'medium') return 'text-amber-500';
    return 'text-emerald-500';
  };

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Self-Healing Proposals</h1>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 text-xs font-medium">dismiss</button>
        </div>
      )}

      <DataTable
        columns={[
          { key: 'status', label: 'Status', render: (p: HealingProposal) => <StatusBadge status={p.status} /> },
          { key: 'risk_level', label: 'Risk', render: (p: HealingProposal) => (
            <div className="flex items-center gap-1.5">
              <AlertTriangle size={14} className={riskColor(p.risk_level)} />
              <span className={`text-sm font-medium ${riskColor(p.risk_level)}`}>{p.risk_level}</span>
            </div>
          )},
          { key: 'confidence', label: 'Confidence', render: (p: HealingProposal) => (
            <div className="flex items-center gap-2">
              <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-pine-500 rounded-full" style={{ width: `${p.confidence * 100}%` }} />
              </div>
              <span className="text-xs">{(p.confidence * 100).toFixed(0)}%</span>
            </div>
          )},
          { key: 'affected_rows_estimate', label: 'Est. Rows' },
          { key: 'actual_rows_affected', label: 'Actual Rows', render: (p: HealingProposal) => p.actual_rows_affected ?? '-' },
          { key: 'created_at', label: 'Date', render: (p: HealingProposal) => new Date(p.created_at).toLocaleString() },
          { key: 'actions', label: 'Actions', render: (p: HealingProposal) => (
            <div className="flex gap-1">
              <button onClick={() => setSelected(p)} className="p-1.5 rounded-md hover:bg-gray-100 text-gray-500 transition-colors" title="View">
                <Eye size={14} />
              </button>
              {p.status === 'pending' && (
                <>
                  <button onClick={() => handleApprove(p.id)} className="p-1.5 rounded-md hover:bg-emerald-50 text-emerald-600 transition-colors" title="Approve">
                    <Check size={14} />
                  </button>
                  <button onClick={() => handleReject(p.id)} className="p-1.5 rounded-md hover:bg-red-50 text-red-500 transition-colors" title="Reject">
                    <X size={14} />
                  </button>
                </>
              )}
            </div>
          )},
        ]}
        data={proposals}
      />

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Healing Proposal Detail">
        {selected && (
          <div className="space-y-5">
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Proposed SQL</label>
              <pre className="mt-1.5 bg-pine-50 border border-pine-200 p-3 rounded-lg text-sm font-mono overflow-auto max-h-40 text-gray-800">{selected.proposed_sql}</pre>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Rollback SQL</label>
              <pre className="mt-1.5 bg-gray-50 border border-gray-200 p-3 rounded-lg text-sm font-mono overflow-auto max-h-40 text-gray-700">{selected.rollback_sql}</pre>
            </div>
            {selected.explanation && (
              <div>
                <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Explanation</label>
                <p className="text-sm text-gray-700 mt-1 leading-relaxed">{selected.explanation}</p>
              </div>
            )}
            {selected.execution_result && (
              <div>
                <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Execution Result</label>
                <p className="text-sm text-gray-700 mt-1">{selected.execution_result}</p>
              </div>
            )}
            {error && <p className="text-red-600 text-sm">{error}</p>}
            {selected.status === 'approved' && (
              <div className="border-t border-pine-100 pt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Connection ID for execution</label>
                <input
                  value={execConnId}
                  onChange={(e) => setExecConnId(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm mb-3 focus:ring-2 focus:ring-pine-500 focus:border-pine-500 outline-none font-mono"
                  placeholder="Connection UUID"
                />
                <button
                  onClick={() => handleExecute(selected.id)}
                  className="inline-flex items-center gap-2 bg-pine-600 text-white px-4 py-2 rounded-lg hover:bg-pine-700 transition-colors text-sm font-medium"
                >
                  <Play size={14} />
                  Execute
                </button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
