import { useEffect, useState } from 'react';
import DataTable from '../components/DataTable';
import StatusBadge from '../components/StatusBadge';
import { listAllIssues, analyzeRCA, type Issue } from '../services/api';
import { Search, Brain } from 'lucide-react';

export default function Issues() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [rcaLoading, setRcaLoading] = useState(false);

  useEffect(() => {
    listAllIssues().then(setIssues).catch(console.error);
  }, []);

  const handleRCA = async (issue: Issue) => {
    setSelectedIssue(issue);
    if (issue.rca_summary) return;
    setRcaLoading(true);
    try {
      const result = await analyzeRCA(issue.id);
      setIssues((prev) => prev.map((i) =>
        i.id === issue.id ? { ...i, rca_summary: result.summary, rca_pattern: result.pattern, rca_confidence: result.confidence } : i
      ));
      setSelectedIssue({ ...issue, rca_summary: result.summary, rca_pattern: result.pattern, rca_confidence: result.confidence });
    } catch (err) {
      console.error(err);
    } finally {
      setRcaLoading(false);
    }
  };

  return (
    <div className="flex gap-6">
      <div className="flex-1 min-w-0">
        <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Issues</h1>
        <DataTable
          columns={[
            { key: 'severity', label: 'Severity', render: (i: Issue) => <StatusBadge status={i.severity} /> },
            { key: 'table_name', label: 'Table' },
            { key: 'check_name', label: 'Check' },
            { key: 'status', label: 'Status', render: (i: Issue) => <StatusBadge status={i.status} /> },
            { key: 'actual_value', label: 'Actual' },
            { key: 'created_at', label: 'Date', render: (i: Issue) => new Date(i.created_at).toLocaleString() },
          ]}
          data={issues}
          onRowClick={handleRCA}
        />
      </div>

      {selectedIssue && (
        <div className="w-80 shrink-0">
          <div className="bg-white rounded-xl border border-pine-200 p-5 sticky top-8">
            <div className="flex items-center gap-2 mb-4">
              <Brain size={18} className="text-pine-500" />
              <h3 className="font-semibold text-gray-800">RCA Analysis</h3>
            </div>
            <div className="text-sm space-y-3">
              <div>
                <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Table</span>
                <div className="text-gray-800 mt-0.5">{selectedIssue.table_name}</div>
              </div>
              <div>
                <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Check</span>
                <div className="text-gray-800 mt-0.5">{selectedIssue.check_name}</div>
              </div>

              <div className="border-t border-pine-100 pt-3">
                {rcaLoading ? (
                  <div className="flex items-center gap-2 text-pine-600">
                    <Search size={14} className="animate-pulse" />
                    <span className="text-sm">Analyzing root cause...</span>
                  </div>
                ) : selectedIssue.rca_summary ? (
                  <div className="space-y-3">
                    <div>
                      <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Summary</span>
                      <div className="text-gray-700 mt-0.5 leading-relaxed">{selectedIssue.rca_summary}</div>
                    </div>
                    <div>
                      <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Pattern</span>
                      <div className="mt-1"><StatusBadge status={selectedIssue.rca_pattern || ''} /></div>
                    </div>
                    <div>
                      <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Confidence</span>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-pine-500 rounded-full"
                            style={{ width: `${(selectedIssue.rca_confidence || 0) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium text-gray-600">
                          {((selectedIssue.rca_confidence || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-gray-400 text-sm">Click an issue to analyze</div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
