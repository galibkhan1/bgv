import { useEffect, useState } from 'react';
import TrustGauge from '../components/TrustGauge';
import DataTable from '../components/DataTable';
import { listTrustScores, getTableTrustHistory, type TrustScore } from '../services/api';
import { ArrowLeft } from 'lucide-react';

export default function TrustScores() {
  const [scores, setScores] = useState<TrustScore[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [history, setHistory] = useState<TrustScore[]>([]);

  useEffect(() => {
    listTrustScores().then(setScores).catch(console.error);
  }, []);

  const handleTableClick = async (table: string) => {
    setSelectedTable(table);
    const h = await getTableTrustHistory(table);
    setHistory(h);
  };

  // Deduplicate to latest score per table
  const latestByTable = new Map<string, TrustScore>();
  for (const s of scores) {
    if (!latestByTable.has(s.table_name)) {
      latestByTable.set(s.table_name, s);
    }
  }
  const tableScores = Array.from(latestByTable.values());

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-gray-800 mb-6">Trust Scores</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
        {tableScores.map((s) => (
          <div
            key={s.id}
            className="cursor-pointer bg-white rounded-xl border border-pine-200 p-4 hover:border-pine-400 hover:shadow-sm transition-all duration-150 flex flex-col items-center"
            onClick={() => handleTableClick(s.table_name)}
          >
            <div className="relative">
              <TrustGauge score={s.overall} label={s.table_name} size="sm" />
            </div>
          </div>
        ))}
        {tableScores.length === 0 && (
          <div className="col-span-full text-center text-gray-400 py-10 text-sm">
            No trust scores yet. Run a scan first.
          </div>
        )}
      </div>

      {selectedTable && (
        <div className="bg-white rounded-xl border border-pine-200 p-6">
          <div className="flex items-center gap-3 mb-5">
            <button
              onClick={() => setSelectedTable(null)}
              className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors"
            >
              <ArrowLeft size={16} />
            </button>
            <h2 className="font-semibold text-gray-800">History for {selectedTable}</h2>
          </div>

          {history[0] && (
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[
                { score: history[0].overall, label: 'Overall' },
                { score: history[0].completeness, label: 'Completeness' },
                { score: history[0].accuracy, label: 'Accuracy' },
                { score: history[0].timeliness, label: 'Timeliness' },
              ].map((g) => (
                <div key={g.label} className="flex flex-col items-center p-3 bg-pine-50 rounded-lg">
                  <div className="relative">
                    <TrustGauge score={g.score} label={g.label} size="sm" />
                  </div>
                </div>
              ))}
            </div>
          )}

          <DataTable
            columns={[
              { key: 'overall', label: 'Overall' },
              { key: 'completeness', label: 'Completeness' },
              { key: 'accuracy', label: 'Accuracy' },
              { key: 'timeliness', label: 'Timeliness' },
              { key: 'created_at', label: 'Date', render: (s: TrustScore) => new Date(s.created_at).toLocaleString() },
            ]}
            data={history}
          />
        </div>
      )}
    </div>
  );
}
