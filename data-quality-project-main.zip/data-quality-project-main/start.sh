#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"
BACKEND_PID_FILE="$PROJECT_DIR/.backend.pid"
FRONTEND_PID_FILE="$PROJECT_DIR/.frontend.pid"

start_backend() {
    if [ -f "$BACKEND_PID_FILE" ] && kill -0 "$(cat "$BACKEND_PID_FILE")" 2>/dev/null; then
        echo "Backend already running (PID $(cat "$BACKEND_PID_FILE"))"
        return
    fi
    source "$VENV_DIR/bin/activate"
    cd "$PROJECT_DIR"
    PYTHONPATH="$PROJECT_DIR/backend/src:$PROJECT_DIR" \
    nohup uvicorn data_sentinel.main:app --host 0.0.0.0 --port 8000 --reload \
        > "$PROJECT_DIR/backend.log" 2>&1 &
    echo $! > "$BACKEND_PID_FILE"
    echo "Backend started (PID $!), log: backend.log"
}

start_frontend() {
    if [ -f "$FRONTEND_PID_FILE" ] && kill -0 "$(cat "$FRONTEND_PID_FILE")" 2>/dev/null; then
        echo "Frontend already running (PID $(cat "$FRONTEND_PID_FILE"))"
        return
    fi
    cd "$PROJECT_DIR/frontend"
    if [ ! -d "node_modules" ]; then
        echo "Installing frontend dependencies..."
        npm install
    fi
    nohup npm run dev > "$PROJECT_DIR/frontend.log" 2>&1 &
    echo $! > "$FRONTEND_PID_FILE"
    echo "Frontend started (PID $!), log: frontend.log"
}

stop_service() {
    local pid_file=$1
    local name=$2
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            echo "$name stopped (PID $pid)"
        fi
        rm -f "$pid_file"
    else
        echo "$name not running"
    fi
}

case "${1:-}" in
    start)
        start_backend
        start_frontend
        echo ""
        echo "Backend:  http://localhost:8000"
        echo "Frontend: http://localhost:5173"
        echo "API docs: http://localhost:8000/docs"
        ;;
    stop)
        stop_service "$FRONTEND_PID_FILE" "Frontend"
        stop_service "$BACKEND_PID_FILE" "Backend"
        ;;
    restart)
        $0 stop
        sleep 1
        $0 start
        ;;
    status)
        for svc in backend frontend; do
            pid_file="$PROJECT_DIR/.${svc}.pid"
            if [ -f "$pid_file" ] && kill -0 "$(cat "$pid_file")" 2>/dev/null; then
                echo "$svc: running (PID $(cat "$pid_file"))"
            else
                echo "$svc: stopped"
            fi
        done
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
