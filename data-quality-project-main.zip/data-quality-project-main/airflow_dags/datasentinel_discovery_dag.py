"""DataSentinel Discovery DAG — daily AI rule generation.

Airflow 3.x compatible: uses airflow.providers.standard.operators.python,
schedule= parameter, no days_ago().
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

default_args = {
    "owner": "datasentinel",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

# Configurable path via env var (#20)
PROJECT_ROOT = os.environ.get("DATASENTINEL_PROJECT_ROOT")
if not PROJECT_ROOT:
    raise RuntimeError("DATASENTINEL_PROJECT_ROOT environment variable must be set")


def run_discovery(**context):
    import asyncio
    import sys
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "backend/src"))
    sys.path.insert(0, PROJECT_ROOT)

    from data_sentinel.core.database import async_session_factory
    from data_sentinel.models.connection import DataConnection
    from data_sentinel.services.connection_service import get_connection_password
    from data_sentinel.services.discovery_engine import discover_rules_for_table, list_tables_for_connection
    from sqlalchemy import select

    async def _run():
        async with async_session_factory() as session:
            result = await session.execute(
                select(DataConnection).where(DataConnection.is_active.is_(True))
            )
            connections = result.scalars().all()

            total_rules = 0
            for conn in connections:
                password = await get_connection_password(conn)
                tables = await list_tables_for_connection(conn, password)
                for table in tables:
                    try:
                        rules = await discover_rules_for_table(session, conn, table, skip_existing=True)
                        total_rules += len(rules)
                    except Exception as e:
                        print(f"Discovery failed for {conn.name}/{table}: {e}")

            return total_rules

    count = asyncio.run(_run())
    print(f"Discovery complete: {count} new rules generated")


with DAG(
    dag_id="datasentinel_discovery",
    default_args=default_args,
    description="Daily AI rule discovery for all connections",
    schedule="0 2 * * *",
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["datasentinel"],
) as dag:
    discover_task = PythonOperator(
        task_id="run_discovery",
        python_callable=run_discovery,
    )
