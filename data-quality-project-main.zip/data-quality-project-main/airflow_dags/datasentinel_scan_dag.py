"""DataSentinel Scan DAG — scheduled DQ scans every 6 hours.

Airflow 3.x compatible.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

default_args = {
    "owner": "datasentinel",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

PROJECT_ROOT = os.environ.get("DATASENTINEL_PROJECT_ROOT")
if not PROJECT_ROOT:
    raise RuntimeError("DATASENTINEL_PROJECT_ROOT environment variable must be set")


def run_scans(**context):
    import asyncio
    import sys
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "backend/src"))
    sys.path.insert(0, PROJECT_ROOT)

    from data_sentinel.core.database import async_session_factory
    from data_sentinel.models.connection import DataConnection
    from data_sentinel.services.scan_engine import trigger_scan
    from sqlalchemy import select

    async def _run():
        async with async_session_factory() as session:
            result = await session.execute(
                select(DataConnection).where(DataConnection.is_active.is_(True))
            )
            connections = result.scalars().all()

            for conn in connections:
                run = await trigger_scan(session, conn.id)
                print(f"Scan for {conn.name}: {run.status} "
                      f"(passed={run.passed}, failed={run.failed})")

    asyncio.run(_run())


with DAG(
    dag_id="datasentinel_scan",
    default_args=default_args,
    description="Scheduled DQ scans every 6 hours",
    schedule="0 */6 * * *",
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["datasentinel"],
) as dag:
    scan_task = PythonOperator(
        task_id="run_scans",
        python_callable=run_scans,
    )
