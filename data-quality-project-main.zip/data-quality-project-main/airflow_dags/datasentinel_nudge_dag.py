"""DataSentinel Nudge DAG — 15-min alert escalation for unresolved alerts.

Airflow 3.x compatible.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

default_args = {
    "owner": "datasentinel",
    "depends_on_past": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=2),
}

PROJECT_ROOT = os.environ.get("DATASENTINEL_PROJECT_ROOT")
if not PROJECT_ROOT:
    raise RuntimeError("DATASENTINEL_PROJECT_ROOT environment variable must be set")


def escalate_alerts(**context):
    import asyncio
    import sys
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "backend/src"))
    sys.path.insert(0, PROJECT_ROOT)

    from datetime import timezone
    from data_sentinel.core.database import async_session_factory
    from data_sentinel.models.alert import Alert
    from data_sentinel.services.nudge_engine import send_slack_alert, send_email_alert
    from sqlalchemy import select

    async def _run():
        async with async_session_factory() as session:
            # Find unresolved alerts older than 1 hour
            cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
            result = await session.execute(
                select(Alert).where(
                    Alert.status.in_(["sent", "escalated"]),
                    Alert.created_at < cutoff,
                )
            )
            stale_alerts = result.scalars().all()

            MAX_ESCALATION_LEVEL = 5
            for alert in stale_alerts:
                if alert.escalation_level >= MAX_ESCALATION_LEVEL:
                    alert.status = "expired"
                    print(f"Alert {alert.id} expired after {alert.escalation_level} escalations")
                    continue

                alert.escalation_level += 1
                alert.status = "escalated"

                # Re-send notifications on escalation
                escalation_msg = (
                    f"*ESCALATION (Level {alert.escalation_level})*\n{alert.message}"
                )
                try:
                    if alert.channel == "slack":
                        await send_slack_alert(
                            alert.recipient, escalation_msg, alert.resolution_token,
                        )
                    elif alert.channel == "email":
                        await send_email_alert(
                            alert.recipient,
                            f"[ESCALATION L{alert.escalation_level}] DataSentinel Alert",
                            escalation_msg,
                            alert.resolution_token,
                        )
                except Exception as e:
                    print(f"Failed to send escalation for alert {alert.id}: {e}")

                print(f"Escalated alert {alert.id} to level {alert.escalation_level}")

            await session.commit()
            print(f"Escalated {len(stale_alerts)} alerts")

    asyncio.run(_run())


def expire_snoozed_issues(**context):
    """Un-snooze issues whose snooze period has expired (#15)."""
    import asyncio
    import sys
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "backend/src"))
    sys.path.insert(0, PROJECT_ROOT)

    from datetime import timezone
    from data_sentinel.core.database import async_session_factory
    from data_sentinel.models.issue import DQIssue
    from sqlalchemy import select

    async def _run():
        async with async_session_factory() as session:
            now = datetime.now(timezone.utc)
            result = await session.execute(
                select(DQIssue).where(
                    DQIssue.status == "snoozed",
                    DQIssue.snoozed_until < now,
                )
            )
            expired = result.scalars().all()
            for issue in expired:
                issue.status = "open"
                issue.snoozed_until = None
                print(f"Un-snoozed issue {issue.id}")

            await session.commit()
            print(f"Un-snoozed {len(expired)} issues")

    asyncio.run(_run())


with DAG(
    dag_id="datasentinel_nudge",
    default_args=default_args,
    description="15-min alert escalation + snooze expiration",
    schedule="*/15 * * * *",
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["datasentinel"],
) as dag:
    nudge_task = PythonOperator(
        task_id="escalate_alerts",
        python_callable=escalate_alerts,
    )
    snooze_task = PythonOperator(
        task_id="expire_snoozed_issues",
        python_callable=expire_snoozed_issues,
    )
    nudge_task >> snooze_task
