"""DataSentinel Trust Score DAG — daily trust computation + degradation detection.

Airflow 3.x compatible.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

default_args = {
    "owner": "datasentinel",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

PROJECT_ROOT = os.environ.get("DATASENTINEL_PROJECT_ROOT")
if not PROJECT_ROOT:
    raise RuntimeError("DATASENTINEL_PROJECT_ROOT environment variable must be set")


def compute_and_detect(**context):
    import asyncio
    import sys
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "backend/src"))
    sys.path.insert(0, PROJECT_ROOT)

    from data_sentinel.core.database import async_session_factory
    from data_sentinel.models.rule import DQRule
    from data_sentinel.models.trust_score import TrustScore
    from data_sentinel.services.trust_score_engine import compute_trust_score
    from sqlalchemy import select, distinct

    async def _run():
        async with async_session_factory() as session:
            result = await session.execute(
                select(distinct(DQRule.table_name), DQRule.connection_id)
                .where(DQRule.is_active.is_(True))
            )
            tables = result.all()

            for table_name, connection_id in tables:
                # Get previous score
                prev_result = await session.execute(
                    select(TrustScore)
                    .where(
                        TrustScore.connection_id == connection_id,
                        TrustScore.table_name == table_name,
                    )
                    .order_by(TrustScore.created_at.desc())
                    .limit(1)
                )
                prev_score = prev_result.scalar_one_or_none()

                # Compute new score
                new_score = await compute_trust_score(session, connection_id, table_name)

                # Detect degradation (>10% drop)
                if prev_score and (prev_score.overall - new_score.overall) > 10:
                    print(f"DEGRADATION ALERT: {table_name} dropped from "
                          f"{prev_score.overall} to {new_score.overall}")

    asyncio.run(_run())


with DAG(
    dag_id="datasentinel_trust",
    default_args=default_args,
    description="Daily trust score computation + degradation detection",
    schedule="0 7 * * *",
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["datasentinel"],
) as dag:
    trust_task = PythonOperator(
        task_id="compute_and_detect",
        python_callable=compute_and_detect,
    )
