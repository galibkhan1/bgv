# DataSentinel

Data Quality & Observability Platform — AI-powered rule discovery, automated scans, self-healing, trust scoring, and Slack/Email alerting.

## Features

- **AI Rule Discovery**: AWS Bedrock (Claude Sonnet) analyzes table DDL + sample data to generate SodaCL quality checks
- **Automated Scans**: Soda Core 3.5.x and Great Expectations integration with scheduled execution
- **Root Cause Analysis**: AI-powered investigation of data quality failures
- **Self-Healing**: AI proposes safe SQL fixes with dry-run validation and rollback support
- **Trust Scores**: Per-table 0-100 scores across completeness, accuracy, and timeliness dimensions
- **Alerting**: Slack Block Kit + AWS SES email with actionable resolve/snooze buttons
- **Immutable Audit Trail**: PostgreSQL trigger-enforced append-only log
- **Multi-Connection**: Manage multiple database targets with AWS Secrets Manager support

## Quick Start

```bash
# 1. Setup (creates venv, installs deps, creates DB, runs migrations)
./setup.sh

# 2. Edit environment config
vim .env

# 3. Create admin user
source .venv/bin/activate
python backend/scripts/create_admin.py

# 4. Start both backend + frontend
./start.sh start
```

- Backend API: http://localhost:8000 (Swagger docs at /docs)
- Frontend: http://localhost:5173
- Health check: http://localhost:8000/healthz

## Architecture

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.11+, FastAPI, SQLAlchemy 2.x (async), Alembic |
| Frontend | React 18, TypeScript 5, Vite 5, Tailwind CSS 3.4, lucide-react |
| Database | PostgreSQL with UUID PKs, JSONB, triggers |
| AI | Ollama Cloud API (native Python client) |
| DQ Engines | Soda Core 3.5.x |
| Scheduling | Apache Airflow 3.x |
| Alerting | Slack API, AWS SES |

## Frontend Design

The frontend uses a **Pine Labs-inspired** brand identity:

- **Color palette**: Custom `pine` green scale (deep forest `#001A12` to light `#F5FDF8`)
- **Accent**: Bright emerald `#50D387` (Pine Labs brand green)
- **Typography**: Roboto (Google Fonts CDN)
- **Icons**: `lucide-react` with consistent 24px stroke design
- **Key components**: SVG ring gauges for trust scores, dot-prefix status pills, dark pine sidebar with icon navigation, split-layout login

## Project Structure

```
backend/src/data_sentinel/   # FastAPI application
frontend/src/                 # React SPA (10 pages + Login)
├── components/              # Layout, DataTable, TrustGauge (SVG ring), Modal, StatusBadge (dot pills)
├── pages/                   # Dashboard, Discovery, Rules, Scans, Issues, Alerts, Healing, TrustScores, AuditTrail, Connections
├── services/api.ts          # Fetch-based API client
└── context/AuthContext.tsx   # JWT auth provider
airflow_dags/                 # 4 scheduled DAGs
shared_utils/                 # Prompts, YAML parser, constants
```

## License

Proprietary
