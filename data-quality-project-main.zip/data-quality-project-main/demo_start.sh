#!/bin/bash
# ─── DataSentinel Demo Start ─────────────────────────────────────
# One-command start for Pine Labs client demo
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJECT_DIR/.venv"
BACKEND_PID_FILE="$PROJECT_DIR/.backend.pid"
FRONTEND_PID_FILE="$PROJECT_DIR/.frontend.pid"

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║        DataSentinel — Starting Demo          ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

# ── Check prerequisites ─────────────────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "  ERROR: Python venv not found at $VENV_DIR"
    echo "  Run: python3 -m venv .venv && pip install -r requirements.txt"
    exit 1
fi

if ! pg_isready -h localhost -p 5432 >/dev/null 2>&1; then
    echo "  ERROR: PostgreSQL not running on port 5432"
    echo "  Start Postgres.app first."
    exit 1
fi

echo "  Prerequisites OK"

# ── Stop any existing services ───────────────────────────────────
for pid_file in "$BACKEND_PID_FILE" "$FRONTEND_PID_FILE"; do
    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file")
        kill "$pid" 2>/dev/null || true
        rm -f "$pid_file"
    fi
done
# Kill orphans on ports
lsof -ti:8000 2>/dev/null | xargs kill 2>/dev/null || true
lsof -ti:5173 2>/dev/null | xargs kill 2>/dev/null || true
sleep 1

# ── Start Backend ────────────────────────────────────────────────
echo "  Starting backend (port 8000)..."
source "$VENV_DIR/bin/activate"
cd "$PROJECT_DIR"
PYTHONPATH="$PROJECT_DIR/backend/src:$PROJECT_DIR" \
nohup uvicorn data_sentinel.main:app --host 0.0.0.0 --port 8000 --reload \
    > "$PROJECT_DIR/backend.log" 2>&1 &
echo $! > "$BACKEND_PID_FILE"
echo "    PID: $!"

# ── Start Frontend ───────────────────────────────────────────────
echo "  Starting frontend (port 5173)..."
cd "$PROJECT_DIR/frontend"
if [ ! -d "node_modules" ]; then
    echo "    Installing npm dependencies (first time)..."
    npm install --silent
fi
nohup npm run dev > "$PROJECT_DIR/frontend.log" 2>&1 &
echo $! > "$FRONTEND_PID_FILE"
echo "    PID: $!"

# ── Wait for backend to be ready ────────────────────────────────
echo ""
echo "  Waiting for backend..."
for i in $(seq 1 20); do
    if curl -s http://localhost:8000/healthz >/dev/null 2>&1; then
        echo "  Backend ready!"
        break
    fi
    if [ "$i" -eq 20 ]; then
        echo "  Backend may still be starting — check backend.log"
    fi
    sleep 1
done

sleep 2

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║          DataSentinel is RUNNING             ║"
echo "  ╠══════════════════════════════════════════════╣"
echo "  ║  App:      http://localhost:5173             ║"
echo "  ║  API:      http://localhost:8000             ║"
echo "  ║  Swagger:  http://localhost:8000/docs        ║"
echo "  ╠══════════════════════════════════════════════╣"
echo "  ║  Login:  admin@datasentinel.dev              ║"
echo "  ║  Pass:   admin123                            ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""
echo "  To stop: ./demo_stop.sh"
echo ""
