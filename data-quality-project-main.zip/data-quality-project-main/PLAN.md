# DataSentinel - Implementation Plan

## Context

Build "DataSentinel," a production-ready Data Quality & Observability platform at `/Volumes/T9 1/Products/data_quality_tool`. The design evolves proven patterns from the existing pulse-dq project, replacing Ollama with AWS Bedrock (Claude Sonnet), adding Slack/Email alerting, self-healing SQL proposals, trust scoring, and multi-connection support. No Docker — uses venvs + systemd/PM2.

---

## Directory Structure

```
data_quality_tool/
├── CLAUDE.md
├── README.md
├── pyproject.toml
├── requirements.txt
├── alembic.ini
├── setup.sh                           # venv + systemd + DB init
├── start.sh                           # multi-service start/stop
├── .env.example
├── .gitignore
│
├── backend/
│   ├── src/data_sentinel/
│   │   ├── __init__.py
│   │   ├── main.py                    # FastAPI app factory + lifespan
│   │   ├── config.py                  # Pydantic Settings (AWS, RDS, Slack, SES)
│   │   ├── api/
│   │   │   ├── deps.py                # DI: auth, roles, engine injection
│   │   │   ├── middleware/rls.py      # Row-Level Security
│   │   │   └── routers/
│   │   │       ├── discovery.py       # POST /discovery/run
│   │   │       ├── rules.py           # CRUD /rules + /rules/contracts
│   │   │       ├── scans.py           # POST /scans/trigger, GET /scans/history
│   │   │       ├── alerts.py          # GET /alerts, POST /alerts/{id}/resolve
│   │   │       ├── health_score.py    # GET /health-score, GET /health-score/{table}
│   │   │       ├── healing.py         # POST /healing/propose, /healing/{id}/approve
│   │   │       ├── rca.py             # POST /rca/analyze/{issue_id}
│   │   │       ├── audit.py           # GET /audit-trail
│   │   │       ├── connections.py     # CRUD /connections
│   │   │       └── auth.py            # POST /auth/login, /auth/refresh
│   │   ├── core/
│   │   │   ├── database.py            # Async engine + session (asyncpg)
│   │   │   ├── exceptions.py          # Domain exceptions
│   │   │   ├── security.py            # JWT + bcrypt (pinned 4.2.1)
│   │   │   └── aws_secrets.py         # Secrets Manager loader
│   │   ├── models/
│   │   │   ├── base.py                # UUID PK + timestamps
│   │   │   ├── user.py, connection.py, rule.py, rule_version.py
│   │   │   ├── run.py, issue.py, alert.py
│   │   │   ├── healing_proposal.py, trust_score.py
│   │   │   └── audit_trail.py         # Immutable, append-only
│   │   ├── schemas/                   # Pydantic v2 DTOs (one per router)
│   │   ├── services/
│   │   │   ├── bedrock_client.py      # AWS Bedrock Claude Sonnet (replaces Ollama)
│   │   │   ├── discovery_engine.py    # DDL → Bedrock → SodaCL rules
│   │   │   ├── scan_engine.py         # Orchestrates Soda/GE scans
│   │   │   ├── soda_executor.py       # Soda Core 3.5.x wrapper
│   │   │   ├── ge_profiler.py         # Great Expectations profiler
│   │   │   ├── rca_engine.py          # AI root cause analysis
│   │   │   ├── healing_engine.py      # AI SQL fix → approve → execute
│   │   │   ├── nudge_engine.py        # Slack + SES alerts + resolution tokens
│   │   │   ├── trust_score_engine.py  # 0-100 per-table scoring
│   │   │   ├── audit_service.py       # Immutable audit writes
│   │   │   └── connection_service.py  # DB connection management
│   │   └── repositories/base.py       # Generic async CRUD
│   ├── alembic/
│   ├── scripts/seed_dev_data.py, create_admin.py
│   └── tests/
│
├── frontend/                          # React 18 + TS + Vite + Tailwind + lucide-react
│   └── src/
│       ├── services/api.ts            # Fetch-based client (no Axios)
│       ├── context/AuthContext.tsx     # JWT auth provider
│       ├── hooks/usePolling.ts
│       ├── components/                # Layout (pine sidebar), DataTable, TrustGauge (SVG ring), Modal, StatusBadge (dot pills)
│       └── pages/                     # 10 pages + Login (Pine Labs brand)
│
├── airflow_dags/                      # 4 DAGs (Airflow 3.x compatible)
│   ├── datasentinel_discovery_dag.py  # Daily AI rule generation
│   ├── datasentinel_scan_dag.py       # Scheduled DQ scans
│   ├── datasentinel_trust_dag.py      # Daily trust score computation
│   └── datasentinel_nudge_dag.py      # 15-min alert escalation
│
└── shared_utils/
    ├── prompt_templates.py            # All LLM prompt constants
    ├── yaml_parser.py                 # SodaCL parse + fence stripping
    └── constants.py                   # Enums, severity levels, statuses
```

---

## Database Schema (10 tables)

| Table | Purpose | Key Fields |
|-------|---------|------------|
| `users` | Auth + RLS | email, role (admin/lead/analyst/viewer), hr_scope arrays |
| `data_connections` | Managed DB targets | host, port, db, schema, `secret_arn` (AWS Secrets Manager) |
| `dq_rules` | Rule registry | source (manual/ai/contract), engine (soda/ge), `check_definition` YAML, severity, `is_contract` flag |
| `dq_rule_versions` | Immutable version history | rule_id FK, version int, check_definition snapshot |
| `dq_runs` | Scan execution records | status, passed/failed/warnings counts, health_score |
| `dq_issues` | Failing checks + RCA | rca_summary, rca_pattern, rca_confidence, snoozed_until |
| `alerts` | Slack/Email nudge records | channel, `resolution_token` (UUID), escalation_level, resolution_action |
| `healing_proposals` | AI-generated SQL fixes | proposed_sql, rollback_sql, risk_level, confidence, execution_result |
| `trust_scores` | Per-table score snapshots | overall (0-100), completeness, accuracy, timeliness sub-scores |
| `audit_trail` | **Immutable** (DB trigger enforced) | entity_type, action, old/new values, justification, ip_address |

All tables: UUID PKs, `created_at`/`updated_at` timestamps. Audit trail has a PostgreSQL trigger preventing UPDATE/DELETE.

---

## Key Services

### AWS Bedrock Client (replaces Ollama)
- Uses **Converse API** (`boto3.client("bedrock-runtime").converse()`)
- boto3 is sync → wrapped in `asyncio.run_in_executor` to avoid blocking
- Three LLM interactions: rule generation, RCA analysis, healing SQL proposal
- Prompt templates in `shared_utils/prompt_templates.py`

### Trust Score Algorithm
```
overall = 0.40 * completeness + 0.40 * accuracy + 0.20 * timeliness
```
- **Completeness**: % of passed missing_count/missing_percent/row_count checks
- **Accuracy**: % of passed invalid_count/duplicate_count/failed_rows checks
- **Timeliness**: % of passed freshness checks (or score decays 2pts/hour since last scan)
- Rules categorized via `# dimension:` comments in SodaCL YAML

### Nudge Engine (Slack + Email)
- Slack: Block Kit messages with Approve/Reject/Snooze buttons linking to `{base_url}/resolve/{token}`
- Email: AWS SES with HTML template + same action links
- Resolution tokens: UUID stored in `alerts.resolution_token`, validated by backend
- Escalation: Airflow DAG every 15min bumps `escalation_level` for stale alerts

### Self-Healing Pipeline
1. AI proposes SQL fix + rollback SQL via Bedrock
2. `HealingProposal` created (status=pending), alert sent to admin
3. Admin approves/rejects via UI or Slack/Email link
4. On approve: dry-run first (BEGIN → SQL → count → ROLLBACK), then execute if count matches
5. Safety: max 1000 rows, DML only (no DDL), rollback always available
6. Every step → audit_trail entry

### Soda Executor
- Adapted from pulse-dq with all 3.5.x quirks preserved:
  - No `get_checks_pass()` — use `_checks` + `get_checks_fail()` set comparison
  - `check.check_value` is int/float, not dict
  - `check.dict["table"]` for table name
  - Dynamic datasource YAML from `data_connections` table

---

## Frontend (10 Pages)

| Page | Route | Features |
|------|-------|----------|
| Dashboard | `/` | KPI cards with lucide icons, SVG ring gauges, recent scans with health bars |
| Discovery | `/discovery` | Trigger AI rule discovery, review generated rules |
| Rules | `/rules` | CRUD registry, Data Contracts tab, YAML editor |
| Scans | `/scans` | Trigger + history + status polling |
| Issues | `/issues` | List with filters, RCA drill-down panel |
| Alerts | `/alerts` | Inbox, resolve/snooze actions, escalation timeline |
| Healing | `/healing` | SQL preview cards, approve/reject/execute |
| Trust Scores | `/trust-scores` | Clickable ring gauge cards, per-table breakdown |
| Audit Trail | `/audit-trail` | Immutable log viewer with filters |
| Connections | `/connections` | Database connection CRUD |

State: AuthContext (JWT) + page-local `useState`/`useEffect`. No Redux.

---

## Airflow DAGs (4 DAGs, Airflow 3.x)

1. **Discovery** (daily 02:00): list connections → profile tables → Bedrock generates rules → Slack notify
2. **Scan** (every 6h): gather active rules → trigger scans → poll completion → compute trust → trigger alerts
3. **Trust** (daily 07:00): list tables → compute scores → store snapshots → detect degradation (>10% drop → alert)
4. **Nudge** (every 15min): check unresolved alerts → escalate → re-send reminders

All use `airflow.providers.standard.operators.python` and `schedule=` (not `schedule_interval`).

---

## Implementation Order (8 Phases)

| Phase | What | ~Files |
|-------|------|--------|
| 1. Foundation | Config, DB, auth, models (user, connection), main.py, setup.sh, start.sh, alembic, seed script | ~20 |
| 2. Core DQ Pipeline | Rule/run/issue models, soda_executor, ge_profiler, scan_engine, /rules + /scans routers | ~15 |
| 3. AI Intelligence | bedrock_client, prompt_templates, discovery_engine, rca_engine, /discovery + /rca routers | ~10 |
| 4. Trust + Audit | trust_score model + engine, audit_trail model + service + DB trigger, /health-score + /audit routers | ~8 |
| 5. Healing + Nudge | healing_proposal + alert models, healing_engine, nudge_engine, /healing + /alerts routers | ~10 |
| 6. Airflow DAGs | 4 DAGs with proper 3.x imports | ~4 |
| 7. Frontend | Vite scaffold, all 10 pages, api.ts, AuthContext, shared components | ~25 |
| 8. Hardening | CORS lockdown, rate limiting, tests, systemd units, CLAUDE.md | ~10 |

---

## Verification Plan

After each phase:
1. `alembic upgrade head` succeeds
2. `uvicorn data_sentinel.main:app --reload` boots without errors
3. `GET /healthz` returns 200
4. Phase-specific endpoint smoke tests via curl
5. Frontend: `npm run dev` boots, pages load, API calls succeed through Vite proxy

End-to-end test after Phase 7:
- Create a connection → discover rules via Bedrock → approve rules → trigger scan → view issues with RCA → approve healing proposal → verify trust score updates → check audit trail
