# DataSentinel — Start / Stop / Restart Guide

## Quick Start

```bash
# Start both backend + frontend
./start.sh start

# Check status
./start.sh status

# Stop everything
./start.sh stop

# Restart
./start.sh restart
```

## Service URLs

| Service | URL | Description |
|---------|-----|-------------|
| Frontend | http://localhost:5173 | React UI |
| Backend API | http://localhost:8000 | FastAPI server |
| Swagger Docs | http://localhost:8000/docs | Interactive API docs |
| ReDoc | http://localhost:8000/redoc | Alternative API docs |
| Health Check | http://localhost:8000/healthz | Returns `{"status":"ok"}` |

## Starting Services Individually

### Backend Only

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. uvicorn data_sentinel.main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend Only

```bash
cd frontend
npm run dev
```

### Frontend Production Build

```bash
cd frontend
npm run build    # outputs to frontend/dist/
npm run preview  # preview the production build
```

## Logs

When started via `start.sh`, logs are written to:

| Service | Log File |
|---------|----------|
| Backend | `backend.log` |
| Frontend | `frontend.log` |

View logs in real time:
```bash
tail -f backend.log
tail -f frontend.log
```

## PID Files

`start.sh` tracks running processes via PID files:
- `.backend.pid`
- `.frontend.pid`

If a service won't start (says "already running" but isn't), delete the stale PID file:
```bash
rm .backend.pid .frontend.pid
```

## Database Management

### Run Migrations

```bash
source .venv/bin/activate
cd /Volumes/T9\ 1/Products/data_quality_tool
alembic upgrade head
```

### Create a New Migration

```bash
alembic revision --autogenerate -m "description of change"
```

### Rollback Migration

```bash
alembic downgrade -1
```

### Reset Database

```bash
psql -U postgres -c "DROP DATABASE datasentinel"
psql -U postgres -c "CREATE DATABASE datasentinel"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE datasentinel TO datasentinel"
alembic upgrade head
python backend/scripts/seed_dev_data.py
```

## Running Tests

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. pytest backend/tests/ -v
```

## API Quick Reference

All endpoints require JWT authentication (except `/healthz`, `/api/auth/login`, and `/api/alerts/resolve/{token}`).

### Authentication
```bash
# Login
TOKEN=$(curl -s -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@datasentinel.dev","password":"admin123"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# Use token in subsequent requests
AUTH="Authorization: Bearer $TOKEN"
```

### Connections
```bash
# List connections
curl -H "$AUTH" http://localhost:8000/api/connections

# Create connection
curl -X POST -H "$AUTH" -H "Content-Type: application/json" \
  http://localhost:8000/api/connections \
  -d '{"name":"my-db","host":"localhost","port":5432,"database":"mydb","username":"user","password":"pass"}'
```

### Rules
```bash
# List rules
curl -H "$AUTH" http://localhost:8000/api/rules

# Create rule
curl -X POST -H "$AUTH" -H "Content-Type: application/json" \
  http://localhost:8000/api/rules \
  -d '{"connection_id":"<uuid>","table_name":"users","check_name":"row_count","check_definition":"row_count > 0","severity":"high"}'
```

### Scans
```bash
# Trigger scan
curl -X POST -H "$AUTH" -H "Content-Type: application/json" \
  http://localhost:8000/api/scans/trigger \
  -d '{"connection_id":"<uuid>"}'

# Scan history
curl -H "$AUTH" http://localhost:8000/api/scans/history
```

### AI Discovery
```bash
# Run AI rule discovery
curl -X POST -H "$AUTH" -H "Content-Type: application/json" \
  http://localhost:8000/api/discovery/run \
  -d '{"connection_id":"<uuid>"}'
```

### Trust Scores
```bash
# List all scores
curl -H "$AUTH" http://localhost:8000/api/health-score

# Table history
curl -H "$AUTH" http://localhost:8000/api/health-score/users
```

### Healing
```bash
# List proposals
curl -H "$AUTH" http://localhost:8000/api/healing

# Propose fix for an issue
curl -X POST -H "$AUTH" -H "Content-Type: application/json" \
  http://localhost:8000/api/healing/propose \
  -d '{"issue_id":"<uuid>"}'

# Approve
curl -X POST -H "$AUTH" http://localhost:8000/api/healing/<uuid>/approve
```

### Alerts & Audit
```bash
# List alerts
curl -H "$AUTH" http://localhost:8000/api/alerts

# Audit trail
curl -H "$AUTH" http://localhost:8000/api/audit-trail
```

## Airflow DAGs

If using Airflow for scheduling:

```bash
# Check DAG status
airflow dags list | grep datasentinel

# Manually trigger a DAG
airflow dags trigger datasentinel_scan

# Pause/unpause
airflow dags pause datasentinel_nudge
airflow dags unpause datasentinel_nudge
```

| DAG | Schedule | Purpose |
|-----|----------|---------|
| `datasentinel_discovery` | Daily 02:00 UTC | AI rule generation |
| `datasentinel_scan` | Every 6 hours | Data quality scans |
| `datasentinel_trust` | Daily 07:00 UTC | Trust score computation |
| `datasentinel_nudge` | Every 15 minutes | Alert escalation |
