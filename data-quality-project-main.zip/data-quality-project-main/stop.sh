#!/bin/bash
# ─── DataSentinel Demo Stop ──────────────────────────────────────
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_PID_FILE="$PROJECT_DIR/.backend.pid"
FRONTEND_PID_FILE="$PROJECT_DIR/.frontend.pid"

echo ""
echo "  Stopping DataSentinel..."
echo ""

for svc in frontend backend; do
    pid_file="$PROJECT_DIR/.${svc}.pid"
    if [ -f "$pid_file" ]; then
        pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            echo "  ✓ $svc stopped (PID $pid)"
        else
            echo "  - $svc was already stopped"
        fi
        rm -f "$pid_file"
    else
        echo "  - $svc not running"
    fi
done

# Kill any orphaned processes on the ports
lsof -ti:8000 2>/dev/null | xargs kill 2>/dev/null || true
lsof -ti:5173 2>/dev/null | xargs kill 2>/dev/null || true

echo ""
echo "  DataSentinel stopped."
echo ""
