# DataSentinel — HR Demo Script

## Quick Start

```bash
cd "/Volumes/T9 1/Products/data_quality_tool"
./demo_start.sh     # starts backend + frontend
```

**Login**: `admin@datasentinel.dev` / `admin123`

## Visual Design

The UI uses a **Pine Labs-inspired** brand identity:
- **Dark pine-green sidebar** with lucide icons for each navigation item
- **SVG ring gauges** for trust scores (animated fill, color-coded by health)
- **Dot-prefix status pills** for statuses (softer, muted semantic colors)
- **Split login page** — left: pine gradient with branding, right: clean white form
- **Font**: Roboto via Google Fonts
- **Accent color**: Bright emerald `#50D387` (Pine Labs brand green)

---

## Demo Flow (20-25 minutes)

### Act 1: The Problem (2 min)

**Talking point**: "HR data is critical for compliance, attrition analysis, and workforce planning. Yet data quality issues — missing exit reasons, stale survey data, incomplete performance reviews — often go undetected until they corrupt downstream reports. DataSentinel catches these automatically."

---

### Act 2: Dashboard Overview (3 min)

**Page**: `/` (Dashboard)

- **KPI cards** (top row): 4 cards with lucide icons, showing Avg Trust Score, Open Alerts, Recent Scans, Tables Monitored
- **Trust Scores section**: SVG ring gauges for 6 HR tables:
  - `employee_promotions`: 98 (emerald green ring)
  - `employee_learning`: 97 (emerald green ring)
  - `employees`: 96 (emerald green ring)
  - `employee_attrition`: 90 (emerald green ring)
  - `performance_ratings`: 88 (emerald green ring)
  - `pulse_surveys`: 80 (yellow ring — needs attention)
- **Recent Scans section**: Compact list with status pills + inline health score progress bars
- **Open Alerts**: 3 active HR alerts

**Talking point**: "At a glance, HR leadership sees which datasets are healthy. Pulse surveys and performance ratings need attention. Trust scores combine completeness, accuracy, and timeliness into a single 0-100 score — like a credit score for your data."

---

### Act 3: AI Rule Discovery (5 min)

**Page**: `/discovery`

1. Select the `dev-postgres` connection from dropdown
2. Click the **"Run Discovery"** button (has a Sparkles icon)
3. Show the AI analyzing HR table structures and generating SodaCL rules
4. Point out the **Discovery History** table below — clean pine-styled headers, status pills with dot indicators, timestamps and rule counts

**Talking point**: "Instead of manually writing quality checks, our AI analyzes your table structures and sample data. For HR tables, it automatically discovers checks like: 'employee names must not be null', 'ages must be between 18-70', 'salaries must be positive', 'survey data must be fresh within 30 days'."

> **Note**: If AI is slow, show the 18 pre-seeded rules on the Rules page instead. Discovery history shows past run results.

---

### Act 4: Rules Management (3 min)

**Page**: `/rules`

- Show the 18 AI-generated rules across 6 HR tables
- Highlight HR-specific rules:
  - `missing_count(name) = 0` on employees (critical — compliance)
  - `invalid_count(age) = 0` with valid range 18-70 (accuracy)
  - `freshness(survey_date) < 30d` on pulse_surveys (timeliness)
  - `missing_count(exit_date) = 0` on attrition (critical — offboarding compliance)
- Switch to **Data Contracts** tab (underline-style tabs with pine-500 active indicator) — explain how rules can be grouped by table into contracts

**Talking point**: "Every rule has a severity (critical, high, medium) and a quality dimension. Missing exit dates is critical — it's a compliance issue. Missing survey scores is high — it impacts engagement analytics. Data contracts let you define SLAs per table."

---

### Act 5: Scan Execution (3 min)

**Page**: `/scans`

1. Select the `dev-postgres` connection
2. Click **"Trigger Scan"** (or show existing scan history)
3. Show the scan results — 18 checks, improving from 88.9% to 100%. Health scores displayed as inline progress bars (green/yellow/red)
4. Click on a scan row to see individual check results

**Talking point**: "Scans run all 18 HR rules against your live data. Each scan produces a health score. Notice the trend: 5 days ago we had 2 failures — today all 18 checks pass. The freshness issue on pulse surveys was fixed when the survey pipeline was restarted."

---

### Act 6: Issues + Root Cause Analysis (5 min)

**Page**: `/issues`

1. Show the 6 HR-specific issues — highlight the critical missing performance ratings
2. Click an issue row — the RCA panel slides in on the right with a Brain icon header, showing structured analysis with confidence progress bars

**Pre-seeded RCA examples** (HR-specific):
- `missing_count(department)` on employees: "3 records missing department — likely from recent bulk import of contractor data" (Pattern: data_pipeline_delay, 88% confidence)
- `missing_count(rating)` on performance_ratings: "12 reviews missing ratings — Q4 review cycle incomplete" (Pattern: upstream_error, 91% confidence)
- `freshness(survey_date)` on pulse_surveys: "Survey data is 45 days old — survey pipeline stalled" (Pattern: data_pipeline_delay, 95% confidence)
- `missing_count(reason)` on employee_attrition: "5 exit records missing reason — HR may not have completed exit interviews" (Pattern: business_logic_change, 82% confidence)

**Talking point**: "DataSentinel doesn't just tell you WHAT failed — it analyzes WHY. For the missing performance ratings, the AI identifies this as an upstream process issue with 91% confidence. For stale survey data, it's a pipeline delay at 95% confidence. These insights help HR teams prioritize fixes."

---

### Act 7: Self-Healing (3 min)

**Page**: `/healing`

**Talking point**: "For issues that can be fixed with SQL, DataSentinel proposes safe repairs. For example, it might propose setting a default department for contractor records, or flagging incomplete performance reviews. Every proposal goes through: AI generates SQL → Admin reviews → Dry-run validates → Execute with rollback."

- Show risk level indicators (colored AlertTriangle icons for high/medium/low)
- Click "View" (Eye icon) to open the proposal modal — SQL displayed in pine-tinted code blocks
- Explain the approval workflow (pending → approved → executed) using the icon buttons (Check/X/Play)
- Highlight safety: SQL validation (only UPDATE/INSERT), row limit (max 1000), dry-run, rollback always provided

> To show a live proposal: go to Issues → click an issue → "Propose Fix"

---

### Act 8: Trust Scores Deep Dive (2 min)

**Page**: `/trust-scores`

- Click on `pulse_surveys` ring gauge card (lowest at 80, bordered card with hover effect) — show 3-dimension breakdown as SVG ring gauges on pine-50 background:
  - Completeness: 88
  - Accuracy: 84
  - Timeliness: 65 (root cause of low score — stale data)
- Show the historical trend — timeliness improving from 50 to 65 over 5 days
- Compare with `employee_learning` at 97 — clean table

**Talking point**: "Trust scores tell HR leadership: 'pulse survey data is 80% trustworthy — the issue is timeliness.' When building attrition models or engagement reports, you know which tables to trust and which need cleanup first."

---

### Act 9: Alerts & Audit Trail (2 min)

**Page**: `/alerts` — Show 3 HR alerts with channel icons (MessageSquare for Slack, Mail for email):
- Slack: Performance ratings missing ratings — Q4 review cycle incomplete
- Email: Pulse survey data is 45 days stale — engagement tracking impacted
- Slack (resolved): Employee attrition records missing exit reasons — compliance risk
- Action buttons: Check (approve), X (reject), Clock (snooze) as icon buttons

**Page**: `/audit-trail` — Show the immutable log with filter bar (Entity Type + Action dropdowns, Clear filters button)

**Talking point**: "Every action is logged to an immutable audit trail — PostgreSQL triggers prevent anyone from editing or deleting entries. For HR data, this is critical for SOX compliance and audit readiness."

---

### Act 10: Connections (1 min)

**Page**: `/connections`

- Show the existing dev-postgres connection with Database icon, type badge (PG/MY/SF/RS), and green status dot
- Explain multi-database support: PostgreSQL, MySQL, Snowflake, Redshift
- Mention AWS Secrets Manager integration for credential storage
- New Connection modal has a clean grid layout for host/port and database/schema fields

---

## Key Differentiators for HR

| Feature | What to say |
|---------|-------------|
| **AI-First** | "AI discovers HR-specific rules, analyzes root causes, and proposes fixes — not just monitoring" |
| **Self-Healing** | "Automatically fix data quality issues with admin approval — no manual SQL required" |
| **Trust Scores** | "Quantified data quality SLAs — know which HR tables to trust for analytics" |
| **Compliance-Ready** | "Immutable audit trail + critical rule alerts = audit-ready from day one" |
| **HR-Aware** | "Discovers domain-specific checks: age ranges, salary constraints, survey freshness, exit interview completeness" |
| **Proactive Alerts** | "Slack + email alerts ensure issues are caught before they corrupt HR reports" |

---

## If Something Goes Wrong

| Problem | Fix |
|---------|-----|
| Backend down | `./demo_start.sh` (restarts both) |
| Frontend blank | Check `frontend.log`, ensure port 5173 free |
| Login fails | Use `admin@datasentinel.dev` / `admin123` |
| AI features slow | Skip live AI — show pre-seeded rules, RCA results, and discovery history |
| Port in use | `./demo_stop.sh` then `./demo_start.sh` |
| Scan shows failed | Check backend.log; ensure HR tables exist in database |

---

## Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@datasentinel.dev | admin123 |
| Lead | lead@datasentinel.dev | lead123 |
| Analyst | analyst@datasentinel.dev | analyst123 |
