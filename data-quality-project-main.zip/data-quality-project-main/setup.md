# DataSentinel — First-Time Setup Guide

## Prerequisites

- **Python 3.11+** installed
- **Node.js 18+** and npm
- **PostgreSQL** running (Postgres.app, Homebrew, or RDS)
- **AWS account** with Bedrock access (for AI features)
- Optional: Slack workspace (for alerts), AWS SES (for email alerts)
- Optional: Apache Airflow 3.x (for scheduled DAGs)

## 1. Clone the Repository

```bash
git clone https://gitlab.com/dattamsha-data-labs-private-limited-group/data-quality-project.git
cd data-quality-project
```

## 2. Automated Setup

The `setup.sh` script handles venv creation, dependency installation, database creation, and migrations:

```bash
chmod +x setup.sh start.sh
./setup.sh
```

This will:
- Create a Python virtual environment at `.venv/`
- Install all Python dependencies (with `bcrypt==4.2.1` pinned)
- Copy `.env.example` to `.env` if it doesn't exist
- Create the `datasentinel` PostgreSQL database and user
- Run Alembic migrations (creates all 10 tables + immutable audit trigger)

## 3. Configure Environment

Edit `.env` with your actual settings:

```bash
vim .env
```

### Required Settings

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL async connection string | `postgresql+asyncpg://datasentinel:changeme@localhost:5432/datasentinel` |
| `JWT_SECRET_KEY` | Random secret for JWT signing (change this!) | `openssl rand -hex 32` |

### AWS Settings (for AI features)

| Variable | Description |
|----------|-------------|
| `AWS_REGION` | AWS region for Bedrock |
| `AWS_BEDROCK_MODEL_ID` | Bedrock model ID (default: Claude Sonnet) |
| `AWS_ACCESS_KEY_ID` | Optional if using IAM roles |
| `AWS_SECRET_ACCESS_KEY` | Optional if using IAM roles |

### Slack Settings (for alerts)

| Variable | Description |
|----------|-------------|
| `SLACK_BOT_TOKEN` | Slack Bot OAuth token (`xoxb-...`) |
| `SLACK_DEFAULT_CHANNEL` | Default channel for alerts |

### AWS SES Settings (for email alerts)

| Variable | Description |
|----------|-------------|
| `SES_SENDER_EMAIL` | Verified SES sender email |
| `SES_REGION` | SES region |

### App Settings

| Variable | Description | Default |
|----------|-------------|---------|
| `APP_BASE_URL` | Public URL for resolution links | `http://localhost:8000` |
| `CORS_ORIGINS` | JSON array of allowed frontend origins | `["http://localhost:5173"]` |
| `LOG_LEVEL` | Logging level | `INFO` |

## 4. Create Admin User

```bash
source .venv/bin/activate
python backend/scripts/create_admin.py
```

You'll be prompted for email, password, and full name.

## 5. (Optional) Seed Development Data

Creates 3 dev users (admin/lead/analyst) and a sample localhost connection:

```bash
python backend/scripts/seed_dev_data.py
```

Dev credentials:
- `admin@datasentinel.dev` / `admin123`
- `lead@datasentinel.dev` / `lead123`
- `analyst@datasentinel.dev` / `analyst123`

## 6. Install Frontend Dependencies

```bash
cd frontend
npm install    # installs react, tailwindcss, lucide-react, etc.
cd ..
```

**Key frontend dependencies:**
- `react` + `react-dom` 18.x — UI framework
- `react-router-dom` 6.x — Client-side routing
- `tailwindcss` 3.4 — Utility-first CSS (custom `pine` green palette)
- `lucide-react` — Tree-shakeable SVG icons (24px stroke design)
- **Roboto font** — Loaded via Google Fonts CDN (no npm package)

## 7. Start the Application

```bash
./start.sh start
```

This starts both backend and frontend:
- **Backend API**: http://localhost:8000 (Swagger docs at http://localhost:8000/docs)
- **Frontend UI**: http://localhost:5173
- **Health check**: http://localhost:8000/healthz

## 8. (Optional) Airflow DAGs Setup

If you have Airflow 3.x installed:

```bash
# Copy DAGs to your Airflow DAGs folder
cp airflow_dags/*.py ~/airflow/dags/

# Verify DAGs are detected
airflow dags list | grep datasentinel
```

DAGs included:
- `datasentinel_discovery` — Daily AI rule generation (02:00 UTC)
- `datasentinel_scan` — DQ scans every 6 hours
- `datasentinel_trust` — Daily trust score computation (07:00 UTC)
- `datasentinel_nudge` — Alert escalation every 15 minutes

**Note:** Update the `sys.path` entries in each DAG file to match your deployment path.

## 9. Verify Installation

```bash
# Backend health
curl http://localhost:8000/healthz
# Expected: {"status":"ok"}

# Login
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@datasentinel.dev","password":"admin123"}'
# Expected: {"access_token":"...","token_type":"bearer"}

# Frontend
open http://localhost:5173
```

## Database Schema

The migration creates 10 tables:

| Table | Purpose |
|-------|---------|
| `users` | Authentication + role-based access |
| `data_connections` | Managed database targets |
| `dq_rules` | Data quality rule registry |
| `dq_rule_versions` | Immutable rule version history |
| `dq_runs` | Scan execution records |
| `dq_issues` | Failing checks with RCA data |
| `healing_proposals` | AI-generated SQL fix proposals |
| `alerts` | Slack/Email notification records |
| `trust_scores` | Per-table quality score snapshots |
| `audit_trail` | Immutable log (DB trigger enforced) |

## Troubleshooting

### `bcrypt` errors
Ensure `bcrypt==4.2.1` is installed. Version 5.x breaks passlib:
```bash
pip install bcrypt==4.2.1
```

### Database connection refused
Check PostgreSQL is running and the connection string in `.env` is correct:
```bash
psql -U datasentinel -d datasentinel -c "SELECT 1"
```

### Alembic migration fails
If tables already exist, stamp the current state:
```bash
alembic stamp head
```

### Frontend proxy errors
Ensure backend is running on port 8000 before starting frontend. The Vite dev server proxies `/api` requests to `http://localhost:8000`.
