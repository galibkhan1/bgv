# DataSentinel -- Setup & Operations Guide

## Table of Contents

- [Prerequisites](#prerequisites)
- [First-Time Setup](#first-time-setup)
  - [1. Clone the Repository](#1-clone-the-repository)
  - [2. Run the Automated Setup](#2-run-the-automated-setup)
  - [3. Configure Environment Variables](#3-configure-environment-variables)
  - [4. Create the Admin User](#4-create-the-admin-user)
  - [5. (Optional) Seed Development Data](#5-optional-seed-development-data)
  - [6. Start the Application](#6-start-the-application)
  - [7. Verify Everything Works](#7-verify-everything-works)
- [Day-to-Day Operations](#day-to-day-operations)
  - [Starting the Application](#starting-the-application)
  - [Stopping the Application](#stopping-the-application)
  - [Restarting the Application](#restarting-the-application)
  - [Checking Status](#checking-status)
  - [Viewing Logs](#viewing-logs)
- [Running Components Individually](#running-components-individually)
  - [Backend Only](#backend-only)
  - [Frontend Only](#frontend-only)
  - [Database Migrations](#database-migrations)
  - [Tests](#tests)
- [Airflow DAGs Setup](#airflow-dags-setup)
- [Production Deployment](#production-deployment)
- [Environment Variable Reference](#environment-variable-reference)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

Install the following before starting:

| Dependency     | Version   | Check Command            | Install Notes                                  |
|----------------|-----------|--------------------------|------------------------------------------------|
| Python         | 3.11+     | `python3 --version`      | macOS: `brew install python@3.11`              |
| Node.js        | 18+       | `node --version`         | macOS: `brew install node`                     |
| npm            | 9+        | `npm --version`          | Comes with Node.js                             |
| PostgreSQL     | 14+       | `psql --version`         | macOS: `brew install postgresql@16`            |
| OpenSSL        | any       | `openssl version`        | Pre-installed on macOS/Linux                   |
| Git            | any       | `git --version`          | Pre-installed on macOS                         |

**PostgreSQL must be running** before setup:

```bash
# macOS (Homebrew)
brew services start postgresql@16

# Linux (systemd)
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

---

## First-Time Setup

### 1. Clone the Repository

```bash
git clone https://gitlab.com/dattamsha-data-labs-private-limited-group/data-quality-project.git
cd data-quality-project
```

### 2. Run the Automated Setup

The setup script handles everything: Python venv, pip install, database creation, migrations, and key generation.

```bash
chmod +x setup.sh start.sh
./setup.sh
```

**What `setup.sh` does:**

1. Creates a Python virtual environment in `.venv/`
2. Installs all Python dependencies from `requirements.txt`
3. Installs the `data-sentinel` package in editable mode
4. Copies `.env.example` to `.env` (if `.env` doesn't exist)
5. Creates the `datasentinel` PostgreSQL database and user with a random password
6. Updates `.env` with the generated database password (replaces the default `changeme`)
7. Generates a Fernet `ENCRYPTION_KEY` and appends it to `.env`
8. Runs Alembic database migrations (`alembic upgrade head`)

**If the script fails at the database step**, ensure PostgreSQL is running and the `postgres` superuser is accessible:

```bash
# Test PostgreSQL access
psql -U postgres -c "SELECT 1"
```

### 3. Configure Environment Variables

Open `.env` and fill in the remaining values:

```bash
# Open in your editor
nano .env    # or: code .env
```

**Required for full functionality** (the app starts without these, but features will be limited):

```bash
# JWT -- CHANGE THIS for production (any random string, 32+ chars)
JWT_SECRET_KEY=<your-random-secret>

# AWS Bedrock (for AI rule discovery, RCA, and self-healing)
AWS_REGION=us-east-1
AWS_BEDROCK_MODEL_ID=us.anthropic.claude-sonnet-4-20250514
AWS_ACCESS_KEY_ID=<your-key>           # omit if using IAM role
AWS_SECRET_ACCESS_KEY=<your-secret>    # omit if using IAM role

# Slack (for alert notifications via Block Kit)
SLACK_BOT_TOKEN=xoxb-your-slack-bot-token
SLACK_DEFAULT_CHANNEL=#data-quality-alerts

# AWS SES (for email alert notifications)
SES_SENDER_EMAIL=datasentinel@yourcompany.com
SES_REGION=us-east-1
```

**Already auto-configured by setup.sh** (verify they look correct):

```bash
DATABASE_URL=postgresql+asyncpg://datasentinel:<generated-password>@localhost:5432/datasentinel
ENCRYPTION_KEY=<generated-fernet-key>
```

### 4. Create the Admin User

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. python backend/scripts/create_admin.py
```

You will be prompted for:
- **Email**: your login email (e.g., `admin@yourcompany.com`)
- **Password**: securely entered (hidden input)
- **Full name**: display name

### 5. (Optional) Seed Development Data

For local development, seed sample users and a connection:

```bash
PYTHONPATH=backend/src:. python backend/scripts/seed_dev_data.py
```

This creates:
- `admin@datasentinel.dev` / `admin123` (admin role)
- `lead@datasentinel.dev` / `lead123` (lead role)
- `analyst@datasentinel.dev` / `analyst123` (analyst role)
- A sample `dev-postgres` connection pointing to localhost

### 6. Start the Application

```bash
./start.sh start
```

This starts both the backend and frontend as background processes:
- **Backend** (FastAPI + Uvicorn): `http://localhost:8000`
- **Frontend** (Vite dev server): `http://localhost:5173`
- **API docs** (Swagger UI): `http://localhost:8000/docs`

### 7. Verify Everything Works

```bash
# Check both services are running
./start.sh status

# Test the health endpoint
curl http://localhost:8000/healthz
# Expected: {"status":"ok"}

# Open the frontend in your browser
open http://localhost:5173
```

Log in with the admin credentials you created in step 4.

---

## Day-to-Day Operations

### Starting the Application

```bash
cd /path/to/data-quality-project
./start.sh start
```

Output:
```
Backend started (PID 12345), log: backend.log
Frontend started (PID 12346), log: frontend.log

Backend:  http://localhost:8000
Frontend: http://localhost:5173
API docs: http://localhost:8000/docs
```

### Stopping the Application

```bash
./start.sh stop
```

### Restarting the Application

```bash
./start.sh restart
```

This stops both services, waits 1 second, then starts them again. Use this after:
- Changing `.env` values
- Updating Python dependencies
- Pulling new code from Git

### Checking Status

```bash
./start.sh status
```

Output:
```
backend: running (PID 12345)
frontend: running (PID 12346)
```

### Viewing Logs

```bash
# Backend logs (FastAPI/Uvicorn)
tail -f backend.log

# Frontend logs (Vite)
tail -f frontend.log

# Last 50 lines of backend log
tail -50 backend.log
```

---

## Running Components Individually

For development, you may want to run backend and frontend in separate terminals with live output.

### Backend Only

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. uvicorn data_sentinel.main:app --reload --port 8000
```

The `--reload` flag enables hot-reloading on file changes.

### Frontend Only

```bash
cd frontend
npm install     # only needed first time or after package.json changes (includes lucide-react)
npm run dev
```

The Vite dev server starts at `http://localhost:5173` and proxies `/api` requests to `http://localhost:8000`.

**Note:** The frontend uses a custom `pine` Tailwind color palette (Pine Labs brand). If you see Tailwind errors about unknown `pine-*` classes after pulling new code, clear the Vite cache:
```bash
rm -rf frontend/node_modules/.vite
```

### Database Migrations

```bash
source .venv/bin/activate

# Apply all pending migrations
alembic upgrade head

# Check current migration version
alembic current

# See migration history
alembic history
```

### Tests

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. pytest backend/tests/
```

To install dev dependencies (pytest, ruff, etc.):

```bash
pip install -e ".[dev]"
```

---

## Airflow DAGs Setup

DataSentinel includes 4 Airflow DAGs for automated operations. This section is only needed if you want scheduled, unattended scanning and alerting.

### DAG Summary

| DAG                       | Schedule       | Purpose                                          |
|---------------------------|----------------|--------------------------------------------------|
| `datasentinel_discovery`  | Daily 2:00 AM  | AI-powered rule generation for all connections    |
| `datasentinel_scan`       | Every 6 hours  | Run DQ checks on all active connections           |
| `datasentinel_trust`      | Daily 7:00 AM  | Compute trust scores, detect degradation          |
| `datasentinel_nudge`      | Every 15 mins  | Escalate unresolved alerts, expire snoozed issues |

### Installation

1. **Install Airflow 3.x** (if not already installed):

```bash
pip install apache-airflow
```

2. **Set the required environment variable** in your Airflow environment:

```bash
export DATASENTINEL_PROJECT_ROOT=/path/to/data-quality-project
```

This variable is **required** -- the DAGs will fail to load without it.

3. **Symlink or copy the DAGs** into your Airflow dags folder:

```bash
# Option A: Symlink (recommended for development)
ln -s /path/to/data-quality-project/airflow_dags/* $AIRFLOW_HOME/dags/

# Option B: Copy (for production)
cp /path/to/data-quality-project/airflow_dags/*.py $AIRFLOW_HOME/dags/
```

4. **Ensure the DataSentinel venv is accessible** to Airflow. If Airflow uses its own venv, install DataSentinel's dependencies there too:

```bash
pip install -r /path/to/data-quality-project/requirements.txt
```

5. **Verify DAGs are loaded** in the Airflow UI or CLI:

```bash
airflow dags list | grep datasentinel
```

---

## Production Deployment

### Key Differences from Development

| Setting              | Development              | Production                        |
|----------------------|--------------------------|-----------------------------------|
| `ENVIRONMENT`        | `development`            | `production`                      |
| `JWT_SECRET_KEY`     | default allowed          | **must** be unique, random        |
| `ENCRYPTION_KEY`     | auto-generated dev key   | **must** be unique Fernet key     |
| `DATABASE_URL`       | `changeme` allowed       | **must** use strong password      |
| `CORS_ORIGINS`       | `localhost:5173`         | your actual frontend domain       |
| `APP_BASE_URL`       | `http://localhost:8000`  | your actual backend URL           |
| Backend `--reload`   | enabled                  | disabled                          |
| HSTS header          | disabled                 | enabled automatically             |

### Production Checklist

1. **Set `ENVIRONMENT=production`** in `.env` -- this enables all security guards:
   - App will refuse to start with default JWT secret
   - App will refuse to start with default database password
   - App will refuse to start with missing or known-dev encryption key
   - HSTS header is enabled automatically

2. **Generate production secrets**:

```bash
# JWT secret (random 64-char string)
openssl rand -base64 48

# Encryption key (Fernet)
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# Database password
openssl rand -base64 24
```

3. **Build the frontend** for production:

```bash
cd frontend
npm run build
```

The output is in `frontend/dist/`. Serve it with Nginx, Caddy, or any static file server.

4. **Run the backend without `--reload`**:

```bash
PYTHONPATH=backend/src:. uvicorn data_sentinel.main:app --host 0.0.0.0 --port 8000 --workers 4
```

5. **Use a process manager** (systemd or PM2) to keep services running:

```bash
# PM2 example
pm2 start "PYTHONPATH=backend/src:. uvicorn data_sentinel.main:app --host 0.0.0.0 --port 8000 --workers 4" --name datasentinel-api
pm2 save
```

6. **Put a reverse proxy** (Nginx/Caddy) in front for TLS, static file serving, and request buffering.

---

## Environment Variable Reference

| Variable                        | Required | Default                              | Description                                      |
|---------------------------------|----------|--------------------------------------|--------------------------------------------------|
| `DATABASE_URL`                  | Yes      | `...changeme...`                     | PostgreSQL async connection string               |
| `JWT_SECRET_KEY`                | Yes      | `change-this-to-a-random-secret`     | Secret for signing JWT tokens                    |
| `JWT_ALGORITHM`                 | No       | `HS256`                              | JWT signing algorithm                            |
| `JWT_ACCESS_TOKEN_EXPIRE_MINUTES` | No     | `60`                                 | Token expiry in minutes                          |
| `ENCRYPTION_KEY`                | Yes*     | auto-generated in dev                | Fernet key for encrypting connection passwords   |
| `ENVIRONMENT`                   | No       | `development`                        | `development` or `production`                    |
| `AWS_REGION`                    | No       | `us-east-1`                          | AWS region for Bedrock and SES                   |
| `AWS_BEDROCK_MODEL_ID`          | No       | `us.anthropic.claude-sonnet-4-20250514` | Bedrock model for AI features                 |
| `AWS_ACCESS_KEY_ID`             | No*      | None                                 | AWS credentials (omit if using IAM role)         |
| `AWS_SECRET_ACCESS_KEY`         | No*      | None                                 | AWS credentials (omit if using IAM role)         |
| `SLACK_BOT_TOKEN`               | No       | None                                 | Slack bot token for alert notifications          |
| `SLACK_DEFAULT_CHANNEL`         | No       | `#data-quality-alerts`               | Default Slack channel for alerts                 |
| `SES_SENDER_EMAIL`              | No       | None                                 | Verified SES sender email address                |
| `SES_REGION`                    | No       | `us-east-1`                          | AWS region for SES                               |
| `APP_BASE_URL`                  | No       | `http://localhost:8000`              | Base URL for alert resolution links              |
| `CORS_ORIGINS`                  | No       | `["http://localhost:5173"]`          | JSON array of allowed CORS origins               |
| `LOG_LEVEL`                     | No       | `INFO`                               | Logging level (`DEBUG`, `INFO`, `WARNING`, etc.) |
| `DATASENTINEL_PROJECT_ROOT`     | Airflow  | None                                 | Project root path (required for Airflow DAGs)    |

*Required in production (`ENVIRONMENT=production`). Auto-handled in development.

---

## Troubleshooting

### Setup fails at database creation

```
psql: error: connection to server on socket ... failed: No such file or directory
```

PostgreSQL is not running. Start it:

```bash
# macOS
brew services start postgresql@16

# Linux
sudo systemctl start postgresql
```

### Setup fails at `psql -U postgres`

```
psql: error: FATAL: role "postgres" does not exist
```

On some macOS Homebrew installs, the superuser is your OS username:

```bash
psql -U $(whoami) -c "SELECT 1"
```

If this works, run the database commands manually:

```bash
psql -U $(whoami) -c "CREATE DATABASE datasentinel"
psql -U $(whoami) -c "CREATE USER datasentinel WITH PASSWORD 'your-password'"
psql -U $(whoami) -c "GRANT ALL PRIVILEGES ON DATABASE datasentinel TO datasentinel"
```

### Backend fails to start: `ModuleNotFoundError`

Ensure you activate the virtual environment and set `PYTHONPATH`:

```bash
source .venv/bin/activate
PYTHONPATH=backend/src:. uvicorn data_sentinel.main:app --reload --port 8000
```

### Backend fails to start: `SECURITY: ENCRYPTION_KEY must be set`

This happens in production mode (`ENVIRONMENT=production`) when `ENCRYPTION_KEY` is missing. Generate one:

```bash
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Add the output to `.env`:

```
ENCRYPTION_KEY=<paste-generated-key-here>
```

### Frontend shows blank page or API errors

1. Check the backend is running: `curl http://localhost:8000/healthz`
2. Check Vite proxy config in `frontend/vite.config.ts` points to the correct backend port
3. Check CORS_ORIGINS in `.env` includes the frontend URL

### `bcrypt` errors after upgrading dependencies

DataSentinel pins `bcrypt==4.2.1` because `bcrypt 5.x` breaks `passlib`. If you see bcrypt-related errors:

```bash
pip install bcrypt==4.2.1
```

### Alembic migration fails

```bash
# Check current state
alembic current

# If the database is out of sync, stamp the current state and retry
alembic stamp head
alembic upgrade head
```

### Airflow DAGs not showing up

1. Verify `DATASENTINEL_PROJECT_ROOT` is set in the Airflow environment
2. Check DAG files are in `$AIRFLOW_HOME/dags/`
3. Check Airflow logs for import errors: `airflow dags list-import-errors`
