# DataSentinel - Project Context for AI Assistants

## What This Is
DataSentinel is a Data Quality & Observability platform. It monitors database tables via Soda Core, uses Ollama Cloud for AI-powered rule discovery, root cause analysis, and self-healing SQL proposals. Alerts go via Slack (Block Kit) and email.

## Tech Stack
- **Backend**: Python 3.11+, FastAPI, SQLAlchemy 2.x (async + asyncpg), Alembic, Pydantic v2
- **Frontend**: React 18 + TypeScript 5 + Vite 5 + Tailwind CSS 3.4 + lucide-react icons
- **Database**: PostgreSQL (UUID PKs, JSONB, immutable audit trail trigger)
- **AI**: Ollama Cloud API (native `ollama` Python client, sync → run_in_executor)
- **DQ Engine**: Soda Core 3.5.x
- **Scheduling**: Airflow 3.x DAGs
- **No Docker** — uses venvs, systemd/PM2

## Project Structure
```
data_quality_tool/
├── backend/src/data_sentinel/    # FastAPI app
│   ├── api/routers/              # 10 routers (auth, connections, rules, scans, discovery, rca, health_score, audit, healing, alerts)
│   ├── core/                     # database, security, exceptions, aws_secrets, encryption
│   ├── models/                   # 11 SQLAlchemy models (includes DiscoveryRun)
│   ├── schemas/                  # Pydantic v2 DTOs
│   └── services/                 # Business logic (ollama_client, soda_executor, scan_engine, discovery_engine, rca_engine, healing_engine, nudge_engine, trust_score_engine, audit_service, connection_service). Note: bedrock_client.py is legacy/unused — use ollama_client.py
├── frontend/src/                 # React SPA
│   ├── pages/                    # 10 pages + Login
│   ├── components/               # Layout, DataTable, TrustGauge (SVG ring), Modal, StatusBadge (dot pills), ErrorBoundary
│   ├── context/AuthContext.tsx    # JWT auth
│   └── services/api.ts           # Fetch-based API client
├── demo_start.sh                 # One-click demo launcher
├── demo_stop.sh                  # Clean shutdown
└── stop.sh                       # Standalone stop script
├── airflow_dags/                 # 4 DAGs (discovery, scan, trust, nudge)
├── shared_utils/                 # prompt_templates, yaml_parser, constants
├── demo_start.sh                 # One-click demo launcher
├── demo_stop.sh                  # Clean shutdown
└── stop.sh                       # Standalone stop script
```

## Frontend Design System (Pine Labs Brand)
- **Color palette**: Custom `pine` scale (#001A12 to #F5FDF8) replacing old `sentinel` blue
- **Primary dark**: `pine-950` (#001A12) — sidebar background
- **Brand accent**: `pine-500` (#50D387) — Pine Labs emerald green
- **Font**: Roboto (400/500/700) via Google Fonts CDN
- **Icons**: `lucide-react` — tree-shakeable, consistent 24px stroke icons
- **Components**:
  - `TrustGauge`: SVG ring gauge with `stroke-dasharray` animation
  - `StatusBadge`: Pill badges with colored dot prefix indicator
  - `DataTable`: pine-100 headers, pine-200 borders, hover:bg-pine-50 rows
  - `Layout`: Dark pine-950 sidebar with lucide nav icons, border-l-2 active indicator
  - `Modal`: rounded-xl, backdrop-blur-sm overlay
- **Login**: Split layout — left pine gradient panel with branding, right white form

## Critical Gotchas
1. **bcrypt==4.2.1** pinned — bcrypt 5.x breaks passlib
2. **Soda Core 3.5.x** — No `get_checks_pass()`. Use `_checks` set minus `get_checks_fail()`. `check.check_value` is int/float, not dict (use `getattr(check, "check_value", None)` — FreshnessCheck has no check_value). Use `check.dict["table"]` for table name. Import from `soda.scan` not `soda.core.scan`.
3. **Airflow 3.x** — Use `airflow.providers.standard.operators.python`. Use `schedule=` not `schedule_interval=`. No `days_ago()`.
4. **Audit trail** — PostgreSQL trigger prevents UPDATE/DELETE on audit_trail table
5. **Ollama Cloud client** — sync `ollama.Client`, wrapped in `asyncio.run_in_executor`
6. **Soda datasource YAML** — Must use key `data_source <name>:`, type `postgres` (not `postgresql`), names must match `[a-z0-9_]`
7. **Rule definitions** — Stored as check-line-only format (e.g., `- row_count > 0`), NOT wrapped in `checks for <table>:`. Scan engine assembles the wrapper.
8. **Postgres.app v18** — Trust auth with `dakshsahni` user, pg_dump at `/Applications/Postgres.app/Contents/Versions/18/bin/pg_dump`

## Key Commands
```bash
# Demo start/stop
./demo_start.sh
./demo_stop.sh
./stop.sh             # standalone stop

# Setup
source .venv/bin/activate
alembic upgrade head
python backend/scripts/create_admin.py
python backend/scripts/seed_dev_data.py
python backend/scripts/seed_hr_demo.py

# Frontend setup (first time)
cd frontend && npm install   # includes lucide-react

# Backend only
PYTHONPATH=backend/src:shared_utils uvicorn data_sentinel.main:app --reload --port 8000

# Frontend only
cd frontend && npm run dev

# Tests (all)
PYTHONPATH=backend/src:shared_utils:. pytest backend/tests/

# Tests (single file)
PYTHONPATH=backend/src:shared_utils:. pytest backend/tests/test_yaml_parser.py -v
```

## Database Schema (11 tables)
users, data_connections, dq_rules, dq_rule_versions, dq_runs, dq_issues, healing_proposals, alerts, trust_scores, audit_trail, discovery_runs

## API Endpoints (all under /api)
- POST /auth/login, GET /auth/me
- CRUD /connections
- CRUD /rules, GET /rules/contracts, GET /rules/{id}/versions
- POST /scans/trigger, GET /scans/history, GET /scans/{id}/issues, GET /scans/issues/all
- POST /discovery/run, GET /discovery/history
- POST /rca/analyze/{issue_id}
- GET /health-score, GET /health-score/{table}, POST /health-score/compute/{conn_id}/{table}
- GET /audit-trail
- GET /healing, POST /healing/propose, POST /healing/{id}/approve|reject|execute
- GET /alerts, POST /alerts/{id}/resolve, GET /alerts/resolve/{token}
- GET /healthz

## Data Contracts
Data contracts are DQ rules with `is_contract=True`. They live in the `dq_rules` table. Frontend Rules page has an "All Rules" / "Data Contracts" tab toggle. Dedicated endpoint: `GET /rules/contracts`.

## Trust Score Formula
overall = 0.40 * completeness + 0.40 * accuracy + 0.20 * timeliness

## Demo Data (HR)
6 HR tables: employees, employee_attrition, performance_ratings, pulse_surveys, employee_learning, employee_promotions. Seeded via `seed_hr_demo.py` with 18 rules, 6 scan runs (improving trend), 6 issues (4 with RCA), 30 trust scores, 3 alerts, 5 audit entries.

## Environment Variables
Copy `.env.example` to `.env` and fill in values. Required: DATABASE_URL, JWT_SECRET_KEY, OLLAMA_CLOUD_BASE_URL, OLLAMA_CLOUD_API_KEY, OLLAMA_CLOUD_MODEL, ENCRYPTION_KEY, ENVIRONMENT.

## Credentials (Demo)
- **Admin**: admin@datasentinel.dev / admin123
- **URL**: http://localhost:5173 (frontend), http://localhost:8000/docs (API docs)
